import fs from 'node:fs';
import path from 'node:path';
import { getDb, getSettings, rowToRecord, syncExchangeFiles, utcNowIso, type IntakeRecord } from './storage.ts';
import { localTodayIso } from './analytics.ts';
import { validateIntakePayload, ValidationError } from './validation.ts';

function fetchRecords(startDate = '', endDate = ''): IntakeRecord[] {
  const db = getDb();
  const clauses: string[] = [];
  const params: string[] = [];
  if (startDate.trim()) {
    clauses.push('intake_date >= ?');
    params.push(startDate.trim());
  }
  if (endDate.trim()) {
    clauses.push('intake_date <= ?');
    params.push(endDate.trim());
  }
  const whereSql = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const rows = db
    .prepare(`SELECT * FROM intake_records ${whereSql} ORDER BY intake_date DESC, intake_time DESC, id DESC`)
    .all(...params) as Record<string, unknown>[];
  return rows.map(rowToRecord);
}

function buildExportSummary(records: IntakeRecord[], dailyTargetMl: number) {
  if (records.length === 0) {
    return {
      total_ml: 0,
      average_daily_ml: 0,
      active_days: 0,
      target_achievement_pct: 0,
      highest_day: null as { date: string; total_ml: number } | null,
      lowest_day: null as { date: string; total_ml: number } | null,
    };
  }
  const byDay = new Map<string, number>();
  for (const r of records) {
    byDay.set(r.intake_date, Math.round(((byDay.get(r.intake_date) ?? 0) + r.quantity_ml) * 100) / 100);
  }
  const entries = Array.from(byDay.entries());
  const totalMl = Math.round(entries.reduce((s, [, v]) => s + v, 0) * 100) / 100;
  const activeDays = entries.length;
  const avgDaily = Math.round((totalMl / activeDays) * 10) / 10;
  const achievedDays = entries.filter(([, v]) => v >= dailyTargetMl).length;
  const achievementPct = Math.round((achievedDays / activeDays) * 1000) / 10;
  const highest = entries.reduce((best, cur) => (cur[1] > best[1] ? cur : best));
  const lowest = entries.reduce((best, cur) => (cur[1] < best[1] ? cur : best));

  return {
    total_ml: totalMl,
    average_daily_ml: avgDaily,
    active_days: activeDays,
    target_achievement_pct: achievementPct,
    highest_day: { date: highest[0], total_ml: highest[1] },
    lowest_day: { date: lowest[0], total_ml: lowest[1] },
  };
}

function csvCell(val: unknown): string {
  const s = String(val ?? '');
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function exportCsvText(startDate = '', endDate = ''): string {
  const records = fetchRecords(startDate, endDate);
  const lines = ['id,intake_date,intake_time,quantity_ml,original_quantity,original_unit,category,description,source'];
  for (const r of records) {
    lines.push(
      [
        r.id,
        r.intake_date,
        r.intake_time,
        r.quantity_ml,
        r.original_quantity,
        r.original_unit,
        r.category,
        r.description,
        r.is_sample ? 'sample' : 'user',
      ]
        .map(csvCell)
        .join(','),
    );
  }
  return `${lines.join('\n')}\n`;
}

export function exportJsonText(startDate = '', endDate = ''): string {
  const records = fetchRecords(startDate, endDate);
  const settings = getSettings();
  const summary = buildExportSummary(records, settings.daily_target_ml);
  return JSON.stringify(
    {
      application: 'AquaTrack — Water Intake Reminder Log',
      generated_at: utcNowIso(),
      reporting_period: {
        start_date: startDate || 'All recorded dates',
        end_date: endDate || 'Present',
      },
      settings,
      summary,
      records,
    },
    null,
    2,
  );
}

export function exportMarkdownText(startDate = '', endDate = ''): string {
  const records = fetchRecords(startDate, endDate);
  const settings = getSettings();
  const summary = buildExportSummary(records, settings.daily_target_ml);
  const generated = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
  const period = `${startDate || 'Beginning'} to ${endDate || 'Latest'}`;

  const lines = [
    '# AquaTrack — Hydration Analytics Report',
    '',
    `- **Generated At:** ${generated}`,
    `- **Reporting Period:** ${period}`,
    `- **Daily Target:** ${Math.round(settings.daily_target_ml)} ml`,
    `- **Total Consumption:** ${Math.round(summary.total_ml)} ml`,
    `- **Average Daily Consumption:** ${summary.average_daily_ml.toFixed(1)} ml (${summary.active_days} active days)`,
    `- **Target Achievement Rate:** ${summary.target_achievement_pct.toFixed(1)}%`,
    `- **Highest Consumption Day:** ${summary.highest_day ? `${summary.highest_day.date} (${Math.round(summary.highest_day.total_ml)} ml)` : 'N/A'}`,
    `- **Lowest Consumption Day:** ${summary.lowest_day ? `${summary.lowest_day.date} (${Math.round(summary.lowest_day.total_ml)} ml)` : 'N/A'}`,
    '',
    '## Recorded Entries',
    '',
    '| Date | Time | Volume (ml) | Original | Category | Description |',
    '| :--- | :--- | ---: | :--- | :--- | :--- |',
  ];

  if (records.length === 0) {
    lines.push('| — | — | 0 | — | — | No records in selected range |');
  } else {
    for (const r of records) {
      const desc = (r.description || '—').replace(/\|/g, '\\|');
      lines.push(
        `| ${r.intake_date} | ${r.intake_time} | ${Math.round(r.quantity_ml)} | ${r.original_quantity} ${r.original_unit} | ${r.category} | ${desc} |`,
      );
    }
  }
  return `${lines.join('\n')}\n`;
}

export function exportTxtAudit(startDate = '', endDate = ''): string {
  const records = fetchRecords(startDate, endDate);
  const settings = getSettings();
  const summary = buildExportSummary(records, settings.daily_target_ml);
  const generated = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
  const period = `${startDate || 'Beginning'} to ${endDate || 'Latest'}`;

  const padR = (s: string | number, n: number) => String(s).padEnd(n, ' ');
  const padL = (s: string | number, n: number) => String(s).padStart(n, ' ');

  const lines = [
    '================================================================================',
    'AQUATRACK - WATER INTAKE AUDIT LOG',
    '================================================================================',
    `Generated Date        : ${generated}`,
    `Reporting Period      : ${period}`,
    `Configured Target     : ${Math.round(settings.daily_target_ml)} ml/day`,
    `Total Consumption     : ${Math.round(summary.total_ml)} ml`,
    `Average Daily Intake  : ${summary.average_daily_ml.toFixed(1)} ml`,
    `Target Achievement    : ${summary.target_achievement_pct.toFixed(1)}%`,
    `Highest Day           : ${summary.highest_day ? `${summary.highest_day.date} (${Math.round(summary.highest_day.total_ml)} ml)` : 'N/A'}`,
    `Lowest Day            : ${summary.lowest_day ? `${summary.lowest_day.date} (${Math.round(summary.lowest_day.total_ml)} ml)` : 'N/A'}`,
    '--------------------------------------------------------------------------------',
    `${padR('ID', 5)} ${padR('DATE', 12)} ${padR('TIME', 7)} ${padL('VOL(ML)', 9)} ${padL('ORIG', 10)} ${padR('CATEGORY', 14)} DESCRIPTION`,
    '--------------------------------------------------------------------------------',
  ];

  if (records.length === 0) {
    lines.push('No water intake records found for the specified period.');
  } else {
    for (const r of records) {
      const orig = `${r.original_quantity} ${r.original_unit}`;
      lines.push(
        `${padR(r.id, 5)} ${padR(r.intake_date, 12)} ${padR(r.intake_time, 7)} ${padL(Math.round(r.quantity_ml), 9)} ${padL(orig, 10)} ${padR(r.category, 14)} ${r.description || '-'}`,
      );
    }
  }
  lines.push('================================================================================');
  return `${lines.join('\n')}\n`;
}

function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuotes = false;
  const clean = text.replace(/^\uFEFF/, '');

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (inQuotes) {
      if (ch === '"') {
        if (clean[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      row.push(cell);
      cell = '';
    } else if (ch === '\r' || ch === '\n') {
      if (ch === '\r' && clean[i + 1] === '\n') i += 1;
      row.push(cell);
      if (row.some((c) => c.trim() !== '')) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += ch;
    }
  }
  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    if (row.some((c) => c.trim() !== '')) rows.push(row);
  }
  return rows;
}

export function importCsvText(csvText: string) {
  if (!csvText || !csvText.trim()) {
    return {
      success: false,
      imported_count: 0,
      rejected_count: 0,
      duplicate_count: 0,
      errors: [{ row: 0, type: 'validation', reason: 'Uploaded CSV content is empty.' }],
    };
  }

  const matrix = parseCsvRows(csvText);
  if (matrix.length < 1) {
    return {
      success: false,
      imported_count: 0,
      rejected_count: 0,
      duplicate_count: 0,
      errors: [{ row: 0, type: 'validation', reason: 'Missing CSV header row.' }],
    };
  }

  const headers = matrix[0].map((h) => h.trim().toLowerCase());
  const required = ['intake_date', 'intake_time', 'quantity', 'unit', 'category'];
  const missing = required.filter((col) => !headers.includes(col));
  if (missing.length > 0) {
    return {
      success: false,
      imported_count: 0,
      rejected_count: 0,
      duplicate_count: 0,
      errors: [{ row: 1, type: 'validation', reason: `Missing required column(s): ${missing.join(', ')}` }],
    };
  }

  const db = getDb();
  const existingRows = db
    .prepare('SELECT intake_date, intake_time, quantity_ml, category FROM intake_records')
    .all() as Array<{ intake_date: string; intake_time: string; quantity_ml: number; category: string }>;

  const existingKeys = new Set(
    existingRows.map(
      (r) => `${r.intake_date}|${r.intake_time}|${Math.round(Number(r.quantity_ml) * 100) / 100}|${r.category}`,
    ),
  );
  const seenInFile = new Set<string>();
  const errors: Array<{ row: number; type: string; reason: string; raw?: Record<string, string> }> = [];
  const validRows: ReturnType<typeof validateIntakePayload>[] = [];
  let rejectedCount = 0;
  let duplicateCount = 0;

  for (let i = 1; i < matrix.length; i++) {
    const lineNum = i + 1;
    const rawCells = matrix[i];
    const rowObj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      rowObj[h] = (rawCells[idx] ?? '').trim();
    });

    try {
      const cleaned = validateIntakePayload({
        intake_date: rowObj.intake_date ?? '',
        intake_time: rowObj.intake_time ?? '',
        quantity: rowObj.quantity ?? '',
        unit: rowObj.unit ?? '',
        category: rowObj.category ?? '',
        description: rowObj.description ?? '',
      });

      const key = `${cleaned.intake_date}|${cleaned.intake_time}|${Math.round(cleaned.quantity_ml * 100) / 100}|${cleaned.category}`;
      if (existingKeys.has(key) || seenInFile.has(key)) {
        duplicateCount += 1;
        errors.push({
          row: lineNum,
          type: 'duplicate',
          reason: `Duplicate entry (${cleaned.intake_date} ${cleaned.intake_time}, ${Math.round(cleaned.quantity_ml)} ml, ${cleaned.category}).`,
          raw: rowObj,
        });
        continue;
      }

      seenInFile.add(key);
      validRows.push(cleaned);
    } catch (err) {
      rejectedCount += 1;
      errors.push({
        row: lineNum,
        type: 'validation',
        reason: err instanceof ValidationError ? err.message : 'Invalid row format.',
        raw: rowObj,
      });
    }
  }

  const now = utcNowIso();
  const insertStmt = db.prepare(`
    INSERT INTO intake_records (
      quantity_ml, original_quantity, original_unit,
      category, description, intake_date, intake_time,
      is_sample, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
  `);

  db.exec('BEGIN');
  try {
    for (const item of validRows) {
      insertStmt.run(
        item.quantity_ml,
        item.original_quantity,
        item.original_unit,
        item.category,
        item.description,
        item.intake_date,
        item.intake_time,
        now,
        now,
      );
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }

  if (validRows.length > 0) {
    syncExchangeFiles();
  }

  return {
    success: true,
    imported_count: validRows.length,
    rejected_count: rejectedCount,
    duplicate_count: duplicateCount,
    errors,
  };
}

export function loadSampleDataset() {
  const sampleJsonPath = path.resolve(process.cwd(), 'backend', 'app', 'data', 'sample_data.json');
  const raw = JSON.parse(fs.readFileSync(sampleJsonPath, 'utf-8')) as {
    records: Array<{
      intake_date: string;
      intake_time: string;
      quantity: number;
      unit: string;
      category: string;
      description: string;
    }>;
  };

  // Shift sample dates so the latest sample day lands on local today, keeping all relative intervals intact
  const maxSampleDate = raw.records.reduce((max, r) => (r.intake_date > max ? r.intake_date : max), '2026-11-19');
  const [sy, sm, sd] = maxSampleDate.split('-').map(Number);
  const todayIso = localTodayIso();
  const [ty, tm, td] = todayIso.split('-').map(Number);
  const deltaDays = Math.round(
    (Date.UTC(ty, tm - 1, td) - Date.UTC(sy, sm - 1, sd)) / (24 * 60 * 60 * 1000),
  );

  const db = getDb();
  const now = utcNowIso();

  // Replace existing sample records only (never overwrite real user entries)
  db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM intake_records WHERE is_sample = 1').run();
    const stmt = db.prepare(`
      INSERT INTO intake_records (
        quantity_ml, original_quantity, original_unit,
        category, description, intake_date, intake_time,
        is_sample, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);

    let inserted = 0;
    for (const r of raw.records) {
      const [ry, rm, rd] = r.intake_date.split('-').map(Number);
      const shifted = new Date(Date.UTC(ry, rm - 1, rd + deltaDays)).toISOString().slice(0, 10);
      const cleaned = validateIntakePayload({
        ...r,
        intake_date: shifted,
        is_sample: true,
      });
      stmt.run(
        cleaned.quantity_ml,
        cleaned.original_quantity,
        cleaned.original_unit,
        cleaned.category,
        cleaned.description,
        cleaned.intake_date,
        cleaned.intake_time,
        now,
        now,
      );
      inserted += 1;
    }
    db.exec('COMMIT');
    syncExchangeFiles();
    return { loaded_count: inserted };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export function clearSampleDataset() {
  const db = getDb();
  const info = db.prepare('DELETE FROM intake_records WHERE is_sample = 1').run();
  syncExchangeFiles();
  return { deleted_count: Number(info.changes ?? 0) };
}

export function resetAllData() {
  const db = getDb();
  const info = db.prepare('DELETE FROM intake_records').run();
  syncExchangeFiles();
  return { deleted_count: Number(info.changes ?? 0) };
}

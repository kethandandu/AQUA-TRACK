function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function renderChartSvg(
  chartType: string,
  analyticsData: Record<string, unknown>,
  dailyTargetMl: number,
): string {
  const width = 900;
  const height = 460;
  const padL = 78;
  const padR = 36;
  const padT = 66;
  const padB = 64;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;

  const titles: Record<string, string> = {
    daily: 'AquaTrack — Daily Water Consumption Trend (ml)',
    weekly: 'AquaTrack — 7-Day Consumption Comparison (ml)',
    monthly: 'AquaTrack — Monthly Consumption Overview (ml)',
    target_vs_actual: 'AquaTrack — Target vs Actual Consumption (ml)',
    category: 'AquaTrack — Water Intake Distribution by Category',
  };
  const title = titles[chartType] ?? 'AquaTrack — Hydration Chart';

  let body = '';

  if (chartType === 'category') {
    const breakdown = (analyticsData.category_breakdown as Array<{ category: string; total_ml: number }>) ?? [];
    if (breakdown.length === 0) {
      body = `<text x="${width / 2}" y="${height / 2}" text-anchor="middle" fill="#64748b" font-size="14">No category records available for this period</text>`;
    } else {
      const total = breakdown.reduce((s, b) => s + b.total_ml, 0) || 1;
      const maxVal = Math.max(...breakdown.map((b) => b.total_ml), 100);
      const colors = ['#0284c7', '#0ea5e9', '#06b6d4', '#14b8a6', '#16a34a', '#6366f1', '#8b5cf6', '#64748b'];
      const barH = Math.min(34, Math.floor(plotH / Math.max(breakdown.length, 1)) - 8);
      breakdown.forEach((item, idx) => {
        const y = padT + idx * (barH + 10);
        const w = Math.max(4, (item.total_ml / maxVal) * (plotW - 180));
        const pct = ((item.total_ml / total) * 100).toFixed(1);
        const color = colors[idx % colors.length];
        body += `
          <text x="${padL - 10}" y="${y + barH / 2 + 4}" text-anchor="end" fill="#334155" font-size="12" font-weight="500">${escapeXml(item.category)}</text>
          <rect x="${padL}" y="${y}" width="${w.toFixed(1)}" height="${barH}" rx="4" fill="${color}" />
          <text x="${padL + w + 10}" y="${y + barH / 2 + 4}" fill="#0f172a" font-size="12" font-family="monospace">${Math.round(item.total_ml)} ml (${pct}%)</text>
        `;
      });
    }
  } else if (chartType === 'daily') {
    const timeline = (analyticsData.hourly_timeline as Array<{ label: string; cumulative_ml: number; total_ml: number }>) ?? [];
    const maxVal = Math.max(dailyTargetMl * 1.15, ...timeline.map((t) => t.cumulative_ml), 500);
    // Grid & Y ticks
    for (let i = 0; i <= 4; i++) {
      const val = Math.round((maxVal * i) / 4);
      const y = padT + plotH - (i / 4) * plotH;
      body += `
        <line x1="${padL}" y1="${y}" x2="${padL + plotW}" y2="${y}" stroke="#e2e8f0" stroke-dasharray="4 4" />
        <text x="${padL - 10}" y="${y + 4}" text-anchor="end" fill="#64748b" font-size="11" font-family="monospace">${val}</text>
      `;
    }
    const targetY = padT + plotH - (dailyTargetMl / maxVal) * plotH;
    body += `
      <line x1="${padL}" y1="${targetY}" x2="${padL + plotW}" y2="${targetY}" stroke="#d97706" stroke-width="1.6" stroke-dasharray="6 4" />
      <text x="${padL + plotW - 4}" y="${targetY - 6}" text-anchor="end" fill="#b45309" font-size="11" font-weight="600">Target ${Math.round(dailyTargetMl)} ml</text>
    `;
    if (timeline.length === 0) {
      body += `<text x="${width / 2}" y="${padT + plotH / 2}" text-anchor="middle" fill="#64748b" font-size="13">No entries logged for selected date</text>`;
    } else {
      const pts = timeline.map((pt, idx) => {
        const x = timeline.length === 1 ? padL + plotW / 2 : padL + (idx / (timeline.length - 1)) * plotW;
        const y = padT + plotH - (pt.cumulative_ml / maxVal) * plotH;
        return { x, y, label: pt.label, val: pt.cumulative_ml };
      });
      const polyPts = pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
      if (pts.length > 1) {
        body += `<polyline fill="none" stroke="#0284c7" stroke-width="2.5" points="${polyPts}" />`;
      }
      pts.forEach((p) => {
        body += `
          <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4.5" fill="#0284c7" stroke="#ffffff" stroke-width="1.5" />
          <text x="${p.x.toFixed(1)}" y="${padT + plotH + 18}" text-anchor="middle" fill="#475569" font-size="10" font-family="monospace">${escapeXml(p.label)}</text>
        `;
      });
    }
  } else {
    const series = (analyticsData.daily_series as Array<{ label: string; total_ml: number; target_ml: number; achieved: boolean }>) ?? [];
    const maxVal = Math.max(dailyTargetMl * 1.15, ...series.map((s) => s.total_ml), 500);
    for (let i = 0; i <= 4; i++) {
      const val = Math.round((maxVal * i) / 4);
      const y = padT + plotH - (i / 4) * plotH;
      body += `
        <line x1="${padL}" y1="${y}" x2="${padL + plotW}" y2="${y}" stroke="#e2e8f0" stroke-dasharray="4 4" />
        <text x="${padL - 10}" y="${y + 4}" text-anchor="end" fill="#64748b" font-size="11" font-family="monospace">${val}</text>
      `;
    }
    const targetY = padT + plotH - (dailyTargetMl / maxVal) * plotH;
    body += `
      <line x1="${padL}" y1="${targetY}" x2="${padL + plotW}" y2="${targetY}" stroke="#d97706" stroke-width="1.6" stroke-dasharray="6 4" />
      <text x="${padL + plotW - 4}" y="${targetY - 6}" text-anchor="end" fill="#b45309" font-size="11" font-weight="600">Target ${Math.round(dailyTargetMl)} ml</text>
    `;
    const slotW = plotW / Math.max(series.length, 1);
    series.forEach((item, idx) => {
      if (chartType === 'target_vs_actual') {
        const bw = Math.max(6, Math.min(20, slotW * 0.34));
        const cx = padL + idx * slotW + slotW / 2;
        const hActual = (item.total_ml / maxVal) * plotH;
        const hTarget = (dailyTargetMl / maxVal) * plotH;
        body += `
          <rect x="${(cx - bw - 1).toFixed(1)}" y="${(padT + plotH - hActual).toFixed(1)}" width="${bw.toFixed(1)}" height="${hActual.toFixed(1)}" rx="3" fill="#0284c7" />
          <rect x="${(cx + 1).toFixed(1)}" y="${(padT + plotH - hTarget).toFixed(1)}" width="${bw.toFixed(1)}" height="${hTarget.toFixed(1)}" rx="3" fill="#cbd5e1" />
        `;
      } else {
        const bw = Math.max(8, Math.min(42, slotW * 0.58));
        const x = padL + idx * slotW + (slotW - bw) / 2;
        const h = (item.total_ml / maxVal) * plotH;
        const fill = item.achieved ? '#16a34a' : '#0284c7';
        body += `<rect x="${x.toFixed(1)}" y="${(padT + plotH - h).toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="${fill}" />`;
      }
      if (series.length <= 14 || idx % 2 === 0) {
        body += `<text x="${(padL + idx * slotW + slotW / 2).toFixed(1)}" y="${padT + plotH + 18}" text-anchor="middle" fill="#475569" font-size="10">${escapeXml(item.label)}</text>`;
      }
    });
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <rect width="${width}" height="${height}" fill="#ffffff" />
  <rect x="${padL}" y="${padT}" width="${plotW}" height="${plotH}" fill="#f8fafc" rx="4" />
  <text x="${padL}" y="36" fill="#0f172a" font-family="system-ui, -apple-system, sans-serif" font-size="17" font-weight="700">${escapeXml(title)}</text>
  <line x1="${padL}" y1="${padT + plotH}" x2="${padL + plotW}" y2="${padT + plotH}" stroke="#cbd5e1" stroke-width="1" />
  <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${padT + plotH}" stroke="#cbd5e1" stroke-width="1" />
  ${body}
  <text x="${width - padR}" y="${height - 14}" text-anchor="end" fill="#64748b" font-family="system-ui, sans-serif" font-size="10">Generated from live SQLite records · AquaTrack</text>
</svg>`;
}

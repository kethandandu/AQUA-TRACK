export const ALLOWED_CATEGORIES = [
  'Morning',
  'Breakfast',
  'Lunch',
  'Afternoon',
  'Evening',
  'Dinner',
  'Before Sleep',
  'Other',
] as const;

export const ALLOWED_UNITS = ['ml', 'l'] as const;

export const MAX_SINGLE_ENTRY_ML = 10000;
export const MIN_SINGLE_ENTRY_ML = 1;
export const MIN_DAILY_TARGET_ML = 500;
export const MAX_DAILY_TARGET_ML = 10000;
export const MAX_DESCRIPTION_LEN = 240;

export type AllowedCategory = (typeof ALLOWED_CATEGORIES)[number];
export type AllowedUnit = (typeof ALLOWED_UNITS)[number];

export interface FieldError {
  field: string;
  message: string;
}

export class ValidationError extends Error {
  fieldErrors: FieldError[];

  constructor(message: string, fieldErrors: FieldError[] = []) {
    super(message);
    this.name = 'ValidationError';
    this.fieldErrors = fieldErrors;
  }
}

export interface ValidatedIntake {
  quantity_ml: number;
  original_quantity: number;
  original_unit: AllowedUnit;
  category: AllowedCategory;
  description: string;
  intake_date: string;
  intake_time: string;
  is_sample: number;
}

export function isValidIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [yStr, mStr, dStr] = value.split('-');
  const y = Number(yStr);
  const m = Number(mStr);
  const d = Number(dStr);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

export function isValidTime24(value: string): boolean {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(value);
}

export function convertToMl(quantity: number, unit: string): number {
  const normalized = unit.trim().toLowerCase();
  if (normalized === 'l') return Math.round(quantity * 1000 * 100) / 100;
  if (normalized === 'ml') return Math.round(quantity * 100) / 100;
  throw new ValidationError(`Unsupported measurement unit '${unit}'.`, [
    { field: 'unit', message: "Measurement unit must be 'ml' or 'l'." },
  ]);
}

export function parsePositiveNumber(raw: unknown, field: string): number {
  if (raw === null || raw === undefined || (typeof raw === 'string' && raw.trim() === '')) {
    throw new ValidationError(`${field} is required and cannot be empty.`, [
      { field, message: 'Field cannot be empty.' },
    ]);
  }
  if (typeof raw === 'boolean') {
    throw new ValidationError(`${field} must be a numeric value.`, [
      { field, message: 'Boolean values are not valid numbers.' },
    ]);
  }
  const num = Number(raw);
  if (!Number.isFinite(num)) {
    throw new ValidationError(`${field} must be a valid number.`, [
      { field, message: 'Enter numbers only (no letters or symbols).' },
    ]);
  }
  if (num <= 0) {
    throw new ValidationError(`${field} must be greater than zero.`, [
      { field, message: 'Value must be greater than 0.' },
    ]);
  }
  return num;
}

export function validateIntakePayload(payload: unknown): ValidatedIntake {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new ValidationError('Request payload must be a JSON object.');
  }
  const body = payload as Record<string, unknown>;
  const errors: FieldError[] = [];

  let qtyVal: number | null = null;
  try {
    qtyVal = parsePositiveNumber(body.quantity, 'quantity');
  } catch (err) {
    if (err instanceof ValidationError) errors.push(...err.fieldErrors);
  }

  let unitVal: AllowedUnit | null = null;
  if (typeof body.unit !== 'string' || !ALLOWED_UNITS.includes(body.unit.trim().toLowerCase() as AllowedUnit)) {
    errors.push({ field: 'unit', message: "Measurement unit must be 'ml' or 'l'." });
  } else {
    unitVal = body.unit.trim().toLowerCase() as AllowedUnit;
  }

  let qtyMl = 0;
  if (qtyVal !== null && unitVal !== null) {
    qtyMl = convertToMl(qtyVal, unitVal);
    if (qtyMl < MIN_SINGLE_ENTRY_ML) {
      errors.push({ field: 'quantity', message: `Quantity must be at least ${MIN_SINGLE_ENTRY_ML} ml.` });
    } else if (qtyMl > MAX_SINGLE_ENTRY_ML) {
      errors.push({
        field: 'quantity',
        message: `Single entry cannot exceed ${MAX_SINGLE_ENTRY_ML} ml (10 L).`,
      });
    }
  }

  let catVal: AllowedCategory | null = null;
  if (typeof body.category !== 'string' || !ALLOWED_CATEGORIES.includes(body.category.trim() as AllowedCategory)) {
    errors.push({
      field: 'category',
      message: `Category must be one of: ${ALLOWED_CATEGORIES.join(', ')}.`,
    });
  } else {
    catVal = body.category.trim() as AllowedCategory;
  }

  let dateVal = '';
  if (typeof body.intake_date !== 'string' || !body.intake_date.trim()) {
    errors.push({ field: 'intake_date', message: 'Date is required (YYYY-MM-DD).' });
  } else {
    const trimmed = body.intake_date.trim();
    if (!isValidIsoDate(trimmed)) {
      errors.push({ field: 'intake_date', message: `Invalid calendar date '${trimmed}'. Use YYYY-MM-DD.` });
    } else {
      const tomorrow = new Date();
      tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
      const maxIso = tomorrow.toISOString().slice(0, 10);
      if (trimmed > maxIso) {
        errors.push({ field: 'intake_date', message: 'Date cannot be more than 1 day in the future.' });
      } else if (Number(trimmed.slice(0, 4)) < 2000) {
        errors.push({ field: 'intake_date', message: 'Date year must be 2000 or later.' });
      } else {
        dateVal = trimmed;
      }
    }
  }

  let timeVal = '';
  if (typeof body.intake_time !== 'string' || !body.intake_time.trim()) {
    errors.push({ field: 'intake_time', message: 'Time is required (HH:MM).' });
  } else {
    const trimmed = body.intake_time.trim();
    if (!isValidTime24(trimmed)) {
      errors.push({ field: 'intake_time', message: 'Time must be in 24-hour HH:MM format (00:00 to 23:59).' });
    } else {
      timeVal = trimmed;
    }
  }

  let descVal = '';
  if (body.description !== undefined && body.description !== null) {
    if (typeof body.description !== 'string') {
      errors.push({ field: 'description', message: 'Description must be text.' });
    } else if (body.description.trim().length > MAX_DESCRIPTION_LEN) {
      errors.push({
        field: 'description',
        message: `Description cannot exceed ${MAX_DESCRIPTION_LEN} characters.`,
      });
    } else {
      descVal = body.description.trim();
    }
  }

  if (errors.length > 0 || qtyVal === null || unitVal === null || catVal === null) {
    throw new ValidationError(errors[0]?.message ?? 'Invalid intake input.', errors);
  }

  return {
    quantity_ml: qtyMl,
    original_quantity: Math.round(qtyVal * 1000) / 1000,
    original_unit: unitVal,
    category: catVal,
    description: descVal,
    intake_date: dateVal,
    intake_time: timeVal,
    is_sample: body.is_sample ? 1 : 0,
  };
}

export function validateSettingsPayload(payload: unknown): Record<string, unknown> {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new ValidationError('Settings payload must be a JSON object.');
  }
  const body = payload as Record<string, unknown>;
  const errors: FieldError[] = [];
  const cleaned: Record<string, unknown> = {};

  if ('daily_target_ml' in body && body.daily_target_ml !== undefined) {
    try {
      const target = parsePositiveNumber(body.daily_target_ml, 'daily_target_ml');
      if (target < MIN_DAILY_TARGET_ML || target > MAX_DAILY_TARGET_ML) {
        errors.push({
          field: 'daily_target_ml',
          message: `Daily target must be between ${MIN_DAILY_TARGET_ML} ml and ${MAX_DAILY_TARGET_ML} ml.`,
        });
      } else {
        cleaned.daily_target_ml = Math.round(target * 100) / 100;
      }
    } catch (err) {
      if (err instanceof ValidationError) errors.push(...err.fieldErrors);
    }
  }

  if ('preferred_unit' in body && body.preferred_unit !== undefined) {
    if (
      typeof body.preferred_unit !== 'string' ||
      !ALLOWED_UNITS.includes(body.preferred_unit.trim().toLowerCase() as AllowedUnit)
    ) {
      errors.push({ field: 'preferred_unit', message: "Preferred unit must be 'ml' or 'l'." });
    } else {
      cleaned.preferred_unit = body.preferred_unit.trim().toLowerCase();
    }
  }

  if ('high_single_entry_threshold_ml' in body && body.high_single_entry_threshold_ml !== undefined) {
    try {
      const val = parsePositiveNumber(body.high_single_entry_threshold_ml, 'high_single_entry_threshold_ml');
      if (val < 500 || val > 5000) {
        errors.push({
          field: 'high_single_entry_threshold_ml',
          message: 'Single-entry threshold must be between 500 ml and 5000 ml.',
        });
      } else {
        cleaned.high_single_entry_threshold_ml = Math.round(val * 100) / 100;
      }
    } catch (err) {
      if (err instanceof ValidationError) errors.push(...err.fieldErrors);
    }
  }

  if ('high_daily_total_threshold_ml' in body && body.high_daily_total_threshold_ml !== undefined) {
    try {
      const val = parsePositiveNumber(body.high_daily_total_threshold_ml, 'high_daily_total_threshold_ml');
      if (val < 2000 || val > 15000) {
        errors.push({
          field: 'high_daily_total_threshold_ml',
          message: 'Daily high-volume threshold must be between 2000 ml and 15000 ml.',
        });
      } else {
        cleaned.high_daily_total_threshold_ml = Math.round(val * 100) / 100;
      }
    } catch (err) {
      if (err instanceof ValidationError) errors.push(...err.fieldErrors);
    }
  }

  if ('reminder_interval_hours' in body && body.reminder_interval_hours !== undefined) {
    try {
      const val = Math.round(parsePositiveNumber(body.reminder_interval_hours, 'reminder_interval_hours'));
      if (val < 1 || val > 12) {
        errors.push({
          field: 'reminder_interval_hours',
          message: 'Reminder interval must be between 1 and 12 hours.',
        });
      } else {
        cleaned.reminder_interval_hours = val;
      }
    } catch (err) {
      if (err instanceof ValidationError) errors.push(...err.fieldErrors);
    }
  }

  if ('dark_mode' in body && body.dark_mode !== undefined) {
    cleaned.dark_mode = body.dark_mode ? 1 : 0;
  }

  if (errors.length > 0) {
    throw new ValidationError(errors[0]?.message ?? 'Invalid settings input.', errors);
  }

  return cleaned;
}

import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

export const DATA_DIR = path.resolve(process.cwd(), 'data');
export const DB_PATH = path.join(DATA_DIR, 'aquatrack.db');
export const BACKUP_JSON_PATH = path.join(DATA_DIR, 'records_backup.json');
export const BACKUP_CSV_PATH = path.join(DATA_DIR, 'records_backup.csv');

export interface IntakeRecord {
  id: number;
  quantity_ml: number;
  original_quantity: number;
  original_unit: 'ml' | 'l';
  category: string;
  description: string;
  intake_date: string;
  intake_time: string;
  is_sample: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  daily_target_ml: number;
  preferred_unit: 'ml' | 'l';
  high_single_entry_threshold_ml: number;
  high_daily_total_threshold_ml: number;
  reminder_interval_hours: number;
  dark_mode: boolean;
  updated_at: string;
}

export interface StorageHealthStatus {
  sqlite_ok: boolean;
  json_backup_ok: boolean;
  csv_backup_ok: boolean;
  warnings: string[];
}

let dbInstance: DatabaseSync | null = null;
const storageWarnings: string[] = [];

export function utcNowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function ensureInitialBackupFiles(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(BACKUP_JSON_PATH)) {
    fs.writeFileSync(BACKUP_JSON_PATH, JSON.stringify({ records: [] }, null, 2), 'utf-8');
  } else {
    try {
      const raw = fs.readFileSync(BACKUP_JSON_PATH, 'utf-8');
      if (!raw.trim()) throw new Error('Empty JSON file');
      JSON.parse(raw);
    } catch {
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const corruptCopy = path.join(DATA_DIR, `records_backup.json.corrupted.${stamp}`);
      try {
        fs.copyFileSync(BACKUP_JSON_PATH, corruptCopy);
      } catch {
        // Ignore copy errors if unreadable
      }
      storageWarnings.push(
        `Recovered from corrupted JSON backup file (preserved original as ${path.basename(corruptCopy)}).`,
      );
    }
  }

  if (!fs.existsSync(BACKUP_CSV_PATH)) {
    fs.writeFileSync(
      BACKUP_CSV_PATH,
      'intake_date,intake_time,quantity,unit,category,description\n',
      'utf-8',
    );
  }
}

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');

  db.exec(`
    CREATE TABLE IF NOT EXISTS intake_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quantity_ml REAL NOT NULL CHECK(quantity_ml > 0 AND quantity_ml <= 10000),
      original_quantity REAL NOT NULL CHECK(original_quantity > 0),
      original_unit TEXT NOT NULL CHECK(original_unit IN ('ml', 'l')),
      category TEXT NOT NULL CHECK(category IN (
        'Morning', 'Breakfast', 'Lunch', 'Afternoon',
        'Evening', 'Dinner', 'Before Sleep', 'Other'
      )),
      description TEXT NOT NULL DEFAULT '',
      intake_date TEXT NOT NULL,
      intake_time TEXT NOT NULL,
      is_sample INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_intake_records_date
      ON intake_records (intake_date DESC, intake_time DESC);

    CREATE INDEX IF NOT EXISTS idx_intake_records_category
      ON intake_records (category);

    CREATE TABLE IF NOT EXISTS user_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      daily_target_ml REAL NOT NULL DEFAULT 2500 CHECK(daily_target_ml >= 500 AND daily_target_ml <= 10000),
      preferred_unit TEXT NOT NULL DEFAULT 'ml' CHECK(preferred_unit IN ('ml', 'l')),
      high_single_entry_threshold_ml REAL NOT NULL DEFAULT 1500,
      high_daily_total_threshold_ml REAL NOT NULL DEFAULT 5000,
      reminder_interval_hours INTEGER NOT NULL DEFAULT 2,
      dark_mode INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  const now = utcNowIso();
  db.prepare(`
    INSERT OR IGNORE INTO user_settings (
      id, daily_target_ml, preferred_unit,
      high_single_entry_threshold_ml, high_daily_total_threshold_ml,
      reminder_interval_hours, dark_mode, created_at, updated_at
    ) VALUES (1, 2500, 'ml', 1500, 5000, 2, 0, ?, ?)
  `).run(now, now);

  ensureInitialBackupFiles();
  dbInstance = db;
  return db;
}

export function rowToRecord(row: Record<string, unknown>): IntakeRecord {
  return {
    id: Number(row.id),
    quantity_ml: Number(row.quantity_ml),
    original_quantity: Number(row.original_quantity),
    original_unit: String(row.original_unit) as 'ml' | 'l',
    category: String(row.category),
    description: String(row.description ?? ''),
    intake_date: String(row.intake_date),
    intake_time: String(row.intake_time),
    is_sample: Boolean(row.is_sample),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

function escapeCsvCell(val: unknown): string {
  const s = String(val ?? '');
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function syncExchangeFiles(): void {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM intake_records ORDER BY intake_date DESC, intake_time DESC, id DESC')
    .all() as Record<string, unknown>[];
  const records = rows.map(rowToRecord);

  const jsonTmp = `${BACKUP_JSON_PATH}.tmp`;
  fs.writeFileSync(jsonTmp, JSON.stringify({ records }, null, 2), 'utf-8');
  fs.renameSync(jsonTmp, BACKUP_JSON_PATH);

  const csvLines = ['intake_date,intake_time,quantity,unit,category,description'];
  for (const r of records) {
    csvLines.push(
      [
        r.intake_date,
        r.intake_time,
        r.original_quantity,
        r.original_unit,
        r.category,
        r.description,
      ]
        .map(escapeCsvCell)
        .join(','),
    );
  }
  const csvTmp = `${BACKUP_CSV_PATH}.tmp`;
  fs.writeFileSync(csvTmp, `${csvLines.join('\n')}\n`, 'utf-8');
  fs.renameSync(csvTmp, BACKUP_CSV_PATH);
}

export function getSettings(): UserSettings {
  const db = getDb();
  const row = db.prepare('SELECT * FROM user_settings WHERE id = 1').get() as Record<string, unknown>;
  return {
    daily_target_ml: Number(row.daily_target_ml),
    preferred_unit: String(row.preferred_unit) as 'ml' | 'l',
    high_single_entry_threshold_ml: Number(row.high_single_entry_threshold_ml),
    high_daily_total_threshold_ml: Number(row.high_daily_total_threshold_ml),
    reminder_interval_hours: Number(row.reminder_interval_hours),
    dark_mode: Boolean(row.dark_mode),
    updated_at: String(row.updated_at),
  };
}

export function getStorageStatus(): StorageHealthStatus {
  let sqliteOk = true;
  let jsonOk = true;
  let csvOk = true;
  try {
    getDb().prepare('SELECT 1').get();
  } catch {
    sqliteOk = false;
  }
  try {
    JSON.parse(fs.readFileSync(BACKUP_JSON_PATH, 'utf-8'));
  } catch {
    jsonOk = false;
  }
  try {
    fs.accessSync(BACKUP_CSV_PATH, fs.constants.R_OK);
  } catch {
    csvOk = false;
  }
  return {
    sqlite_ok: sqliteOk,
    json_backup_ok: jsonOk,
    csv_backup_ok: csvOk,
    warnings: [...storageWarnings],
  };
}

import { getDb, getSettings, rowToRecord, type IntakeRecord } from './storage.ts';
import { isValidIsoDate } from './validation.ts';

export interface WarningItem {
  code: string;
  severity: 'info' | 'warning' | 'error';
  title: string;
  message: string;
  basis: string;
}

export function localTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function addDaysIso(iso: string, delta: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + delta));
  return dt.toISOString().slice(0, 10);
}

function formatDayLabel(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return `${weekdays[dt.getUTCDay()]} ${String(d).padStart(2, '0')}`;
}

export function classifyStatus(totalMl: number, targetMl: number): string {
  if (totalMl < targetMl) return 'Below target';
  if (Math.abs(totalMl - targetMl) < 1e-6) return 'Target achieved';
  return 'Above target';
}

export function evaluateWarnings(dateStr: string): WarningItem[] {
  const db = getDb();
  const settings = getSettings();
  const rows = db
    .prepare('SELECT * FROM intake_records WHERE intake_date = ? ORDER BY intake_time ASC, id ASC')
    .all(dateStr) as Record<string, unknown>[];
  const records = rows.map(rowToRecord);
  const warnings: WarningItem[] = [];

  const totalMl = records.reduce((acc, r) => acc + r.quantity_ml, 0);

  if (records.length === 0) {
    warnings.push({
      code: 'NO_ENTRIES_TODAY',
      severity: 'info',
      title: 'No entries logged for selected date',
      message: `No water intake entries recorded for ${dateStr} yet. Your configured daily target is ${Math.round(settings.daily_target_ml)} ml.`,
      basis: `Configured daily target: ${Math.round(settings.daily_target_ml)} ml`,
    });
  } else if (totalMl < settings.daily_target_ml) {
    const remaining = Math.round(settings.daily_target_ml - totalMl);
    warnings.push({
      code: 'BELOW_DAILY_TARGET',
      severity: 'warning',
      title: 'Daily target not yet reached',
      message: `You have logged ${Math.round(totalMl)} ml of your ${Math.round(settings.daily_target_ml)} ml target (${remaining} ml remaining).`,
      basis: `Compared against configured daily target (${Math.round(settings.daily_target_ml)} ml)`,
    });
  }

  if (totalMl >= settings.high_daily_total_threshold_ml) {
    warnings.push({
      code: 'HIGH_DAILY_TOTAL',
      severity: 'warning',
      title: 'Unusually high daily intake total',
      message: `Total recorded intake for ${dateStr} is ${Math.round(totalMl)} ml, above your configured high-daily threshold.`,
      basis: `Configured high-daily threshold: ${Math.round(settings.high_daily_total_threshold_ml)} ml`,
    });
  }

  for (const r of records) {
    if (r.quantity_ml >= settings.high_single_entry_threshold_ml) {
      warnings.push({
        code: 'HIGH_SINGLE_ENTRY',
        severity: 'warning',
        title: 'Unusually large single entry',
        message: `Entry #${r.id} at ${r.intake_time} recorded ${Math.round(r.quantity_ml)} ml (${r.category}). Verify that this amount was intended.`,
        basis: `Configured single-entry threshold: ${Math.round(settings.high_single_entry_threshold_ml)} ml`,
      });
    }
  }

  for (let i = 1; i < records.length; i++) {
    const prev = records[i - 1];
    const curr = records[i];
    const [h1, m1] = prev.intake_time.split(':').map(Number);
    const [h2, m2] = curr.intake_time.split(':').map(Number);
    const diffMin = Math.abs(h2 * 60 + m2 - (h1 * 60 + m1));
    if (diffMin <= 2 && Math.abs(prev.quantity_ml - curr.quantity_ml) < 1e-6) {
      warnings.push({
        code: 'POSSIBLE_DUPLICATE_ENTRY',
        severity: 'info',
        title: 'Possible duplicate entry detected',
        message: `Entries #${prev.id} (${prev.intake_time}) and #${curr.id} (${curr.intake_time}) both logged ${Math.round(curr.quantity_ml)} ml within ${diffMin} minute(s).`,
        basis: 'Anomaly rule: identical volume logged within 2 minutes',
      });
    }
  }

  return warnings;
}

export function getDailyAnalytics(dateParam?: string) {
  const dayStr = dateParam && dateParam.trim() ? dateParam.trim() : localTodayIso();
  if (!isValidIsoDate(dayStr)) {
    throw new Error(`Invalid date '${dayStr}'. Expected YYYY-MM-DD.`);
  }
  const db = getDb();
  const settings = getSettings();
  const targetMl = settings.daily_target_ml;

  const rows = db
    .prepare('SELECT * FROM intake_records WHERE intake_date = ? ORDER BY intake_time ASC, id ASC')
    .all(dayStr) as Record<string, unknown>[];
  const records = rows.map(rowToRecord);

  const totalMl = Math.round(records.reduce((s, r) => s + r.quantity_ml, 0) * 100) / 100;
  const entryCount = records.length;
  const remainingMl = Math.round(Math.max(0, targetMl - totalMl) * 100) / 100;
  const completionPct = targetMl > 0 ? Math.round((totalMl / targetMl) * 1000) / 10 : 0;
  const avgPerEntry = entryCount > 0 ? Math.round((totalMl / entryCount) * 10) / 10 : 0;

  const catMap = new Map<string, { category: string; total_ml: number; entries: number }>();
  const hourlyTimeline: Array<{ label: string; total_ml: number; cumulative_ml: number; category: string }> = [];
  let cumulative = 0;

  for (const r of records) {
    cumulative = Math.round((cumulative + r.quantity_ml) * 100) / 100;
    const prev = catMap.get(r.category) ?? { category: r.category, total_ml: 0, entries: 0 };
    prev.total_ml = Math.round((prev.total_ml + r.quantity_ml) * 100) / 100;
    prev.entries += 1;
    catMap.set(r.category, prev);

    hourlyTimeline.push({
      label: r.intake_time,
      total_ml: r.quantity_ml,
      cumulative_ml: cumulative,
      category: r.category,
    });
  }

  const categoryBreakdown = Array.from(catMap.values()).sort((a, b) => b.total_ml - a.total_ml);
  const sampleCountRow = db.prepare('SELECT COUNT(*) AS cnt FROM intake_records WHERE is_sample = 1').get() as { cnt: number };
  const totalCountRow = db.prepare('SELECT COUNT(*) AS cnt FROM intake_records').get() as { cnt: number };

  return {
    date: dayStr,
    daily_target_ml: targetMl,
    total_ml: totalMl,
    remaining_ml: remainingMl,
    completion_pct: completionPct,
    entry_count: entryCount,
    avg_per_entry_ml: avgPerEntry,
    status: classifyStatus(totalMl, targetMl),
    target_achieved: totalMl >= targetMl,
    category_breakdown: categoryBreakdown,
    hourly_timeline: hourlyTimeline,
    recent_entries: [...records].reverse().slice(0, 8),
    warnings: evaluateWarnings(dayStr),
    dataset_meta: {
      total_records: Number(totalCountRow.cnt),
      sample_records: Number(sampleCountRow.cnt),
      has_sample_data: Number(sampleCountRow.cnt) > 0,
    },
  };
}

export function getWeeklyAnalytics(endDateParam?: string) {
  const endStr = endDateParam && endDateParam.trim() ? endDateParam.trim() : localTodayIso();
  if (!isValidIsoDate(endStr)) {
    throw new Error(`Invalid end_date '${endStr}'. Expected YYYY-MM-DD.`);
  }
  const days = Array.from({ length: 7 }, (_, i) => addDaysIso(endStr, i - 6));
  const startStr = days[0];
  const prevEndStr = addDaysIso(endStr, -7);
  const prevStartStr = addDaysIso(prevEndStr, -6);

  const db = getDb();
  const settings = getSettings();
  const targetMl = settings.daily_target_ml;

  const rows = db
    .prepare(
      'SELECT intake_date, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY intake_date',
    )
    .all(startStr, endStr) as Array<{ intake_date: string; total_ml: number; entries: number }>;

  const prevRow = db
    .prepare('SELECT COALESCE(SUM(quantity_ml), 0) AS total_ml FROM intake_records WHERE intake_date BETWEEN ? AND ?')
    .get(prevStartStr, prevEndStr) as { total_ml: number };

  const catRows = db
    .prepare(
      'SELECT category, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY category ORDER BY total_ml DESC',
    )
    .all(startStr, endStr) as Array<{ category: string; total_ml: number; entries: number }>;

  const byDay = new Map<string, { total: number; entries: number }>();
  for (const r of rows) {
    byDay.set(r.intake_date, {
      total: Math.round(Number(r.total_ml) * 100) / 100,
      entries: Number(r.entries),
    });
  }

  const dailySeries = days.map((d) => {
    const entry = byDay.get(d);
    const total = entry ? entry.total : 0;
    return {
      date: d,
      label: formatDayLabel(d),
      total_ml: total,
      target_ml: targetMl,
      entries: entry ? entry.entries : 0,
      achieved: total >= targetMl,
    };
  });

  const totalWeekly = Math.round(dailySeries.reduce((s, d) => s + d.total_ml, 0) * 100) / 100;
  const dailyAverage = Math.round((totalWeekly / 7) * 10) / 10;
  const activeDaysList = dailySeries.filter((d) => d.total_ml > 0);
  const achievedDays = dailySeries.filter((d) => d.achieved).length;
  const freqPct = Math.round((achievedDays / 7) * 1000) / 10;

  const highest = activeDaysList.length
    ? activeDaysList.reduce((best, cur) => (cur.total_ml > best.total_ml ? cur : best))
    : null;
  const lowest = activeDaysList.length
    ? activeDaysList.reduce((best, cur) => (cur.total_ml < best.total_ml ? cur : best))
    : null;

  const prevTotal = Math.round(Number(prevRow.total_ml) * 100) / 100;
  const trendPct = prevTotal > 0 ? Math.round(((totalWeekly - prevTotal) / prevTotal) * 1000) / 10 : null;

  return {
    start_date: startStr,
    end_date: endStr,
    daily_target_ml: targetMl,
    total_ml: totalWeekly,
    daily_average_ml: dailyAverage,
    active_days: activeDaysList.length,
    target_achieved_days: achievedDays,
    target_achievement_frequency_pct: freqPct,
    highest_day: highest ? { date: highest.date, total_ml: highest.total_ml } : null,
    lowest_day: lowest ? { date: lowest.date, total_ml: lowest.total_ml } : null,
    previous_week_total_ml: prevTotal,
    trend_pct: trendPct,
    daily_series: dailySeries,
    category_breakdown: catRows.map((r) => ({
      category: r.category,
      total_ml: Math.round(Number(r.total_ml) * 100) / 100,
      entries: Number(r.entries),
    })),
  };
}

export function getMonthlyAnalytics(yearParam?: number, monthParam?: number) {
  const today = localTodayIso();
  const targetYear = yearParam ?? Number(today.slice(0, 4));
  const targetMonth = monthParam ?? Number(today.slice(5, 7));
  if (targetMonth < 1 || targetMonth > 12 || targetYear < 2000) {
    throw new Error('Invalid year or month parameter.');
  }

  const daysInMonth = new Date(Date.UTC(targetYear, targetMonth, 0)).getUTCDate();
  const ym = `${targetYear}-${String(targetMonth).padStart(2, '0')}`;
  const startStr = `${ym}-01`;
  const endStr = `${ym}-${String(daysInMonth).padStart(2, '0')}`;

  const prevYear = targetMonth === 1 ? targetYear - 1 : targetYear;
  const prevMonth = targetMonth === 1 ? 12 : targetMonth - 1;
  const prevDays = new Date(Date.UTC(prevYear, prevMonth, 0)).getUTCDate();
  const prevYm = `${prevYear}-${String(prevMonth).padStart(2, '0')}`;
  const prevStart = `${prevYm}-01`;
  const prevEnd = `${prevYm}-${String(prevDays).padStart(2, '0')}`;

  const db = getDb();
  const settings = getSettings();
  const targetMl = settings.daily_target_ml;

  const rows = db
    .prepare(
      'SELECT intake_date, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY intake_date',
    )
    .all(startStr, endStr) as Array<{ intake_date: string; total_ml: number; entries: number }>;

  const prevRow = db
    .prepare(
      'SELECT COALESCE(SUM(quantity_ml), 0) AS total_ml, COUNT(DISTINCT intake_date) AS active_days FROM intake_records WHERE intake_date BETWEEN ? AND ?',
    )
    .get(prevStart, prevEnd) as { total_ml: number; active_days: number };

  const catRows = db
    .prepare(
      'SELECT category, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY category ORDER BY total_ml DESC',
    )
    .all(startStr, endStr) as Array<{ category: string; total_ml: number; entries: number }>;

  const byDay = new Map<string, { total: number; entries: number }>();
  for (const r of rows) {
    byDay.set(r.intake_date, {
      total: Math.round(Number(r.total_ml) * 100) / 100,
      entries: Number(r.entries),
    });
  }

  const dailySeries = Array.from({ length: daysInMonth }, (_, i) => {
    const dayNum = String(i + 1).padStart(2, '0');
    const d = `${ym}-${dayNum}`;
    const entry = byDay.get(d);
    const total = entry ? entry.total : 0;
    return {
      date: d,
      label: dayNum,
      total_ml: total,
      target_ml: targetMl,
      entries: entry ? entry.entries : 0,
      achieved: total >= targetMl,
    };
  });

  const totalMonthly = Math.round(dailySeries.reduce((s, d) => s + d.total_ml, 0) * 100) / 100;
  const activeList = dailySeries.filter((d) => d.total_ml > 0);
  const activeDays = activeList.length;
  const monthlyAvg = activeDays > 0 ? Math.round((totalMonthly / activeDays) * 10) / 10 : 0;
  const achievedDays = activeList.filter((d) => d.achieved).length;
  const ratePct = activeDays > 0 ? Math.round((achievedDays / activeDays) * 1000) / 10 : 0;

  const highest = activeList.length
    ? activeList.reduce((best, cur) => (cur.total_ml > best.total_ml ? cur : best))
    : null;
  const lowest = activeList.length
    ? activeList.reduce((best, cur) => (cur.total_ml < best.total_ml ? cur : best))
    : null;

  const prevTotal = Math.round(Number(prevRow.total_ml) * 100) / 100;
  const momDelta =
    prevTotal > 0 && activeDays > 0 ? Math.round(((totalMonthly - prevTotal) / prevTotal) * 1000) / 10 : null;

  return {
    year: targetYear,
    month: targetMonth,
    start_date: startStr,
    end_date: endStr,
    daily_target_ml: targetMl,
    total_ml: totalMonthly,
    monthly_average_ml: monthlyAvg,
    active_days: activeDays,
    days_in_month: daysInMonth,
    target_achieved_days: achievedDays,
    target_achievement_rate_pct: ratePct,
    highest_day: highest ? { date: highest.date, total_ml: highest.total_ml } : null,
    lowest_day: lowest ? { date: lowest.date, total_ml: lowest.total_ml } : null,
    previous_month_total_ml: prevTotal,
    previous_month_active_days: Number(prevRow.active_days),
    month_over_month_delta_pct: momDelta,
    daily_series: dailySeries,
    category_breakdown: catRows.map((r) => ({
      category: r.category,
      total_ml: Math.round(Number(r.total_ml) * 100) / 100,
      entries: Number(r.entries),
    })),
  };
}

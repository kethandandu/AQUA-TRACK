from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path
import sys
import tempfile
import unittest

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.database import init_db
from app.services.analytics_service import (
    get_daily_analytics,
    get_monthly_analytics,
    get_weekly_analytics,
)
from app.services.export_service import (
    export_csv_text,
    export_json_text,
    export_markdown_text,
    export_txt_audit,
)
from app.services.import_service import import_csv_content
from app.services.intake_service import (
    create_intake,
    delete_intake,
    get_intake_by_id,
    get_settings,
    list_intakes,
    update_intake,
    update_settings,
)
from app.services.validation_service import InputValidationError
from app.utils.file_handler import read_json_safe


class AquaTrackBackendTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp_dir.name) / "test_aquatrack.db"
        init_db(self.db_path)
        self.today = date.today().isoformat()
        self.yesterday = (date.today() - timedelta(days=1)).isoformat()

    def tearDown(self) -> None:
        self.tmp_dir.cleanup()

    def test_01_add_valid_intake_entry_with_unit_conversion(self) -> None:
        rec = create_intake(
            {
                "quantity": 0.5,
                "unit": "l",
                "category": "Morning",
                "description": "Morning bottle",
                "intake_date": self.today,
                "intake_time": "08:15",
            },
            db_path=self.db_path,
        )
        self.assertEqual(rec["quantity_ml"], 500.0)
        self.assertEqual(rec["original_unit"], "l")
        self.assertEqual(rec["category"], "Morning")

    def test_02_reject_negative_quantity(self) -> None:
        with self.assertRaises(InputValidationError):
            create_intake(
                {
                    "quantity": -250,
                    "unit": "ml",
                    "category": "Morning",
                    "intake_date": self.today,
                    "intake_time": "09:00",
                },
                db_path=self.db_path,
            )

    def test_03_reject_zero_quantity(self) -> None:
        with self.assertRaises(InputValidationError):
            create_intake(
                {
                    "quantity": 0,
                    "unit": "ml",
                    "category": "Lunch",
                    "intake_date": self.today,
                    "intake_time": "12:00",
                },
                db_path=self.db_path,
            )

    def test_04_reject_invalid_numeric_inputs(self) -> None:
        with self.assertRaises(InputValidationError):
            create_intake(
                {
                    "quantity": "abc",
                    "unit": "ml",
                    "category": "Lunch",
                    "intake_date": self.today,
                    "intake_time": "12:00",
                },
                db_path=self.db_path,
            )

    def test_05_edit_existing_record(self) -> None:
        rec = create_intake(
            {
                "quantity": 250,
                "unit": "ml",
                "category": "Morning",
                "intake_date": self.today,
                "intake_time": "08:00",
            },
            db_path=self.db_path,
        )
        updated = update_intake(
            rec["id"],
            {
                "quantity": 0.75,
                "unit": "l",
                "category": "Afternoon",
                "description": "Updated bottle",
                "intake_date": self.today,
                "intake_time": "14:30",
            },
            db_path=self.db_path,
        )
        self.assertIsNotNone(updated)
        self.assertEqual(updated["quantity_ml"], 750.0)
        self.assertEqual(updated["category"], "Afternoon")

    def test_06_delete_existing_record(self) -> None:
        rec = create_intake(
            {
                "quantity": 300,
                "unit": "ml",
                "category": "Evening",
                "intake_date": self.today,
                "intake_time": "18:00",
            },
            db_path=self.db_path,
        )
        self.assertTrue(delete_intake(rec["id"], db_path=self.db_path))
        self.assertIsNone(get_intake_by_id(rec["id"], db_path=self.db_path))

    def test_07_calculate_daily_totals_and_remaining(self) -> None:
        update_settings({"daily_target_ml": 2000}, db_path=self.db_path)
        create_intake({"quantity": 500, "unit": "ml", "category": "Morning", "intake_date": self.today, "intake_time": "08:00"}, db_path=self.db_path)
        create_intake({"quantity": 750, "unit": "ml", "category": "Lunch", "intake_date": self.today, "intake_time": "13:00"}, db_path=self.db_path)
        daily = get_daily_analytics(self.today, db_path=self.db_path)
        self.assertEqual(daily["total_ml"], 1250.0)
        self.assertEqual(daily["remaining_ml"], 750.0)
        self.assertEqual(daily["entry_count"], 2)

    def test_08_calculate_weekly_averages(self) -> None:
        create_intake({"quantity": 1400, "unit": "ml", "category": "Morning", "intake_date": self.today, "intake_time": "09:00"}, db_path=self.db_path)
        create_intake({"quantity": 700, "unit": "ml", "category": "Lunch", "intake_date": self.yesterday, "intake_time": "12:00"}, db_path=self.db_path)
        weekly = get_weekly_analytics(self.today, db_path=self.db_path)
        self.assertEqual(weekly["total_ml"], 2100.0)
        self.assertEqual(weekly["daily_average_ml"], 300.0)
        self.assertEqual(weekly["highest_day"]["total_ml"], 1400.0)

    def test_09_calculate_monthly_averages(self) -> None:
        today_d = date.today()
        create_intake({"quantity": 1500, "unit": "ml", "category": "Morning", "intake_date": self.today, "intake_time": "09:00"}, db_path=self.db_path)
        monthly = get_monthly_analytics(today_d.year, today_d.month, db_path=self.db_path)
        self.assertEqual(monthly["total_ml"], 1500.0)
        self.assertEqual(monthly["active_days"], 1)
        self.assertEqual(monthly["monthly_average_ml"], 1500.0)

    def test_10_calculate_completion_percentages(self) -> None:
        update_settings({"daily_target_ml": 2500}, db_path=self.db_path)
        create_intake({"quantity": 1500, "unit": "ml", "category": "Afternoon", "intake_date": self.today, "intake_time": "15:00"}, db_path=self.db_path)
        daily = get_daily_analytics(self.today, db_path=self.db_path)
        self.assertEqual(daily["completion_pct"], 60.0)
        self.assertEqual(daily["status"], "Below target")

    def test_11_and_12_persistence_across_restarts(self) -> None:
        create_intake({"quantity": 600, "unit": "ml", "category": "Breakfast", "intake_date": self.today, "intake_time": "08:30"}, db_path=self.db_path)
        update_settings({"daily_target_ml": 3000}, db_path=self.db_path)
        # Re-initialize DB connection simulating app restart
        init_db(self.db_path)
        listing = list_intakes(db_path=self.db_path)
        settings = get_settings(db_path=self.db_path)
        self.assertEqual(listing["pagination"]["total_records"], 1)
        self.assertEqual(listing["records"][0]["quantity_ml"], 600.0)
        self.assertEqual(settings["daily_target_ml"], 3000.0)

    def test_13_handle_missing_storage_file(self) -> None:
        missing_json = Path(self.tmp_dir.name) / "missing_backup.json"
        data, warning = read_json_safe(missing_json, lambda: {"records": []})
        self.assertIsNone(warning)
        self.assertEqual(data, {"records": []})
        self.assertTrue(missing_json.exists())

    def test_14_handle_corrupted_json_file_without_destroying_data(self) -> None:
        corrupt_json = Path(self.tmp_dir.name) / "corrupt.json"
        corrupt_json.write_text("{bad json: [", encoding="utf-8")
        data, warning = read_json_safe(corrupt_json, lambda: {"records": []})
        self.assertIsNotNone(warning)
        self.assertEqual(data, {"records": []})
        backups = list(Path(self.tmp_dir.name).glob("corrupt.json.corrupted.*"))
        self.assertEqual(len(backups), 1)

    def test_15_import_valid_csv_records(self) -> None:
        csv_data = (
            "intake_date,intake_time,quantity,unit,category,description\n"
            f"{self.today},08:00,300,ml,Morning,Glass 1\n"
            f"{self.today},12:30,0.5,l,Lunch,Bottle 2\n"
        )
        result = import_csv_content(csv_data, db_path=self.db_path)
        self.assertTrue(result["success"])
        self.assertEqual(result["imported_count"], 2)
        self.assertEqual(result["rejected_count"], 0)

    def test_16_reject_invalid_and_duplicate_csv_records(self) -> None:
        csv_data = (
            "intake_date,intake_time,quantity,unit,category,description\n"
            f"{self.today},08:00,300,ml,Morning,Valid 1\n"
            f"{self.today},08:00,300,ml,Morning,Duplicate row\n"
            f"{self.today},09:00,-100,ml,Morning,Negative qty\n"
            f"{self.today},10:00,abc,ml,Lunch,Non-numeric\n"
            f"2026-02-30,11:00,250,ml,Lunch,Bad calendar date\n"
        )
        result = import_csv_content(csv_data, db_path=self.db_path)
        self.assertEqual(result["imported_count"], 1)
        self.assertEqual(result["duplicate_count"], 1)
        self.assertEqual(result["rejected_count"], 3)
        self.assertEqual(len(result["errors"]), 4)

    def test_17_generate_all_export_formats(self) -> None:
        create_intake({"quantity": 500, "unit": "ml", "category": "Lunch", "intake_date": self.today, "intake_time": "12:15", "description": "Export test"}, db_path=self.db_path)
        csv_out = export_csv_text(db_path=self.db_path)
        json_out = export_json_text(db_path=self.db_path)
        md_out = export_markdown_text(db_path=self.db_path)
        txt_out = export_txt_audit(db_path=self.db_path)
        self.assertIn("Export test", csv_out)
        self.assertIn("AquaTrack", json_out)
        self.assertIn("# AquaTrack", md_out)
        self.assertIn("AQUATRACK - WATER INTAKE AUDIT LOG", txt_out)

    def test_18_handle_empty_database(self) -> None:
        daily = get_daily_analytics(self.today, db_path=self.db_path)
        weekly = get_weekly_analytics(self.today, db_path=self.db_path)
        today_d = date.today()
        monthly = get_monthly_analytics(today_d.year, today_d.month, db_path=self.db_path)
        self.assertEqual(daily["total_ml"], 0.0)
        self.assertEqual(daily["completion_pct"], 0.0)
        self.assertEqual(weekly["total_ml"], 0.0)
        self.assertIsNone(weekly["highest_day"])
        self.assertEqual(monthly["active_days"], 0)


if __name__ == "__main__":
    unittest.main()

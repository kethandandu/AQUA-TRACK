# AquaTrack — Python FastAPI Backend

## Overview
Modular Python 3.10+ FastAPI backend for **AquaTrack – Water Intake Reminder Log**.

## Architecture
- `app/main.py`: FastAPI application entry point and CORS configuration.
- `app/database.py`: SQLite schema initialization, indexing, and connection lifecycle.
- `app/services/`: Core business logic (`validation_service.py`, `intake_service.py`, `analytics_service.py`, `export_service.py`, `import_service.py`, `warning_service.py`).
- `app/routes/`: REST API routers (`/api/intake`, `/api/analytics`, `/api/settings`, `/api/export`, `/api/import`).
- `app/utils/`: Defensive JSON/CSV handlers, date validation helpers, and Matplotlib chart generation.
- `tests/test_aquatrack.py`: 18 automated unit and integration tests.

## Running Locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Running Tests
```bash
# Using pytest
pytest backend/tests/test_aquatrack.py -v

# Or using Python standard library unittest
python3 -m unittest backend/tests/test_aquatrack.py -v
```

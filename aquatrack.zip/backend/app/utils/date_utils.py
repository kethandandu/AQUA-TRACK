from __future__ import annotations

from datetime import date, datetime, timedelta
import re

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def parse_iso_date(value: str) -> date:
    if not isinstance(value, str) or not DATE_RE.match(value.strip()):
        raise ValueError("Date must be in YYYY-MM-DD format.")
    try:
        return datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError(f"Invalid calendar date '{value}'.") from exc


def validate_time_str(value: str) -> str:
    if not isinstance(value, str) or not TIME_RE.match(value.strip()):
        raise ValueError("Time must be in 24-hour HH:MM format (00:00 to 23:59).")
    return value.strip()


def today_iso() -> str:
    return date.today().isoformat()


def date_range_list(end_date_str: str, days: int) -> list[str]:
    end_d = parse_iso_date(end_date_str)
    start_d = end_d - timedelta(days=days - 1)
    return [(start_d + timedelta(days=offset)).isoformat() for offset in range(days)]


def month_bounds(year: int, month: int) -> tuple[str, str, int]:
    if month < 1 or month > 12:
        raise ValueError("Month must be between 1 and 12.")
    start_d = date(year, month, 1)
    if month == 12:
        next_month = date(year + 1, 1, 1)
    else:
        next_month = date(year, month + 1, 1)
    end_d = next_month - timedelta(days=1)
    return start_d.isoformat(), end_d.isoformat(), (next_month - start_d).days

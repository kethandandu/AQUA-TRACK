from __future__ import annotations

import io
from typing import Any


class ChartLibraryUnavailableError(RuntimeError):
    """Raised cleanly when matplotlib is not installed in the runtime environment."""


def is_matplotlib_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def generate_chart_png(
    chart_type: str,
    analytics_data: dict[str, Any],
    daily_target_ml: float,
) -> bytes:
    """
    Generate a high-DPI PNG chart using Matplotlib Agg backend from real SQLite records.
    Supported chart_type values:
      - daily
      - weekly
      - monthly
      - target_vs_actual
      - category
    """
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise ChartLibraryUnavailableError(
            "Matplotlib is not installed in the current Python environment. "
            "Install matplotlib (`pip install matplotlib`) to export raster PNG charts, "
            "or use the built-in vector chart exporter."
        ) from exc

    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=150)
    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#F8FAFC")
    ax.grid(axis="y", linestyle="--", alpha=0.45, color="#CBD5E1")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#CBD5E1")
    ax.spines["bottom"].set_color("#CBD5E1")

    if chart_type == "daily":
        timeline = analytics_data.get("hourly_timeline", [])
        labels = [item["label"] for item in timeline] or ["No entries"]
        values = [item["total_ml"] for item in timeline] or [0]
        ax.plot(labels, values, marker="o", linewidth=2.4, color="#0284C7", label="Intake (ml)")
        ax.fill_between(range(len(labels)), values, alpha=0.14, color="#0EA5E9")
        ax.set_title("AquaTrack — Daily Water Consumption Trend", fontsize=13, fontweight="bold", pad=12, color="#0F172A")
        ax.set_xlabel("Time of Day", fontsize=10, color="#475569")
        ax.set_ylabel("Volume (ml)", fontsize=10, color="#475569")
        ax.tick_params(axis="x", rotation=35, labelsize=8)
        ax.legend(frameon=False)

    elif chart_type == "weekly":
        series = analytics_data.get("daily_series", [])
        labels = [item["label"] for item in series] or ["No data"]
        values = [item["total_ml"] for item in series] or [0]
        colors = ["#16A34A" if v >= daily_target_ml else "#0284C7" for v in values]
        ax.bar(labels, values, color=colors, width=0.55, label="Daily Intake (ml)")
        ax.axhline(daily_target_ml, color="#D97706", linestyle="--", linewidth=1.6, label=f"Target ({int(daily_target_ml)} ml)")
        ax.set_title("AquaTrack — 7-Day Consumption Comparison", fontsize=13, fontweight="bold", pad=12, color="#0F172A")
        ax.set_xlabel("Day", fontsize=10, color="#475569")
        ax.set_ylabel("Volume (ml)", fontsize=10, color="#475569")
        ax.legend(frameon=False)

    elif chart_type == "monthly":
        series = analytics_data.get("daily_series", [])
        labels = [item["date"][-2:] for item in series] or ["01"]
        values = [item["total_ml"] for item in series] or [0]
        ax.bar(labels, values, color="#0EA5E9", width=0.65, label="Daily Total (ml)")
        ax.axhline(daily_target_ml, color="#0F172A", linestyle=":", linewidth=1.4, label=f"Target ({int(daily_target_ml)} ml)")
        ax.set_title("AquaTrack — Monthly Consumption Overview", fontsize=13, fontweight="bold", pad=12, color="#0F172A")
        ax.set_xlabel("Day of Month", fontsize=10, color="#475569")
        ax.set_ylabel("Volume (ml)", fontsize=10, color="#475569")
        ax.tick_params(axis="x", labelsize=8)
        ax.legend(frameon=False)

    elif chart_type == "target_vs_actual":
        series = analytics_data.get("daily_series", [])
        labels = [item["label"] for item in series] or ["No data"]
        actuals = [item["total_ml"] for item in series] or [0]
        targets = [daily_target_ml for _ in labels]
        x = list(range(len(labels)))
        width = 0.36
        ax.bar([i - width / 2 for i in x], actuals, width=width, color="#0284C7", label="Actual (ml)")
        ax.bar([i + width / 2 for i in x], targets, width=width, color="#CBD5E1", label="Target (ml)")
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_title("AquaTrack — Target vs Actual Consumption", fontsize=13, fontweight="bold", pad=12, color="#0F172A")
        ax.set_xlabel("Date", fontsize=10, color="#475569")
        ax.set_ylabel("Volume (ml)", fontsize=10, color="#475569")
        ax.legend(frameon=False)

    elif chart_type == "category":
        breakdown = analytics_data.get("category_breakdown", [])
        if not breakdown:
            ax.text(0.5, 0.5, "No category records available for this period", ha="center", va="center", fontsize=11, color="#64748B")
            ax.set_axis_off()
        else:
            labels = [item["category"] for item in breakdown]
            values = [item["total_ml"] for item in breakdown]
            palette = ["#0284C7", "#0EA5E9", "#06B6D4", "#14B8A6", "#16A34A", "#6366F1", "#8B5CF6", "#64748B"]
            ax.pie(values, labels=labels, autopct="%1.1f%%", startangle=120, colors=palette[: len(labels)])
            ax.set_title("AquaTrack — Water Intake Distribution by Category", fontsize=13, fontweight="bold", pad=12, color="#0F172A")
    else:
        plt.close(fig)
        raise ValueError(f"Unsupported chart type '{chart_type}'.")

    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf.read()

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
import shutil
from typing import Any


class StorageFileError(Exception):
    """Raised when a storage file cannot be read or repaired safely."""


def read_json_safe(file_path: str | Path, default_factory: Any = None) -> tuple[Any, str | None]:
    """
    Safely read a JSON file.
    - If missing, creates a valid initial structure without crashing.
    - If corrupted, preserves the corrupted file with a timestamped backup
      instead of silently destroying user data, and returns a warning message.
    """
    path = Path(file_path)
    initial_value = default_factory() if callable(default_factory) else (default_factory if default_factory is not None else {"records": []})

    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        write_json_safe(path, initial_value)
        return initial_value, None

    try:
        raw = path.read_text(encoding="utf-8")
        if not raw.strip():
            raise json.JSONDecodeError("Empty JSON file", raw, 0)
        return json.loads(raw), None
    except json.JSONDecodeError as exc:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        corrupt_backup = path.with_name(f"{path.name}.corrupted.{stamp}")
        try:
            shutil.copy2(path, corrupt_backup)
        except OSError:
            pass
        warning = (
            f"Corrupted JSON file detected at '{path.name}' ({exc.msg}). "
            f"Original file preserved at '{corrupt_backup.name}'."
        )
        return initial_value, warning
    except PermissionError as exc:
        raise StorageFileError(f"Permission denied reading '{path}': {exc}") from exc
    except OSError as exc:
        raise StorageFileError(f"Unable to read '{path}': {exc}") from exc


def write_json_safe(file_path: str | Path, payload: Any) -> None:
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.tmp")
    try:
        tmp_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp_path.replace(path)
    except PermissionError as exc:
        raise StorageFileError(f"Permission denied writing '{path}': {exc}") from exc
    except OSError as exc:
        raise StorageFileError(f"Unable to write '{path}': {exc}") from exc


def read_csv_safe(file_path: str | Path, required_headers: list[str] | None = None) -> tuple[list[dict[str, str]], str | None]:
    path = Path(file_path)
    headers = required_headers or [
        "intake_date",
        "intake_time",
        "quantity",
        "unit",
        "category",
        "description",
    ]
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        write_csv_safe(path, headers, [])
        return [], None

    try:
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            if reader.fieldnames is None:
                return [], f"CSV file '{path.name}' is empty or missing headers."
            rows = [dict(row) for row in reader]
            return rows, None
    except (csv.Error, UnicodeDecodeError) as exc:
        return [], f"Malformed CSV file '{path.name}': {exc}"
    except PermissionError as exc:
        raise StorageFileError(f"Permission denied reading '{path}': {exc}") from exc
    except OSError as exc:
        raise StorageFileError(f"Unable to read '{path}': {exc}") from exc


def write_csv_safe(file_path: str | Path, headers: list[str], rows: list[dict[str, Any]]) -> None:
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.tmp")
    try:
        with tmp_path.open("w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=headers, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        tmp_path.replace(path)
    except PermissionError as exc:
        raise StorageFileError(f"Permission denied writing '{path}': {exc}") from exc
    except OSError as exc:
        raise StorageFileError(f"Unable to write '{path}': {exc}") from exc

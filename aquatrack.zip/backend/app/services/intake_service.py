from __future__ import annotations

from pathlib import Path
from typing import Any

from app.database import get_connection, utc_now_iso
from app.services.validation_service import validate_intake_payload, validate_settings_payload
from app.utils.file_handler import write_csv_safe, write_json_safe


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {
        "id": row["id"],
        "quantity_ml": float(row["quantity_ml"]),
        "original_quantity": float(row["original_quantity"]),
        "original_unit": row["original_unit"],
        "category": row["category"],
        "description": row["description"] or "",
        "intake_date": row["intake_date"],
        "intake_time": row["intake_time"],
        "is_sample": bool(row["is_sample"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def sync_exchange_files(db_path: str | Path | None = None, data_dir: str | Path | None = None) -> None:
    """Keep CSV and JSON exchange snapshots synchronized with SQLite."""
    target_dir = Path(data_dir) if data_dir else (Path(db_path).parent if db_path else Path(__file__).resolve().parents[3] / "data")
    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM intake_records ORDER BY intake_date DESC, intake_time DESC, id DESC"
        ).fetchall()
        records = [_row_to_dict(r) for r in rows]

    write_json_safe(target_dir / "records_backup.json", {"records": records})
    csv_rows = [
        {
            "intake_date": r["intake_date"],
            "intake_time": r["intake_time"],
            "quantity": r["original_quantity"],
            "unit": r["original_unit"],
            "category": r["category"],
            "description": r["description"],
        }
        for r in records
    ]
    write_csv_safe(
        target_dir / "records_backup.csv",
        ["intake_date", "intake_time", "quantity", "unit", "category", "description"],
        csv_rows,
    )


def create_intake(payload: dict[str, Any], db_path: str | Path | None = None) -> dict[str, Any]:
    cleaned = validate_intake_payload(payload)
    now = utc_now_iso()
    with get_connection(db_path) as conn:
        cur = conn.execute(
            """
            INSERT INTO intake_records (
                quantity_ml, original_quantity, original_unit,
                category, description, intake_date, intake_time,
                is_sample, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                cleaned["quantity_ml"],
                cleaned["original_quantity"],
                cleaned["original_unit"],
                cleaned["category"],
                cleaned["description"],
                cleaned["intake_date"],
                cleaned["intake_time"],
                cleaned["is_sample"],
                now,
                now,
            ),
        )
        record_id = cur.lastrowid
        row = conn.execute("SELECT * FROM intake_records WHERE id = ?", (record_id,)).fetchone()
        return _row_to_dict(row)


def get_intake_by_id(record_id: int, db_path: str | Path | None = None) -> dict[str, Any] | None:
    with get_connection(db_path) as conn:
        row = conn.execute("SELECT * FROM intake_records WHERE id = ?", (record_id,)).fetchone()
        return _row_to_dict(row) if row else None


def update_intake(record_id: int, payload: dict[str, Any], db_path: str | Path | None = None) -> dict[str, Any] | None:
    existing = get_intake_by_id(record_id, db_path)
    if existing is None:
        return None
    cleaned = validate_intake_payload(payload)
    now = utc_now_iso()
    with get_connection(db_path) as conn:
        conn.execute(
            """
            UPDATE intake_records
            SET quantity_ml = ?, original_quantity = ?, original_unit = ?,
                category = ?, description = ?, intake_date = ?, intake_time = ?,
                updated_at = ?
            WHERE id = ?
            """,
            (
                cleaned["quantity_ml"],
                cleaned["original_quantity"],
                cleaned["original_unit"],
                cleaned["category"],
                cleaned["description"],
                cleaned["intake_date"],
                cleaned["intake_time"],
                now,
                record_id,
            ),
        )
        row = conn.execute("SELECT * FROM intake_records WHERE id = ?", (record_id,)).fetchone()
        return _row_to_dict(row)


def delete_intake(record_id: int, db_path: str | Path | None = None) -> bool:
    with get_connection(db_path) as conn:
        cur = conn.execute("DELETE FROM intake_records WHERE id = ?", (record_id,))
        return cur.rowcount > 0


def list_intakes(
    *,
    search: str = "",
    start_date: str = "",
    end_date: str = "",
    category: str = "",
    unit: str = "",
    min_ml: float | None = None,
    max_ml: float | None = None,
    sort: str = "newest",
    page: int = 1,
    page_size: int = 20,
    db_path: str | Path | None = None,
) -> dict[str, Any]:
    clauses: list[str] = []
    params: list[Any] = []

    if search.strip():
        like = f"%{search.strip()}%"
        clauses.append("(description LIKE ? OR category LIKE ? OR intake_date LIKE ?)")
        params.extend([like, like, like])
    if start_date.strip():
        clauses.append("intake_date >= ?")
        params.append(start_date.strip())
    if end_date.strip():
        clauses.append("intake_date <= ?")
        params.append(end_date.strip())
    if category.strip() and category.strip().lower() != "all":
        clauses.append("category = ?")
        params.append(category.strip())
    if unit.strip() and unit.strip().lower() != "all":
        clauses.append("original_unit = ?")
        params.append(unit.strip().lower())
    if min_ml is not None:
        clauses.append("quantity_ml >= ?")
        params.append(min_ml)
    if max_ml is not None:
        clauses.append("quantity_ml <= ?")
        params.append(max_ml)

    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    order_map = {
        "newest": "intake_date DESC, intake_time DESC, id DESC",
        "oldest": "intake_date ASC, intake_time ASC, id ASC",
        "highest": "quantity_ml DESC, intake_date DESC, intake_time DESC",
        "lowest": "quantity_ml ASC, intake_date DESC, intake_time DESC",
    }
    order_sql = order_map.get(sort, order_map["newest"])

    safe_page = max(1, page)
    safe_size = max(1, min(100, page_size))
    offset = (safe_page - 1) * safe_size

    with get_connection(db_path) as conn:
        total_row = conn.execute(f"SELECT COUNT(*) AS cnt FROM intake_records {where_sql}", params).fetchone()
        total = int(total_row["cnt"])
        rows = conn.execute(
            f"SELECT * FROM intake_records {where_sql} ORDER BY {order_sql} LIMIT ? OFFSET ?",
            [*params, safe_size, offset],
        ).fetchall()

    total_pages = max(1, (total + safe_size - 1) // safe_size)
    return {
        "records": [_row_to_dict(r) for r in rows],
        "pagination": {
            "page": safe_page,
            "page_size": safe_size,
            "total_records": total,
            "total_pages": total_pages,
        },
    }


def get_settings(db_path: str | Path | None = None) -> dict[str, Any]:
    with get_connection(db_path) as conn:
        row = conn.execute("SELECT * FROM user_settings WHERE id = 1").fetchone()
        return {
            "daily_target_ml": float(row["daily_target_ml"]),
            "preferred_unit": row["preferred_unit"],
            "high_single_entry_threshold_ml": float(row["high_single_entry_threshold_ml"]),
            "high_daily_total_threshold_ml": float(row["high_daily_total_threshold_ml"]),
            "reminder_interval_hours": int(row["reminder_interval_hours"]),
            "dark_mode": bool(row["dark_mode"]),
            "updated_at": row["updated_at"],
        }


def update_settings(payload: dict[str, Any], db_path: str | Path | None = None) -> dict[str, Any]:
    cleaned = validate_settings_payload(payload)
    if not cleaned:
        return get_settings(db_path)
    now = utc_now_iso()
    sets = [f"{col} = ?" for col in cleaned.keys()]
    sets.append("updated_at = ?")
    params = [*cleaned.values(), now]
    with get_connection(db_path) as conn:
        conn.execute(f"UPDATE user_settings SET {', '.join(sets)} WHERE id = 1", params)
    return get_settings(db_path)

from __future__ import annotations

from datetime import timedelta
from pathlib import Path
from typing import Any

from app.database import get_connection
from app.services.intake_service import get_settings
from app.utils.date_utils import date_range_list, month_bounds, parse_iso_date, today_iso


def classify_target_status(total_ml: float, target_ml: float) -> str:
    if total_ml < target_ml:
        return "Below target"
    if abs(total_ml - target_ml) < 1e-6:
        return "Target achieved"
    return "Above target"


def get_daily_analytics(target_date: str | None = None, db_path: str | Path | None = None) -> dict[str, Any]:
    day_str = target_date or today_iso()
    parse_iso_date(day_str)
    settings = get_settings(db_path)
    target_ml = settings["daily_target_ml"]

    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM intake_records WHERE intake_date = ? ORDER BY intake_time ASC, id ASC",
            (day_str,),
        ).fetchall()

    total_ml = round(sum(float(r["quantity_ml"]) for r in rows), 2)
    entry_count = len(rows)
    remaining_ml = round(max(0.0, target_ml - total_ml), 2)
    completion_pct = round((total_ml / target_ml) * 100.0, 1) if target_ml > 0 else 0.0
    avg_per_entry_ml = round(total_ml / entry_count, 1) if entry_count > 0 else 0.0

    category_map: dict[str, dict[str, Any]] = {}
    hourly_timeline: list[dict[str, Any]] = []
    cumulative = 0.0
    for r in rows:
        qty = float(r["quantity_ml"])
        cumulative = round(cumulative + qty, 2)
        cat = r["category"]
        if cat not in category_map:
            category_map[cat] = {"category": cat, "total_ml": 0.0, "entries": 0}
        category_map[cat]["total_ml"] = round(category_map[cat]["total_ml"] + qty, 2)
        category_map[cat]["entries"] += 1
        hourly_timeline.append({
            "label": r["intake_time"],
            "total_ml": qty,
            "cumulative_ml": cumulative,
            "category": cat,
        })

    category_breakdown = sorted(category_map.values(), key=lambda x: x["total_ml"], reverse=True)

    return {
        "date": day_str,
        "daily_target_ml": target_ml,
        "total_ml": total_ml,
        "remaining_ml": remaining_ml,
        "completion_pct": completion_pct,
        "entry_count": entry_count,
        "avg_per_entry_ml": avg_per_entry_ml,
        "status": classify_target_status(total_ml, target_ml),
        "target_achieved": total_ml >= target_ml,
        "category_breakdown": category_breakdown,
        "hourly_timeline": hourly_timeline,
    }


def get_weekly_analytics(end_date: str | None = None, db_path: str | Path | None = None) -> dict[str, Any]:
    end_str = end_date or today_iso()
    end_d = parse_iso_date(end_str)
    days = date_range_list(end_str, 7)
    start_str = days[0]

    prev_end_str = (end_d - timedelta(days=7)).isoformat()
    prev_days = date_range_list(prev_end_str, 7)

    settings = get_settings(db_path)
    target_ml = settings["daily_target_ml"]

    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT intake_date, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY intake_date",
            (start_str, end_str),
        ).fetchall()
        prev_row = conn.execute(
            "SELECT COALESCE(SUM(quantity_ml), 0) AS total_ml "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ?",
            (prev_days[0], prev_days[-1]),
        ).fetchone()
        cat_rows = conn.execute(
            "SELECT category, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY category ORDER BY total_ml DESC",
            (start_str, end_str),
        ).fetchall()

    totals_by_day = {r["intake_date"]: (round(float(r["total_ml"]), 2), int(r["entries"])) for r in rows}

    daily_series: list[dict[str, Any]] = []
    for d in days:
        total, cnt = totals_by_day.get(d, (0.0, 0))
        parsed = parse_iso_date(d)
        daily_series.append({
            "date": d,
            "label": parsed.strftime("%a %d"),
            "total_ml": total,
            "target_ml": target_ml,
            "entries": cnt,
            "achieved": total >= target_ml,
        })

    total_weekly = round(sum(x["total_ml"] for x in daily_series), 2)
    daily_average = round(total_weekly / 7.0, 1)
    active_days_list = [x for x in daily_series if x["total_ml"] > 0]
    achieved_days = sum(1 for x in daily_series if x["achieved"])
    achievement_freq_pct = round((achieved_days / 7.0) * 100.0, 1)

    highest = max(active_days_list, key=lambda x: x["total_ml"]) if active_days_list else None
    lowest = min(active_days_list, key=lambda x: x["total_ml"]) if active_days_list else None

    prev_total = round(float(prev_row["total_ml"]), 2)
    trend_pct = round(((total_weekly - prev_total) / prev_total) * 100.0, 1) if prev_total > 0 else None

    return {
        "start_date": start_str,
        "end_date": end_str,
        "daily_target_ml": target_ml,
        "total_ml": total_weekly,
        "daily_average_ml": daily_average,
        "active_days": len(active_days_list),
        "target_achieved_days": achieved_days,
        "target_achievement_frequency_pct": achievement_freq_pct,
        "highest_day": {"date": highest["date"], "total_ml": highest["total_ml"]} if highest else None,
        "lowest_day": {"date": lowest["date"], "total_ml": lowest["total_ml"]} if lowest else None,
        "previous_week_total_ml": prev_total,
        "trend_pct": trend_pct,
        "daily_series": daily_series,
        "category_breakdown": [
            {"category": r["category"], "total_ml": round(float(r["total_ml"]), 2), "entries": int(r["entries"])}
            for r in cat_rows
        ],
    }


def get_monthly_analytics(year: int | None = None, month: int | None = None, db_path: str | Path | None = None) -> dict[str, Any]:
    ref_d = parse_iso_date(today_iso())
    target_year = year or ref_d.year
    target_month = month or ref_d.month
    start_str, end_str, num_days = month_bounds(target_year, target_month)

    if target_month == 1:
        prev_year, prev_month = target_year - 1, 12
    else:
        prev_year, prev_month = target_year, target_month - 1
    prev_start, prev_end, _ = month_bounds(prev_year, prev_month)

    settings = get_settings(db_path)
    target_ml = settings["daily_target_ml"]

    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT intake_date, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY intake_date",
            (start_str, end_str),
        ).fetchall()
        prev_row = conn.execute(
            "SELECT COALESCE(SUM(quantity_ml), 0) AS total_ml, COUNT(DISTINCT intake_date) AS active_days "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ?",
            (prev_start, prev_end),
        ).fetchone()
        cat_rows = conn.execute(
            "SELECT category, SUM(quantity_ml) AS total_ml, COUNT(*) AS entries "
            "FROM intake_records WHERE intake_date BETWEEN ? AND ? GROUP BY category ORDER BY total_ml DESC",
            (start_str, end_str),
        ).fetchall()

    totals_by_day = {r["intake_date"]: (round(float(r["total_ml"]), 2), int(r["entries"])) for r in rows}
    all_dates = date_range_list(end_str, num_days)

    daily_series: list[dict[str, Any]] = []
    for d in all_dates:
        total, cnt = totals_by_day.get(d, (0.0, 0))
        daily_series.append({
            "date": d,
            "label": d[-2:],
            "total_ml": total,
            "target_ml": target_ml,
            "entries": cnt,
            "achieved": total >= target_ml,
        })

    total_monthly = round(sum(x["total_ml"] for x in daily_series), 2)
    active_days_list = [x for x in daily_series if x["total_ml"] > 0]
    active_days = len(active_days_list)
    monthly_average = round(total_monthly / active_days, 1) if active_days > 0 else 0.0
    achieved_days = sum(1 for x in active_days_list if x["achieved"])
    achievement_rate_pct = round((achieved_days / active_days) * 100.0, 1) if active_days > 0 else 0.0

    highest = max(active_days_list, key=lambda x: x["total_ml"]) if active_days_list else None
    lowest = min(active_days_list, key=lambda x: x["total_ml"]) if active_days_list else None

    prev_total = round(float(prev_row["total_ml"]), 2)
    prev_active = int(prev_row["active_days"])
    mom_delta_pct = round(((total_monthly - prev_total) / prev_total) * 100.0, 1) if prev_total > 0 and active_days > 0 else None

    return {
        "year": target_year,
        "month": target_month,
        "start_date": start_str,
        "end_date": end_str,
        "daily_target_ml": target_ml,
        "total_ml": total_monthly,
        "monthly_average_ml": monthly_average,
        "active_days": active_days,
        "days_in_month": num_days,
        "target_achieved_days": achieved_days,
        "target_achievement_rate_pct": achievement_rate_pct,
        "highest_day": {"date": highest["date"], "total_ml": highest["total_ml"]} if highest else None,
        "lowest_day": {"date": lowest["date"], "total_ml": lowest["total_ml"]} if lowest else None,
        "previous_month_total_ml": prev_total,
        "previous_month_active_days": prev_active,
        "month_over_month_delta_pct": mom_delta_pct,
        "daily_series": daily_series,
        "category_breakdown": [
            {"category": r["category"], "total_ml": round(float(r["total_ml"]), 2), "entries": int(r["entries"])}
            for r in cat_rows
        ],
    }

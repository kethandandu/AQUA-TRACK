from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from app.database import get_connection
from app.services.intake_service import get_settings
from app.utils.date_utils import today_iso


def evaluate_warnings(target_date: str | None = None, db_path: str | Path | None = None) -> list[dict[str, Any]]:
    """
    Evaluate informative, non-alarming hydration and data-integrity warnings
    using configurable thresholds.
    """
    day_str = target_date or today_iso()
    settings = get_settings(db_path)
    target_ml = settings["daily_target_ml"]
    high_single = settings["high_single_entry_threshold_ml"]
    high_daily = settings["high_daily_total_threshold_ml"]

    warnings: list[dict[str, Any]] = []

    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM intake_records WHERE intake_date = ? ORDER BY intake_time ASC, id ASC",
            (day_str,),
        ).fetchall()

    total_ml = sum(float(r["quantity_ml"]) for r in rows)

    if len(rows) == 0:
        warnings.append({
            "code": "NO_ENTRIES_TODAY",
            "severity": "info",
            "title": "No entries logged for selected date",
            "message": f"No water intake entries recorded for {day_str} yet. Your configured target is {int(target_ml)} ml.",
            "basis": f"Configured daily target: {int(target_ml)} ml",
        })
    elif total_ml < target_ml:
        remaining = round(target_ml - total_ml, 1)
        warnings.append({
            "code": "BELOW_DAILY_TARGET",
            "severity": "warning",
            "title": "Daily target not yet reached",
            "message": f"You have logged {int(total_ml)} ml out of your {int(target_ml)} ml goal ({int(remaining)} ml remaining).",
            "basis": f"Compared against configured daily target ({int(target_ml)} ml)",
        })

    if total_ml >= high_daily:
        warnings.append({
            "code": "HIGH_DAILY_TOTAL",
            "severity": "warning",
            "title": "Unusually high daily intake total",
            "message": f"Total logged intake for {day_str} is {int(total_ml)} ml, exceeding your configured high-daily threshold.",
            "basis": f"Configured high daily threshold: {int(high_daily)} ml",
        })

    for r in rows:
        qty = float(r["quantity_ml"])
        if qty >= high_single:
            warnings.append({
                "code": "HIGH_SINGLE_ENTRY",
                "severity": "warning",
                "title": "Unusually large single entry",
                "message": f"Entry #{r['id']} at {r['intake_time']} recorded {int(qty)} ml ({r['category']}). Verify if this was intended.",
                "basis": f"Configured single-entry threshold: {int(high_single)} ml",
            })

    # Detect rapid duplicate-like entries within 2 minutes of identical volume
    for i in range(1, len(rows)):
        prev_r = rows[i - 1]
        curr_r = rows[i]
        try:
            t1 = datetime.strptime(prev_r["intake_time"], "%H:%M")
            t2 = datetime.strptime(curr_r["intake_time"], "%H:%M")
            diff_min = abs((t2 - t1).total_seconds()) / 60.0
        except ValueError:
            continue
        if diff_min <= 2 and abs(float(prev_r["quantity_ml"]) - float(curr_r["quantity_ml"])) < 1e-6:
            warnings.append({
                "code": "POSSIBLE_DUPLICATE_ENTRY",
                "severity": "info",
                "title": "Possible duplicate entry detected",
                "message": f"Entries #{prev_r['id']} ({prev_r['intake_time']}) and #{curr_r['id']} ({curr_r['intake_time']}) both logged {int(curr_r['quantity_ml'])} ml within 2 minutes.",
                "basis": "Anomaly rule: identical volume logged within 2 minutes",
            })

    return warnings

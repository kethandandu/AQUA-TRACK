from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
import math
from typing import Any

from app.utils.date_utils import parse_iso_date, validate_time_str

ALLOWED_CATEGORIES = (
    "Morning",
    "Breakfast",
    "Lunch",
    "Afternoon",
    "Evening",
    "Dinner",
    "Before Sleep",
    "Other",
)

ALLOWED_UNITS = ("ml", "l")
MAX_SINGLE_ENTRY_ML = 10000.0
MIN_SINGLE_ENTRY_ML = 1.0
MIN_DAILY_TARGET_ML = 500.0
MAX_DAILY_TARGET_ML = 10000.0
MAX_DESCRIPTION_LEN = 240


@dataclass
class ValidationErrorDetail:
    field: str
    message: str


class InputValidationError(ValueError):
    def __init__(self, message: str, field_errors: list[dict[str, str]] | None = None):
        super().__init__(message)
        self.message = message
        self.field_errors = field_errors or []


def convert_to_ml(quantity: float, unit: str) -> float:
    normalized = unit.strip().lower()
    if normalized == "l":
        return round(quantity * 1000.0, 2)
    if normalized == "ml":
        return round(quantity, 2)
    raise InputValidationError(
        f"Unsupported measurement unit '{unit}'. Allowed units: ml, l.",
        [{"field": "unit", "message": "Measurement unit must be 'ml' or 'l'."}],
    )


def parse_positive_number(raw_value: Any, field_name: str = "quantity") -> float:
    if raw_value is None or (isinstance(raw_value, str) and not raw_value.strip()):
        raise InputValidationError(
            f"{field_name} is required and cannot be empty.",
            [{"field": field_name, "message": "Field cannot be empty."}],
        )
    if isinstance(raw_value, bool):
        raise InputValidationError(
            f"{field_name} must be a valid number.",
            [{"field": field_name, "message": "Boolean values are not valid quantities."}],
        )
    try:
        num = float(raw_value)
    except (TypeError, ValueError) as exc:
        raise InputValidationError(
            f"{field_name} must be a valid numeric value.",
            [{"field": field_name, "message": "Enter numbers only (no letters or symbols)."}],
        ) from exc

    if math.isnan(num) or math.isinf(num):
        raise InputValidationError(
            f"{field_name} must be a finite number.",
            [{"field": field_name, "message": "Value must be finite."}],
        )
    if num <= 0:
        raise InputValidationError(
            f"{field_name} must be greater than zero.",
            [{"field": field_name, "message": "Quantity must be greater than 0."}],
        )
    return num


def validate_intake_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise InputValidationError("Request payload must be a JSON object.")

    errors: list[dict[str, str]] = []

    raw_qty = payload.get("quantity")
    raw_unit = payload.get("unit", "ml")
    raw_category = payload.get("category", "Other")
    raw_date = payload.get("intake_date")
    raw_time = payload.get("intake_time")
    raw_desc = payload.get("description", "")

    qty_val: float | None = None
    try:
        qty_val = parse_positive_number(raw_qty, "quantity")
    except InputValidationError as exc:
        errors.extend(exc.field_errors)

    unit_val = ""
    if not isinstance(raw_unit, str) or raw_unit.strip().lower() not in ALLOWED_UNITS:
        errors.append({"field": "unit", "message": "Measurement unit must be 'ml' or 'l'."})
    else:
        unit_val = raw_unit.strip().lower()

    qty_ml = 0.0
    if qty_val is not None and unit_val:
        qty_ml = convert_to_ml(qty_val, unit_val)
        if qty_ml < MIN_SINGLE_ENTRY_ML:
            errors.append({"field": "quantity", "message": f"Quantity must be at least {MIN_SINGLE_ENTRY_ML} ml."})
        elif qty_ml > MAX_SINGLE_ENTRY_ML:
            errors.append({"field": "quantity", "message": f"Single entry cannot exceed {int(MAX_SINGLE_ENTRY_ML)} ml (10 L)."})

    cat_val = ""
    if not isinstance(raw_category, str) or raw_category.strip() not in ALLOWED_CATEGORIES:
        errors.append({
            "field": "category",
            "message": f"Category must be one of: {', '.join(ALLOWED_CATEGORIES)}.",
        })
    else:
        cat_val = raw_category.strip()

    date_val = ""
    if not raw_date or not isinstance(raw_date, str):
        errors.append({"field": "intake_date", "message": "Date is required (YYYY-MM-DD)."})
    else:
        try:
            parsed_d = parse_iso_date(raw_date)
            if parsed_d > date.today() + timedelta(days=1):
                errors.append({"field": "intake_date", "message": "Date cannot be more than 1 day in the future."})
            elif parsed_d.year < 2000:
                errors.append({"field": "intake_date", "message": "Date year must be 2000 or later."})
            else:
                date_val = parsed_d.isoformat()
        except ValueError as exc:
            errors.append({"field": "intake_date", "message": str(exc)})

    time_val = ""
    if not raw_time or not isinstance(raw_time, str):
        errors.append({"field": "intake_time", "message": "Time is required (HH:MM)."})
    else:
        try:
            time_val = validate_time_str(raw_time)
        except ValueError as exc:
            errors.append({"field": "intake_time", "message": str(exc)})

    desc_val = ""
    if raw_desc is not None:
        if not isinstance(raw_desc, str):
            errors.append({"field": "description", "message": "Description must be text."})
        elif len(raw_desc.strip()) > MAX_DESCRIPTION_LEN:
            errors.append({"field": "description", "message": f"Description cannot exceed {MAX_DESCRIPTION_LEN} characters."})
        else:
            desc_val = raw_desc.strip()

    if errors:
        raise InputValidationError(errors[0]["message"], errors)

    return {
        "quantity_ml": qty_ml,
        "original_quantity": round(qty_val, 3),
        "original_unit": unit_val,
        "category": cat_val,
        "description": desc_val,
        "intake_date": date_val,
        "intake_time": time_val,
        "is_sample": 1 if bool(payload.get("is_sample", False)) else 0,
    }


def validate_settings_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise InputValidationError("Settings payload must be a JSON object.")

    errors: list[dict[str, str]] = []
    cleaned: dict[str, Any] = {}

    if "daily_target_ml" in payload:
        try:
            target = parse_positive_number(payload["daily_target_ml"], "daily_target_ml")
            if target < MIN_DAILY_TARGET_ML or target > MAX_DAILY_TARGET_ML:
                errors.append({
                    "field": "daily_target_ml",
                    "message": f"Daily target must be between {int(MIN_DAILY_TARGET_ML)} ml and {int(MAX_DAILY_TARGET_ML)} ml.",
                })
            else:
                cleaned["daily_target_ml"] = round(target, 2)
        except InputValidationError as exc:
            errors.extend(exc.field_errors)

    if "preferred_unit" in payload:
        u = payload["preferred_unit"]
        if not isinstance(u, str) or u.strip().lower() not in ALLOWED_UNITS:
            errors.append({"field": "preferred_unit", "message": "Preferred unit must be 'ml' or 'l'."})
        else:
            cleaned["preferred_unit"] = u.strip().lower()

    if "high_single_entry_threshold_ml" in payload:
        try:
            val = parse_positive_number(payload["high_single_entry_threshold_ml"], "high_single_entry_threshold_ml")
            if val < 500 or val > 5000:
                errors.append({"field": "high_single_entry_threshold_ml", "message": "Single entry warning threshold must be between 500 ml and 5000 ml."})
            else:
                cleaned["high_single_entry_threshold_ml"] = round(val, 2)
        except InputValidationError as exc:
            errors.extend(exc.field_errors)

    if "high_daily_total_threshold_ml" in payload:
        try:
            val = parse_positive_number(payload["high_daily_total_threshold_ml"], "high_daily_total_threshold_ml")
            if val < 2000 or val > 15000:
                errors.append({"field": "high_daily_total_threshold_ml", "message": "Daily high-volume threshold must be between 2000 ml and 15000 ml."})
            else:
                cleaned["high_daily_total_threshold_ml"] = round(val, 2)
        except InputValidationError as exc:
            errors.extend(exc.field_errors)

    if "reminder_interval_hours" in payload:
        try:
            val = int(parse_positive_number(payload["reminder_interval_hours"], "reminder_interval_hours"))
            if val < 1 or val > 12:
                errors.append({"field": "reminder_interval_hours", "message": "Reminder interval must be between 1 and 12 hours."})
            else:
                cleaned["reminder_interval_hours"] = val
        except InputValidationError as exc:
            errors.extend(exc.field_errors)

    if "dark_mode" in payload:
        cleaned["dark_mode"] = 1 if bool(payload["dark_mode"]) else 0

    if errors:
        raise InputValidationError(errors[0]["message"], errors)

    return cleaned

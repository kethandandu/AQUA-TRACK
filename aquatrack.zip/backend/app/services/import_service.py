from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any

from app.database import get_connection, utc_now_iso
from app.services.validation_service import InputValidationError, validate_intake_payload

REQUIRED_COLUMNS = {"intake_date", "intake_time", "quantity", "unit", "category"}


def import_csv_content(csv_text: str, db_path: str | Path | None = None) -> dict[str, Any]:
    if not csv_text or not csv_text.strip():
        return {
            "success": False,
            "imported_count": 0,
            "rejected_count": 0,
            "duplicate_count": 0,
            "errors": [{"row": 0, "reason": "Uploaded CSV content is empty."}],
        }

    try:
        reader = csv.DictReader(io.StringIO(csv_text.lstrip("\ufeff")))
    except csv.Error as exc:
        return {
            "success": False,
            "imported_count": 0,
            "rejected_count": 0,
            "duplicate_count": 0,
            "errors": [{"row": 0, "reason": f"Malformed CSV structure: {exc}"}],
        }

    if not reader.fieldnames:
        return {
            "success": False,
            "imported_count": 0,
            "rejected_count": 0,
            "duplicate_count": 0,
            "errors": [{"row": 0, "reason": "Missing CSV header row."}],
        }

    normalized_headers = {h.strip().lower() for h in reader.fieldnames if h}
    missing = sorted(REQUIRED_COLUMNS - normalized_headers)
    if missing:
        return {
            "success": False,
            "imported_count": 0,
            "rejected_count": 0,
            "duplicate_count": 0,
            "errors": [{"row": 1, "reason": f"Missing required column(s): {', '.join(missing)}"}],
        }

    errors: list[dict[str, Any]] = []
    valid_rows: list[dict[str, Any]] = []
    seen_in_file: set[tuple[str, str, float, str]] = set()
    duplicate_count = 0
    rejected_count = 0

    with get_connection(db_path) as conn:
        existing_rows = conn.execute(
            "SELECT intake_date, intake_time, quantity_ml, category FROM intake_records"
        ).fetchall()
        existing_keys = {
            (r["intake_date"], r["intake_time"], round(float(r["quantity_ml"]), 2), r["category"])
            for r in existing_rows
        }

        for row_idx, raw_row in enumerate(reader, start=2):
            row = {(k.strip().lower() if k else ""): (v.strip() if isinstance(v, str) else "") for k, v in raw_row.items()}
            try:
                cleaned = validate_intake_payload({
                    "intake_date": row.get("intake_date", ""),
                    "intake_time": row.get("intake_time", ""),
                    "quantity": row.get("quantity", ""),
                    "unit": row.get("unit", ""),
                    "category": row.get("category", ""),
                    "description": row.get("description", ""),
                })
            except InputValidationError as exc:
                rejected_count += 1
                errors.append({"row": row_idx, "type": "validation", "reason": exc.message, "raw": row})
                continue

            key = (cleaned["intake_date"], cleaned["intake_time"], round(cleaned["quantity_ml"], 2), cleaned["category"])
            if key in existing_keys or key in seen_in_file:
                duplicate_count += 1
                errors.append({
                    "row": row_idx,
                    "type": "duplicate",
                    "reason": f"Duplicate entry ({cleaned['intake_date']} {cleaned['intake_time']}, {int(cleaned['quantity_ml'])} ml, {cleaned['category']}).",
                    "raw": row,
                })
                continue

            seen_in_file.add(key)
            valid_rows.append(cleaned)

        now = utc_now_iso()
        for item in valid_rows:
            conn.execute(
                """
                INSERT INTO intake_records (
                    quantity_ml, original_quantity, original_unit,
                    category, description, intake_date, intake_time,
                    is_sample, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                """,
                (
                    item["quantity_ml"],
                    item["original_quantity"],
                    item["original_unit"],
                    item["category"],
                    item["description"],
                    item["intake_date"],
                    item["intake_time"],
                    now,
                    now,
                ),
            )

    return {
        "success": True,
        "imported_count": len(valid_rows),
        "rejected_count": rejected_count,
        "duplicate_count": duplicate_count,
        "errors": errors,
    }

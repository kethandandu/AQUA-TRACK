from __future__ import annotations

import csv
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.database import get_connection
from app.services.intake_service import get_settings


def _fetch_records(start_date: str = "", end_date: str = "", db_path: str | Path | None = None) -> list[dict[str, Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    if start_date.strip():
        clauses.append("intake_date >= ?")
        params.append(start_date.strip())
    if end_date.strip():
        clauses.append("intake_date <= ?")
        params.append(end_date.strip())
    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    with get_connection(db_path) as conn:
        rows = conn.execute(
            f"SELECT * FROM intake_records {where_sql} ORDER BY intake_date DESC, intake_time DESC, id DESC",
            params,
        ).fetchall()
    return [dict(r) for r in rows]


def _build_summary(records: list[dict[str, Any]], daily_target_ml: float) -> dict[str, Any]:
    if not records:
        return {
            "total_ml": 0.0,
            "average_daily_ml": 0.0,
            "active_days": 0,
            "target_achievement_pct": 0.0,
            "highest_day": None,
            "lowest_day": None,
        }

    daily_totals: dict[str, float] = {}
    for r in records:
        d = r["intake_date"]
        daily_totals[d] = round(daily_totals.get(d, 0.0) + float(r["quantity_ml"]), 2)

    total_ml = round(sum(daily_totals.values()), 2)
    active_days = len(daily_totals)
    avg_daily = round(total_ml / active_days, 1)
    achieved_days = sum(1 for v in daily_totals.values() if v >= daily_target_ml)
    achievement_pct = round((achieved_days / active_days) * 100.0, 1)
    highest = max(daily_totals.items(), key=lambda x: x[1])
    lowest = min(daily_totals.items(), key=lambda x: x[1])

    return {
        "total_ml": total_ml,
        "average_daily_ml": avg_daily,
        "active_days": active_days,
        "target_achievement_pct": achievement_pct,
        "highest_day": {"date": highest[0], "total_ml": highest[1]},
        "lowest_day": {"date": lowest[0], "total_ml": lowest[1]},
    }


def export_csv_text(start_date: str = "", end_date: str = "", db_path: str | Path | None = None) -> str:
    records = _fetch_records(start_date, end_date, db_path)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "intake_date", "intake_time", "quantity_ml", "original_quantity", "original_unit", "category", "description", "is_sample"])
    for r in records:
        writer.writerow([
            r["id"],
            r["intake_date"],
            r["intake_time"],
            r["quantity_ml"],
            r["original_quantity"],
            r["original_unit"],
            r["category"],
            r["description"],
            "sample" if r["is_sample"] else "user",
        ])
    return buf.getvalue()


def export_json_text(start_date: str = "", end_date: str = "", db_path: str | Path | None = None) -> str:
    records = _fetch_records(start_date, end_date, db_path)
    settings = get_settings(db_path)
    summary = _build_summary(records, settings["daily_target_ml"])
    payload = {
        "application": "AquaTrack — Water Intake Reminder Log",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "reporting_period": {
            "start_date": start_date or "All recorded dates",
            "end_date": end_date or "Present",
        },
        "settings": settings,
        "summary": summary,
        "records": records,
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)


def export_markdown_text(start_date: str = "", end_date: str = "", db_path: str | Path | None = None) -> str:
    records = _fetch_records(start_date, end_date, db_path)
    settings = get_settings(db_path)
    summary = _build_summary(records, settings["daily_target_ml"])
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    period = f"{start_date or 'Beginning'} to {end_date or 'Latest'}"

    lines = [
        "# AquaTrack — Hydration Analytics Report",
        "",
        f"- **Generated At:** {generated}",
        f"- **Reporting Period:** {period}",
        f"- **Daily Target:** {int(settings['daily_target_ml'])} ml",
        f"- **Total Consumption:** {summary['total_ml']:.0f} ml",
        f"- **Average Daily Consumption:** {summary['average_daily_ml']:.1f} ml ({summary['active_days']} active days)",
        f"- **Target Achievement Rate:** {summary['target_achievement_pct']:.1f}%",
        f"- **Highest Consumption Day:** {summary['highest_day']['date'] + ' (' + str(int(summary['highest_day']['total_ml'])) + ' ml)' if summary['highest_day'] else 'N/A'}",
        f"- **Lowest Consumption Day:** {summary['lowest_day']['date'] + ' (' + str(int(summary['lowest_day']['total_ml'])) + ' ml)' if summary['lowest_day'] else 'N/A'}",
        "",
        "## Recorded Entries",
        "",
        "| Date | Time | Volume (ml) | Original | Category | Description |",
        "| :--- | :--- | ---: | :--- | :--- | :--- |",
    ]
    if not records:
        lines.append("| — | — | 0 | — | — | No records in selected range |")
    else:
        for r in records:
            desc = (r["description"] or "—").replace("|", "\\|")
            lines.append(
                f"| {r['intake_date']} | {r['intake_time']} | {int(r['quantity_ml'])} | {r['original_quantity']} {r['original_unit']} | {r['category']} | {desc} |"
            )
    return "\n".join(lines) + "\n"


def export_txt_audit(start_date: str = "", end_date: str = "", db_path: str | Path | None = None) -> str:
    records = _fetch_records(start_date, end_date, db_path)
    settings = get_settings(db_path)
    summary = _build_summary(records, settings["daily_target_ml"])
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    period = f"{start_date or 'Beginning'} to {end_date or 'Latest'}"

    lines = [
        "================================================================================",
        "AQUATRACK - WATER INTAKE AUDIT LOG",
        "================================================================================",
        f"Generated Date        : {generated}",
        f"Reporting Period      : {period}",
        f"Configured Target     : {int(settings['daily_target_ml'])} ml/day",
        f"Total Consumption     : {summary['total_ml']:.0f} ml",
        f"Average Daily Intake  : {summary['average_daily_ml']:.1f} ml",
        f"Target Achievement    : {summary['target_achievement_pct']:.1f}%",
        f"Highest Day           : {summary['highest_day']['date'] + ' (' + str(int(summary['highest_day']['total_ml'])) + ' ml)' if summary['highest_day'] else 'N/A'}",
        f"Lowest Day            : {summary['lowest_day']['date'] + ' (' + str(int(summary['lowest_day']['total_ml'])) + ' ml)' if summary['lowest_day'] else 'N/A'}",
        "--------------------------------------------------------------------------------",
        f"{'ID':<5} {'DATE':<12} {'TIME':<7} {'VOL(ML)':>9} {'ORIG':>10} {'CATEGORY':<14} {'DESCRIPTION'}",
        "--------------------------------------------------------------------------------",
    ]
    if not records:
        lines.append("No water intake records found for the specified period.")
    else:
        for r in records:
            orig = f"{r['original_quantity']} {r['original_unit']}"
            lines.append(
                f"{r['id']:<5} {r['intake_date']:<12} {r['intake_time']:<7} {int(r['quantity_ml']):>9} {orig:>10} {r['category']:<14} {r['description'] or '-'}"
            )
    lines.append("================================================================================")
    return "\n".join(lines) + "\n"

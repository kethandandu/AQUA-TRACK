from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_PATH = PROJECT_ROOT / "data" / "aquatrack.db"


def get_db_path(custom_path: str | Path | None = None) -> Path:
    if custom_path is not None:
        return Path(custom_path)
    env_path = os.environ.get("AQUATRACK_DB_PATH")
    if env_path:
        return Path(env_path)
    return DEFAULT_DB_PATH


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def init_db(db_path: str | Path | None = None) -> Path:
    """Initialize SQLite schema, indexes, and default user settings idempotently."""
    target = get_db_path(db_path)
    target.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(target))
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS intake_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quantity_ml REAL NOT NULL CHECK(quantity_ml > 0 AND quantity_ml <= 10000),
                original_quantity REAL NOT NULL CHECK(original_quantity > 0),
                original_unit TEXT NOT NULL CHECK(original_unit IN ('ml', 'l')),
                category TEXT NOT NULL CHECK(category IN (
                    'Morning', 'Breakfast', 'Lunch', 'Afternoon',
                    'Evening', 'Dinner', 'Before Sleep', 'Other'
                )),
                description TEXT NOT NULL DEFAULT '',
                intake_date TEXT NOT NULL,
                intake_time TEXT NOT NULL,
                is_sample INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )

        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_intake_records_date
            ON intake_records (intake_date DESC, intake_time DESC);
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_intake_records_category
            ON intake_records (category);
            """
        )

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_settings (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                daily_target_ml REAL NOT NULL DEFAULT 2500 CHECK(daily_target_ml >= 500 AND daily_target_ml <= 10000),
                preferred_unit TEXT NOT NULL DEFAULT 'ml' CHECK(preferred_unit IN ('ml', 'l')),
                high_single_entry_threshold_ml REAL NOT NULL DEFAULT 1500,
                high_daily_total_threshold_ml REAL NOT NULL DEFAULT 5000,
                reminder_interval_hours INTEGER NOT NULL DEFAULT 2,
                dark_mode INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )

        now = utc_now_iso()
        conn.execute(
            """
            INSERT OR IGNORE INTO user_settings (
                id, daily_target_ml, preferred_unit,
                high_single_entry_threshold_ml, high_daily_total_threshold_ml,
                reminder_interval_hours, dark_mode, created_at, updated_at
            ) VALUES (1, 2500, 'ml', 1500, 5000, 2, 0, ?, ?);
            """,
            (now, now),
        )
        conn.commit()
    finally:
        conn.close()

    return target


@contextmanager
def get_connection(db_path: str | Path | None = None) -> Iterator[sqlite3.Connection]:
    target = init_db(db_path)
    conn = sqlite3.connect(str(target), timeout=10.0)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

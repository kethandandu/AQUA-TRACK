from __future__ import annotations

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.routes.analytics_routes import router as analytics_router
from app.routes.export_routes import router as export_router
from app.routes.import_routes import router as import_router
from app.routes.intake_routes import router as intake_router
from app.routes.settings_routes import router as settings_router


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="AquaTrack API",
    description="Water Intake Reminder Log & Hydration Analytics Backend",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(intake_router)
app.include_router(analytics_router)
app.include_router(settings_router)
app.include_router(export_router)
app.include_router(import_router)


@app.get("/api/health")
async def health_check():
    return {"status": "ok", "service": "aquatrack-fastapi"}

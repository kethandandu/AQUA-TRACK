from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field


class SettingsUpdateSchema(BaseModel):
    daily_target_ml: Optional[float] = Field(default=None, ge=500, le=10000)
    preferred_unit: Optional[Literal["ml", "l"]] = None
    high_single_entry_threshold_ml: Optional[float] = Field(default=None, ge=500, le=5000)
    high_daily_total_threshold_ml: Optional[float] = Field(default=None, ge=2000, le=15000)
    reminder_interval_hours: Optional[int] = Field(default=None, ge=1, le=12)
    dark_mode: Optional[bool] = None

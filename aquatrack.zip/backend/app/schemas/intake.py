from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, field_validator

from app.services.validation_service import ALLOWED_CATEGORIES, ALLOWED_UNITS, validate_time_str
from app.utils.date_utils import parse_iso_date


class IntakeCreateSchema(BaseModel):
    quantity: float = Field(..., gt=0, le=10000)
    unit: Literal["ml", "l"] = "ml"
    category: str = "Other"
    description: str = Field(default="", max_length=240)
    intake_date: str
    intake_time: str
    is_sample: bool = False

    @field_validator("unit", mode="before")
    @classmethod
    def normalize_unit(cls, v: str) -> str:
        if not isinstance(v, str) or v.strip().lower() not in ALLOWED_UNITS:
            raise ValueError("Measurement unit must be 'ml' or 'l'.")
        return v.strip().lower()

    @field_validator("category")
    @classmethod
    def check_category(cls, v: str) -> str:
        if v.strip() not in ALLOWED_CATEGORIES:
            raise ValueError(f"Category must be one of: {', '.join(ALLOWED_CATEGORIES)}")
        return v.strip()

    @field_validator("intake_date")
    @classmethod
    def check_date(cls, v: str) -> str:
        return parse_iso_date(v).isoformat()

    @field_validator("intake_time")
    @classmethod
    def check_time(cls, v: str) -> str:
        return validate_time_str(v)

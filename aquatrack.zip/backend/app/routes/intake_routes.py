from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Request

from app.services.intake_service import (
    create_intake,
    delete_intake,
    get_intake_by_id,
    list_intakes,
    sync_exchange_files,
    update_intake,
)
from app.services.validation_service import InputValidationError

router = APIRouter(prefix="/api/intake", tags=["Water Intake"])


@router.get("")
async def get_intakes(
    search: str = "",
    start_date: str = "",
    end_date: str = "",
    category: str = "",
    unit: str = "",
    min_ml: float | None = Query(default=None),
    max_ml: float | None = Query(default=None),
    sort: str = "newest",
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
):
    return list_intakes(
        search=search,
        start_date=start_date,
        end_date=end_date,
        category=category,
        unit=unit,
        min_ml=min_ml,
        max_ml=max_ml,
        sort=sort,
        page=page,
        page_size=page_size,
    )


@router.post("", status_code=201)
async def add_intake(request: Request):
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail={"error": "Invalid JSON payload.", "details": str(exc)}) from exc

    try:
        record = create_intake(payload)
        sync_exchange_files()
        return {"record": record}
    except InputValidationError as exc:
        raise HTTPException(status_code=422, detail={"error": exc.message, "field_errors": exc.field_errors}) from exc


@router.get("/{record_id}")
async def get_single_intake(record_id: int):
    record = get_intake_by_id(record_id)
    if record is None:
        raise HTTPException(status_code=404, detail={"error": f"Intake record #{record_id} not found."})
    return {"record": record}


@router.put("/{record_id}")
async def edit_intake(record_id: int, request: Request):
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail={"error": "Invalid JSON payload.", "details": str(exc)}) from exc

    try:
        updated = update_intake(record_id, payload)
    except InputValidationError as exc:
        raise HTTPException(status_code=422, detail={"error": exc.message, "field_errors": exc.field_errors}) from exc

    if updated is None:
        raise HTTPException(status_code=404, detail={"error": f"Intake record #{record_id} not found."})
    sync_exchange_files()
    return {"record": updated}


@router.delete("/{record_id}")
async def remove_intake(record_id: int):
    deleted = delete_intake(record_id)
    if not deleted:
        raise HTTPException(status_code=404, detail={"error": f"Intake record #{record_id} not found."})
    sync_exchange_files()
    return {"deleted": True, "id": record_id}

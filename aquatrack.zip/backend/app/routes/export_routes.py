from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from app.services.analytics_service import (
    get_daily_analytics,
    get_monthly_analytics,
    get_weekly_analytics,
)
from app.services.export_service import (
    export_csv_text,
    export_json_text,
    export_markdown_text,
    export_txt_audit,
)
from app.services.intake_service import get_settings
from app.utils.chart_generator import (
    ChartLibraryUnavailableError,
    generate_chart_png,
    is_matplotlib_available,
)

router = APIRouter(prefix="/api/export", tags=["Export"])


@router.get("/csv")
async def download_csv(start_date: str = "", end_date: str = ""):
    content = export_csv_text(start_date, end_date)
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="aquatrack_records.csv"'},
    )


@router.get("/json")
async def download_json(start_date: str = "", end_date: str = ""):
    content = export_json_text(start_date, end_date)
    return Response(
        content=content,
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="aquatrack_export.json"'},
    )


@router.get("/markdown")
async def download_markdown(start_date: str = "", end_date: str = ""):
    content = export_markdown_text(start_date, end_date)
    return Response(
        content=content,
        media_type="text/markdown; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="aquatrack_report.md"'},
    )


@router.get("/txt")
async def download_txt(start_date: str = "", end_date: str = ""):
    content = export_txt_audit(start_date, end_date)
    return Response(
        content=content,
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="aquatrack_audit.txt"'},
    )


@router.get("/chart/status")
async def chart_engine_status():
    return {"matplotlib_available": is_matplotlib_available()}


@router.get("/chart")
async def download_chart(
    type: str = Query(default="weekly"),
    date: str | None = Query(default=None),
):
    settings = get_settings()
    target_ml = settings["daily_target_ml"]
    if type == "daily":
        data = get_daily_analytics(date)
    elif type == "monthly":
        data = get_monthly_analytics()
    elif type in ("weekly", "target_vs_actual", "category"):
        data = get_weekly_analytics(date)
    else:
        raise HTTPException(status_code=400, detail={"error": f"Unsupported chart type '{type}'."})

    try:
        png_bytes = generate_chart_png(type, data, target_ml)
    except ChartLibraryUnavailableError as exc:
        raise HTTPException(status_code=503, detail={"error": str(exc)}) from exc

    return Response(
        content=png_bytes,
        media_type="image/png",
        headers={"Content-Disposition": f'attachment; filename="aquatrack_{type}_chart.png"'},
    )

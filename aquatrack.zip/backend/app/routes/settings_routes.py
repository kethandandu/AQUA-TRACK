from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from app.services.intake_service import get_settings, update_settings
from app.services.validation_service import InputValidationError

router = APIRouter(prefix="/api/settings", tags=["Settings"])


@router.get("")
async def read_settings():
    return {"settings": get_settings()}


@router.put("")
async def save_settings(request: Request):
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail={"error": "Invalid JSON payload.", "details": str(exc)}) from exc
    try:
        updated = update_settings(payload)
        return {"settings": updated}
    except InputValidationError as exc:
        raise HTTPException(status_code=422, detail={"error": exc.message, "field_errors": exc.field_errors}) from exc

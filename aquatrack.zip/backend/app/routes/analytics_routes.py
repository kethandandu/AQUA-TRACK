from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from app.services.analytics_service import (
    get_daily_analytics,
    get_monthly_analytics,
    get_weekly_analytics,
)
from app.services.warning_service import evaluate_warnings

router = APIRouter(prefix="/api/analytics", tags=["Analytics"])


@router.get("/daily")
async def daily_analytics(date: str | None = Query(default=None)):
    try:
        data = get_daily_analytics(date)
        data["warnings"] = evaluate_warnings(data["date"])
        return data
    except ValueError as exc:
        raise HTTPException(status_code=422, detail={"error": str(exc)}) from exc


@router.get("/weekly")
async def weekly_analytics(end_date: str | None = Query(default=None)):
    try:
        return get_weekly_analytics(end_date)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail={"error": str(exc)}) from exc


@router.get("/monthly")
async def monthly_analytics(year: int | None = Query(default=None), month: int | None = Query(default=None)):
    try:
        return get_monthly_analytics(year, month)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail={"error": str(exc)}) from exc

from __future__ import annotations

from fastapi import APIRouter, File, HTTPException, Request, UploadFile

from app.services.import_service import import_csv_content
from app.services.intake_service import sync_exchange_files

router = APIRouter(prefix="/api/import", tags=["Import"])


@router.post("/csv")
async def upload_csv(request: Request, file: UploadFile | None = File(default=None)):
    csv_text = ""
    if file is not None:
        raw_bytes = await file.read()
        try:
            csv_text = raw_bytes.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise HTTPException(status_code=400, detail={"error": "Uploaded file must be UTF-8 encoded CSV text."}) from exc
    else:
        try:
            body = await request.json()
            csv_text = body.get("csv_text", "")
        except Exception as exc:
            raise HTTPException(status_code=400, detail={"error": "Provide a CSV file upload or JSON { csv_text }."}) from exc

    result = import_csv_content(csv_text)
    if result["imported_count"] > 0:
        sync_exchange_files()
    return result

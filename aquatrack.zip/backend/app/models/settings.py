from __future__ import annotations

from dataclasses import dataclass


@dataclass
class UserSettingsModel:
    id: int
    daily_target_ml: float
    preferred_unit: str
    high_single_entry_threshold_ml: float
    high_daily_total_threshold_ml: float
    reminder_interval_hours: int
    dark_mode: bool
    created_at: str
    updated_at: str

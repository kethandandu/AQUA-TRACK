from __future__ import annotations

from dataclasses import dataclass


@dataclass
class IntakeRecordModel:
    id: int
    quantity_ml: float
    original_quantity: float
    original_unit: str
    category: str
    description: str
    intake_date: str
    intake_time: str
    is_sample: bool
    created_at: str
    updated_at: str

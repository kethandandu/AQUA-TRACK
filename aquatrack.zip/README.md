# AquaTrack — Water Intake Reminder Log
**CampusSolve Project No. 31 · Health & Wellbeing**

AquaTrack is a full-stack water intake reminder log and hydration analytics application built for CampusSolve. It enables students and everyday users to record daily water consumption, configure personalized targets, monitor daily/weekly/monthly progress, query historical logs, validate bulk CSV imports, and export multi-format analytical reports and charts.

---

## 1. Problem Statement
Manual hydration tracking and fragmented tools frequently lead to calculation errors, missing records, poor visibility into weekly and monthly habits, and unreliable data persistence. AquaTrack solves this with a focused, defensively validated tracking interface backed by persistent SQLite storage, automated unit conversion (`ml` / `L`), and real-time analytical reporting.

---

## 2. Core & Stretch Features
- **Interactive Dashboard**: Circular SVG completion gauge, real-time daily target comparison, remaining intake, entry count, quick-add buttons (`100 ml`–`750 ml`), 7-day chart, and recent entries.
- **Water Intake Recording**: Supports `ml` and `l` (auto-normalized to `ml`), 8 categories (`Morning`, `Breakfast`, `Lunch`, `Afternoon`, `Evening`, `Dinner`, `Before Sleep`, `Other`), date/time pickers, optional notes, and full edit/delete lifecycle.
- **Personalized Daily Target**: Configurable daily goal (`500 ml`–`10,000 ml`), preferred display unit, and non-medical status indicators (`Below target`, `Target achieved`, `Above target`).
- **Defensive Input Validation**: Frontend + centralized backend validation rejecting empty fields, negative/zero quantities, non-numeric text, excessive single entries (`> 10,000 ml`), invalid dates (`YYYY-MM-DD`), invalid 24h times (`HH:MM`), unsupported units/categories, and malformed JSON.
- **Local Data Persistence**: Primary SQLite database (`data/aquatrack.db`) with indexed date/category columns plus automatic synchronized JSON (`data/records_backup.json`) and CSV (`data/records_backup.csv`) exchange snapshots. Corrupted JSON backups are preserved safely with timestamped recovery backups instead of overwriting user data.
- **History & Search**: Keyword search, date range, category filter, unit filter, min/max volume filters, sorting (newest, oldest, highest, lowest), and pagination.
- **Executive Analytics & Visualizations**: Daily, weekly, and monthly metrics plus 5 interactive Recharts visualizations and backend exportable chart rendering (Matplotlib PNG or server SVG fallback).
- **Multi-Format Export & Bulk CSV Import**: Downloadable CSV, JSON, Markdown, and TXT audit reports; row-by-row validated CSV importer with duplicate detection, error logs, and downloadable CSV template.
- **Threshold Warnings**: Configurable, non-alarming indicators for unachieved targets, high single entries, high daily totals, and rapid duplicate entries.

---

## 3. Technology Stack
- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Recharts, Lucide Icons
- **Runtime Full-Stack Server**: Express + Node.js (`node:sqlite`) serving Vite SPA & `/api/*` REST API
- **Python Backend Architecture (`backend/`)**: Python 3.10+, FastAPI, Pydantic v2, SQLite3, Matplotlib, Pytest / Unittest

---

## 4. Project Architecture
```text
/
├── server.ts                  # Express + Vite + SQLite full-stack server (port 3000)
├── server/                    # TypeScript validation, SQLite storage, analytics, CSV/JSON exchange
├── src/                       # React frontend (components, pages, services, types, utils)
├── backend/                   # Modular Python 3.10+ FastAPI + Matplotlib + pytest backend
│   ├── app/
│   │   ├── main.py            # FastAPI application entry point
│   │   ├── database.py        # SQLite schema & connection lifecycle
│   │   ├── models/            # Domain dataclasses
│   │   ├── schemas/           # Pydantic request validation schemas
│   │   ├── routes/            # REST API routers (/api/intake, /analytics, /settings, /export, /import)
│   │   ├── services/          # Business logic, analytics, warnings, import/export
│   │   ├── utils/             # Defensive JSON/CSV file handler, date helpers, Matplotlib chart generator
│   │   └── data/              # Sample CSV, JSON, and edge-case import datasets
│   ├── tests/
│   │   └── test_aquatrack.py  # 18-case backend test suite
│   └── requirements.txt
└── package.json
```

---

## 5. Installation & Execution

### Option A: Full-Stack Web Application (Port 3000)
```bash
npm install
npm run dev
```
For production build:
```bash
npm run build
npm start
```

### Option B: Python FastAPI Backend (Standalone API on Port 8000)
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

---

## 6. Database Initialization & Sample Data
- The SQLite database (`data/aquatrack.db`) initializes automatically on first server startup with `intake_records` and `user_settings` tables and default settings (`2500 ml/day`).
- **Clean Empty State**: AquaTrack starts with zero records so empty-state behavior works cleanly.
- **Demonstration Data**: Sample datasets are located in `backend/app/data/sample_data.csv`, `backend/app/data/sample_data.json`, and `backend/app/data/sample_import_with_errors.csv`. You can load and clear demonstration data at any time from the Dashboard or Settings page without mixing sample flags with real entries.

---

## 7. Running Backend Tests
Run all 18 backend verification tests covering validation, CRUD persistence, daily/weekly/monthly calculations, missing/corrupted storage recovery, CSV bulk import/rejection, multi-format exports, and empty-database handling:
```bash
# Using Python standard library unittest
python3 -m unittest backend/tests/test_aquatrack.py -v

# Or using pytest (with backend dependencies installed)
pytest backend/tests/test_aquatrack.py -v
```

---

## 8. Export Functionality
- `GET /api/export/csv` — Structured CSV records
- `GET /api/export/json` — Full JSON snapshot with settings & summary analytics
- `GET /api/export/markdown` — Formatted Markdown analytical report
- `GET /api/export/txt` — Fixed-width plain-text audit log
- `GET /api/export/chart?type=weekly` — Backend-rendered chart (`daily`, `weekly`, `monthly`, `target_vs_actual`, `category`)

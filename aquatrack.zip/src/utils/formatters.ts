import type { MeasurementUnit } from '../types/aquatrack';

export function localTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function currentTimeHHMM(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function formatVolume(ml: number, preferredUnit: MeasurementUnit = 'ml'): string {
  if (preferredUnit === 'l') {
    return `${(ml / 1000).toFixed(2)} L`;
  }
  return `${Math.round(ml).toLocaleString()} ml`;
}

export function formatMl(ml: number): string {
  return `${Math.round(ml).toLocaleString()} ml`;
}

export function formatDateShort(iso: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

export function convertQuantityToMl(rawQuantity: string, unit: MeasurementUnit): number | null {
  const num = Number(rawQuantity);
  if (!rawQuantity.trim() || !Number.isFinite(num) || num <= 0) return null;
  return unit === 'l' ? Math.round(num * 1000) : Math.round(num);
}

export const INTAKE_CATEGORIES = [
  'Morning',
  'Breakfast',
  'Lunch',
  'Afternoon',
  'Evening',
  'Dinner',
  'Before Sleep',
  'Other',
] as const;

export type IntakeCategory = (typeof INTAKE_CATEGORIES)[number];
export type MeasurementUnit = 'ml' | 'l';
export type NavSection =
  | 'dashboard'
  | 'track'
  | 'history'
  | 'analytics'
  | 'reports'
  | 'settings';

export interface IntakeRecord {
  id: number;
  quantity_ml: number;
  original_quantity: number;
  original_unit: MeasurementUnit;
  category: IntakeCategory | string;
  description: string;
  intake_date: string;
  intake_time: string;
  is_sample: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  daily_target_ml: number;
  preferred_unit: MeasurementUnit;
  high_single_entry_threshold_ml: number;
  high_daily_total_threshold_ml: number;
  reminder_interval_hours: number;
  dark_mode: boolean;
  updated_at: string;
}

export interface WarningItem {
  code: string;
  severity: 'info' | 'warning' | 'error';
  title: string;
  message: string;
  basis: string;
}

export interface CategoryBreakdownItem {
  category: string;
  total_ml: number;
  entries: number;
}

export interface DailyAnalytics {
  date: string;
  daily_target_ml: number;
  total_ml: number;
  remaining_ml: number;
  completion_pct: number;
  entry_count: number;
  avg_per_entry_ml: number;
  status: 'Below target' | 'Target achieved' | 'Above target' | string;
  target_achieved: boolean;
  category_breakdown: CategoryBreakdownItem[];
  hourly_timeline: Array<{
    label: string;
    total_ml: number;
    cumulative_ml: number;
    category: string;
  }>;
  recent_entries: IntakeRecord[];
  warnings: WarningItem[];
  dataset_meta: {
    total_records: number;
    sample_records: number;
    has_sample_data: boolean;
  };
}

export interface SeriesDayPoint {
  date: string;
  label: string;
  total_ml: number;
  target_ml: number;
  entries: number;
  achieved: boolean;
}

export interface WeeklyAnalytics {
  start_date: string;
  end_date: string;
  daily_target_ml: number;
  total_ml: number;
  daily_average_ml: number;
  active_days: number;
  target_achieved_days: number;
  target_achievement_frequency_pct: number;
  highest_day: { date: string; total_ml: number } | null;
  lowest_day: { date: string; total_ml: number } | null;
  previous_week_total_ml: number;
  trend_pct: number | null;
  daily_series: SeriesDayPoint[];
  category_breakdown: CategoryBreakdownItem[];
}

export interface MonthlyAnalytics {
  year: number;
  month: number;
  start_date: string;
  end_date: string;
  daily_target_ml: number;
  total_ml: number;
  monthly_average_ml: number;
  active_days: number;
  days_in_month: number;
  target_achieved_days: number;
  target_achievement_rate_pct: number;
  highest_day: { date: string; total_ml: number } | null;
  lowest_day: { date: string; total_ml: number } | null;
  previous_month_total_ml: number;
  previous_month_active_days: number;
  month_over_month_delta_pct: number | null;
  daily_series: SeriesDayPoint[];
  category_breakdown: CategoryBreakdownItem[];
}

export interface PaginationMeta {
  page: number;
  page_size: number;
  total_records: number;
  total_pages: number;
}

export interface IntakeListResponse {
  records: IntakeRecord[];
  pagination: PaginationMeta;
}

export interface CsvImportResult {
  success: boolean;
  imported_count: number;
  rejected_count: number;
  duplicate_count: number;
  errors: Array<{
    row: number;
    type: string;
    reason: string;
    raw?: Record<string, string>;
  }>;
}

export interface StorageStatus {
  sqlite_ok: boolean;
  json_backup_ok: boolean;
  csv_backup_ok: boolean;
  warnings: string[];
}

export interface ChartEngineStatus {
  matplotlib_available: boolean;
  active_engine: string;
  message: string;
}

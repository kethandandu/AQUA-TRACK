import { useCallback, useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { ConfirmDialog } from './components/ConfirmDialog';
import { IntakeForm } from './components/IntakeForm';
import { Navbar } from './components/Navbar';
import { Notification, type ToastMessage } from './components/Notification';
import { Sidebar } from './components/Sidebar';
import { Analytics } from './pages/Analytics';
import { Dashboard } from './pages/Dashboard';
import { History } from './pages/History';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { TrackWater } from './pages/TrackWater';
import { api } from './services/api';
import type {
  DailyAnalytics,
  IntakeRecord,
  MeasurementUnit,
  NavSection,
  UserSettings,
  WeeklyAnalytics,
} from './types/aquatrack';
import { currentTimeHHMM, localTodayIso } from './utils/formatters';

const DEFAULT_SETTINGS: UserSettings = {
  daily_target_ml: 2500,
  preferred_unit: 'ml',
  high_single_entry_threshold_ml: 1500,
  high_daily_total_threshold_ml: 5000,
  reminder_interval_hours: 2,
  dark_mode: false,
  updated_at: '',
};

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const [selectedDate, setSelectedDate] = useState(localTodayIso());
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [daily, setDaily] = useState<DailyAnalytics | null>(null);
  const [weekly, setWeekly] = useState<WeeklyAnalytics | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(true);
  const [refreshToken, setRefreshToken] = useState(0);

  const [editingRecord, setEditingRecord] = useState<IntakeRecord | null>(null);
  const [deletingRecord, setDeletingRecord] = useState<IntakeRecord | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const [toast, setToast] = useState<ToastMessage | null>(null);

  const notify = useCallback(
    (type: ToastMessage['type'], title: string, description?: string) => {
      setToast({ id: Date.now(), type, title, description });
    },
    [],
  );

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const root = document.documentElement;
    if (settings.dark_mode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.dark_mode]);

  const loadCoreData = useCallback(async () => {
    setLoadingDashboard(true);
    try {
      const [sRes, dRes, wRes] = await Promise.all([
        api.getSettings(),
        api.getDailyAnalytics(selectedDate),
        api.getWeeklyAnalytics(selectedDate),
      ]);
      setSettings(sRes.settings);
      setDaily(dRes);
      setWeekly(wRes);
    } catch (err) {
      notify(
        'error',
        'Unable to connect to AquaTrack backend',
        err instanceof Error ? err.message : undefined,
      );
    } finally {
      setLoadingDashboard(false);
    }
  }, [selectedDate, notify]);

  useEffect(() => {
    void loadCoreData();
  }, [loadCoreData]);

  const triggerRefresh = useCallback(async () => {
    await loadCoreData();
    setRefreshToken((n) => n + 1);
  }, [loadCoreData]);

  const handleCreateIntake = async (payload: {
    quantity: string;
    unit: MeasurementUnit;
    category: string;
    description: string;
    intake_date: string;
    intake_time: string;
  }) => {
    const res = await api.createIntake(payload);
    await triggerRefresh();
    notify(
      'success',
      `Recorded ${Math.round(res.record.quantity_ml)} ml`,
      `${res.record.category} · ${res.record.intake_date} at ${res.record.intake_time}`,
    );
  };

  const handleQuickAdd = async (ml: number) => {
    const res = await api.createIntake({
      quantity: ml,
      unit: 'ml',
      category: 'Other',
      description: 'Quick-add entry',
      intake_date: selectedDate,
      intake_time: currentTimeHHMM(),
    });
    await triggerRefresh();
    notify('success', `Quick-added ${Math.round(res.record.quantity_ml)} ml`, `Logged for ${selectedDate}`);
  };

  const handleSaveEdit = async (payload: {
    quantity: string;
    unit: MeasurementUnit;
    category: string;
    description: string;
    intake_date: string;
    intake_time: string;
  }) => {
    if (!editingRecord) return;
    const res = await api.updateIntake(editingRecord.id, payload);
    setEditingRecord(null);
    await triggerRefresh();
    notify(
      'success',
      'Entry updated',
      `Updated to ${Math.round(res.record.quantity_ml)} ml (${res.record.category}).`,
    );
  };

  const handleConfirmDelete = async () => {
    if (!deletingRecord) return;
    setDeleteBusy(true);
    try {
      await api.deleteIntake(deletingRecord.id);
      setDeletingRecord(null);
      await triggerRefresh();
      notify('success', 'Entry deleted', 'Dashboard and analytics recalculated.');
    } catch (err) {
      notify('error', 'Failed to delete entry', err instanceof Error ? err.message : undefined);
    } finally {
      setDeleteBusy(false);
    }
  };

  const handleUpdateSettings = async (patch: Partial<UserSettings>) => {
    const res = await api.updateSettings(patch);
    setSettings(res.settings);
    await triggerRefresh();
    notify('success', 'Preferences saved', `Daily target: ${Math.round(res.settings.daily_target_ml)} ml`);
  };

  const handleToggleTheme = async () => {
    const nextDark = !settings.dark_mode;
    setSettings((prev) => ({ ...prev, dark_mode: nextDark }));
    try {
      const res = await api.updateSettings({ dark_mode: nextDark });
      setSettings(res.settings);
    } catch {
      // Revert if persistence fails
    }
  };

  const handleLoadSample = async () => {
    const res = await api.loadSampleDataset();
    await triggerRefresh();
    notify('success', `Loaded ${res.loaded_count} demo records`, 'Sample records are clearly tagged as demonstration data.');
  };

  const handleClearSample = async () => {
    const res = await api.clearSampleDataset();
    await triggerRefresh();
    notify('info', `Cleared ${res.deleted_count} demo records`, 'Your personal entries were preserved.');
  };

  const handleResetAll = async () => {
    const res = await api.resetAllData();
    await triggerRefresh();
    notify('info', `Reset complete (${res.deleted_count} records removed)`, 'Application is now in a clean zero-record state.');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <div className="flex min-h-screen">
        <Sidebar
          activeSection={activeSection}
          onSelect={setActiveSection}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        <div className="flex min-w-0 flex-1 flex-col">
          <Navbar
            activeSection={activeSection}
            darkMode={settings.dark_mode}
            onToggleTheme={handleToggleTheme}
            onOpenMobileNav={() => setMobileNavOpen(true)}
            onQuickTrack={() => setActiveSection('track')}
          />

          <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:px-8">
            {activeSection === 'dashboard' && (
              <Dashboard
                selectedDate={selectedDate}
                onChangeDate={setSelectedDate}
                daily={daily}
                weekly={weekly}
                preferredUnit={settings.preferred_unit}
                loading={loadingDashboard}
                onQuickAdd={handleQuickAdd}
                onNavigate={setActiveSection}
                onEditRecord={setEditingRecord}
                onDeleteRecord={setDeletingRecord}
                onLoadSample={handleLoadSample}
                onClearSample={handleClearSample}
              />
            )}

            {activeSection === 'track' && (
              <TrackWater
                daily={daily}
                preferredUnit={settings.preferred_unit}
                onCreateIntake={handleCreateIntake}
                onQuickAdd={handleQuickAdd}
                onEditRecord={setEditingRecord}
                onDeleteRecord={setDeletingRecord}
              />
            )}

            {activeSection === 'history' && (
              <History
                preferredUnit={settings.preferred_unit}
                refreshToken={refreshToken}
                onEditRecord={setEditingRecord}
                onDeleteRecord={setDeletingRecord}
              />
            )}

            {activeSection === 'analytics' && (
              <Analytics
                preferredUnit={settings.preferred_unit}
                refreshToken={refreshToken}
              />
            )}

            {activeSection === 'reports' && (
              <Reports
                onImportSuccess={triggerRefresh}
                onNotify={notify}
              />
            )}

            {activeSection === 'settings' && (
              <Settings
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onLoadSample={handleLoadSample}
                onClearSample={handleClearSample}
                onResetAll={handleResetAll}
              />
            )}
          </main>
        </div>
      </div>

      {/* Edit Intake Modal */}
      {editingRecord && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-modal-title"
        >
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-4 flex items-center justify-between">
              <h3
                id="edit-modal-title"
                className="text-base font-semibold text-slate-900 dark:text-slate-100"
              >
                Edit Water Intake Entry #{editingRecord.id}
              </h3>
              <button
                type="button"
                onClick={() => setEditingRecord(null)}
                aria-label="Close edit modal"
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <IntakeForm
              initialRecord={editingRecord}
              showQuickAdd={false}
              onSubmit={handleSaveEdit}
              onCancel={() => setEditingRecord(null)}
            />
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(deletingRecord)}
        title="Delete water intake entry?"
        message={
          deletingRecord
            ? `Remove ${Math.round(deletingRecord.quantity_ml)} ml (${deletingRecord.category}) logged on ${deletingRecord.intake_date} at ${deletingRecord.intake_time}?`
            : ''
        }
        confirmLabel="Delete Entry"
        destructive
        busy={deleteBusy}
        onCancel={() => setDeletingRecord(null)}
        onConfirm={handleConfirmDelete}
      />

      <Notification toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}

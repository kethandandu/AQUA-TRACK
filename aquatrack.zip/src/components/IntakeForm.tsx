import { useEffect, useState, type FormEvent } from 'react';
import { AlertCircle } from 'lucide-react';
import { ApiError } from '../services/api';
import { INTAKE_CATEGORIES, type IntakeRecord, type MeasurementUnit } from '../types/aquatrack';
import { convertQuantityToMl, currentTimeHHMM, localTodayIso } from '../utils/formatters';

const QUICK_PRESETS = [100, 150, 250, 300, 500, 750] as const;

interface IntakeFormProps {
  initialRecord?: IntakeRecord | null;
  defaultUnit?: MeasurementUnit;
  onSubmit: (payload: {
    quantity: string;
    unit: MeasurementUnit;
    category: string;
    description: string;
    intake_date: string;
    intake_time: string;
  }) => Promise<void>;
  onCancel?: () => void;
  showQuickAdd?: boolean;
  onQuickAdd?: (ml: number) => Promise<void>;
  allowValidationDemo?: boolean;
}

export function IntakeForm({
  initialRecord,
  defaultUnit = 'ml',
  onSubmit,
  onCancel,
  showQuickAdd = true,
  onQuickAdd,
  allowValidationDemo = false,
}: IntakeFormProps) {
  const [quantity, setQuantity] = useState<string>(
    initialRecord ? String(initialRecord.original_quantity) : '250',
  );
  const [unit, setUnit] = useState<MeasurementUnit>(
    initialRecord ? initialRecord.original_unit : defaultUnit,
  );
  const [category, setCategory] = useState<string>(
    initialRecord ? initialRecord.category : 'Morning',
  );
  const [intakeDate, setIntakeDate] = useState<string>(
    initialRecord ? initialRecord.intake_date : localTodayIso(),
  );
  const [intakeTime, setIntakeTime] = useState<string>(
    initialRecord ? initialRecord.intake_time : currentTimeHHMM(),
  );
  const [description, setDescription] = useState<string>(
    initialRecord ? initialRecord.description : '',
  );
  const [submitting, setSubmitting] = useState(false);
  const [quickBusyMl, setQuickBusyMl] = useState<number | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialRecord) {
      setQuantity(String(initialRecord.original_quantity));
      setUnit(initialRecord.original_unit);
      setCategory(initialRecord.category);
      setIntakeDate(initialRecord.intake_date);
      setIntakeTime(initialRecord.intake_time);
      setDescription(initialRecord.description);
    }
  }, [initialRecord]);

  const convertedMl = convertQuantityToMl(quantity, unit);

  const validateClientSide = (): boolean => {
    const nextErrors: Record<string, string> = {};
    const trimmedQty = quantity.trim();
    const numQty = Number(trimmedQty);

    if (!trimmedQty) {
      nextErrors.quantity = 'Quantity is required and cannot be empty.';
    } else if (!Number.isFinite(numQty)) {
      nextErrors.quantity = 'Enter a valid numeric quantity (no letters or symbols).';
    } else if (numQty <= 0) {
      nextErrors.quantity = 'Quantity must be greater than zero.';
    } else {
      const ml = unit === 'l' ? numQty * 1000 : numQty;
      if (ml < 1) nextErrors.quantity = 'Quantity must be at least 1 ml.';
      if (ml > 10000) nextErrors.quantity = 'Single entry cannot exceed 10,000 ml (10 L).';
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(intakeDate)) {
      nextErrors.intake_date = 'Date must follow YYYY-MM-DD format.';
    }
    if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(intakeTime)) {
      nextErrors.intake_time = 'Time must follow 24-hour HH:MM format.';
    }
    if (description.length > 240) {
      nextErrors.description = 'Description cannot exceed 240 characters.';
    }

    setFieldErrors(nextErrors);
    const firstMsg = Object.values(nextErrors)[0] ?? null;
    setFormError(firstMsg);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent, bypassClient = false) => {
    e.preventDefault();
    setFormError(null);
    setFieldErrors({});

    if (!bypassClient && !validateClientSide()) {
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit({
        quantity: quantity.trim(),
        unit,
        category,
        description: description.trim(),
        intake_date: intakeDate.trim(),
        intake_time: intakeTime.trim(),
      });
      if (!initialRecord) {
        setDescription('');
        setIntakeTime(currentTimeHHMM());
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setFormError(err.message);
        const mapped: Record<string, string> = {};
        for (const fe of err.fieldErrors) {
          mapped[fe.field] = fe.message;
        }
        setFieldErrors(mapped);
      } else {
        setFormError(err instanceof Error ? err.message : 'Unable to save water intake entry.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickPreset = async (ml: number) => {
    if (!onQuickAdd) {
      setUnit('ml');
      setQuantity(String(ml));
      setFieldErrors({});
      setFormError(null);
      return;
    }
    setQuickBusyMl(ml);
    setFormError(null);
    try {
      await onQuickAdd(ml);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Quick add failed.');
    } finally {
      setQuickBusyMl(null);
    }
  };

  const applyInvalidPreset = (kind: 'negative' | 'zero' | 'alpha' | 'excess') => {
    setFormError(null);
    setFieldErrors({});
    if (kind === 'negative') {
      setUnit('ml');
      setQuantity('-250');
    } else if (kind === 'zero') {
      setUnit('ml');
      setQuantity('0');
    } else if (kind === 'alpha') {
      setUnit('ml');
      setQuantity('two_cups');
    } else {
      setUnit('l');
      setQuantity('25');
    }
  };

  return (
    <div className="space-y-5">
      {showQuickAdd && (
        <div>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Quick Add Presets
          </p>
          <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {QUICK_PRESETS.map((ml) => (
              <button
                key={ml}
                type="button"
                disabled={quickBusyMl !== null}
                onClick={() => handleQuickPreset(ml)}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs font-medium text-slate-800 transition-colors hover:border-sky-300 hover:bg-sky-50 hover:text-sky-700 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:border-sky-700 dark:hover:bg-sky-950/60 dark:hover:text-sky-300 whitespace-nowrap"
              >
                {quickBusyMl === ml ? 'Saving...' : `+${ml} ml`}
              </button>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={(e) => handleSubmit(e, false)} noValidate className="space-y-4">
        {formError && (
          <div
            role="alert"
            className="flex items-start gap-2.5 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800 dark:border-rose-900/70 dark:bg-rose-950/40 dark:text-rose-200"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600 dark:text-rose-400" />
            <span>{formError}</span>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="intake-qty"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Quantity
            </label>
            <div className="mt-1.5 flex items-stretch gap-2">
              <input
                id="intake-qty"
                type="text"
                inputMode="decimal"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder={unit === 'l' ? 'e.g. 0.5' : 'e.g. 250'}
                className={`min-w-0 flex-1 rounded-lg border bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:outline-none focus:ring-2 dark:bg-slate-950 dark:text-slate-100 ${
                  fieldErrors.quantity
                    ? 'border-rose-400 focus:ring-rose-500/30 dark:border-rose-700'
                    : 'border-slate-200 focus:border-sky-500 focus:ring-sky-500/20 dark:border-slate-700'
                }`}
              />
              <div className="flex rounded-lg border border-slate-200 bg-slate-100 p-0.5 dark:border-slate-700 dark:bg-slate-800">
                {(['ml', 'l'] as const).map((u) => (
                  <button
                    key={u}
                    type="button"
                    onClick={() => setUnit(u)}
                    className={`rounded-md px-3 py-1.5 font-mono text-xs font-medium uppercase transition-colors ${
                      unit === u
                        ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-slate-100'
                        : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                    }`}
                  >
                    {u}
                  </button>
                ))}
              </div>
            </div>
            <p className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">
              {convertedMl !== null
                ? `Normalized volume: ${convertedMl.toLocaleString()} ml`
                : 'Enter a positive numeric volume'}
            </p>
            {fieldErrors.quantity && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{fieldErrors.quantity}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="intake-category"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Intake Category
            </label>
            <select
              id="intake-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              {INTAKE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="intake-date"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Date
            </label>
            <input
              id="intake-date"
              type="date"
              value={intakeDate}
              onChange={(e) => setIntakeDate(e.target.value)}
              className={`mt-1.5 w-full rounded-lg border bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:outline-none focus:ring-2 dark:bg-slate-950 dark:text-slate-100 ${
                fieldErrors.intake_date
                  ? 'border-rose-400 focus:ring-rose-500/30 dark:border-rose-700'
                  : 'border-slate-200 focus:border-sky-500 focus:ring-sky-500/20 dark:border-slate-700'
              }`}
            />
            {fieldErrors.intake_date && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{fieldErrors.intake_date}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="intake-time"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Time
            </label>
            <input
              id="intake-time"
              type="time"
              value={intakeTime}
              onChange={(e) => setIntakeTime(e.target.value)}
              className={`mt-1.5 w-full rounded-lg border bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:outline-none focus:ring-2 dark:bg-slate-950 dark:text-slate-100 ${
                fieldErrors.intake_time
                  ? 'border-rose-400 focus:ring-rose-500/30 dark:border-rose-700'
                  : 'border-slate-200 focus:border-sky-500 focus:ring-sky-500/20 dark:border-slate-700'
              }`}
            />
            {fieldErrors.intake_time && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{fieldErrors.intake_time}</p>
            )}
          </div>
        </div>

        <div>
          <label
            htmlFor="intake-desc"
            className="block text-xs font-medium text-slate-700 dark:text-slate-300"
          >
            Description (Optional)
          </label>
          <input
            id="intake-desc"
            type="text"
            maxLength={240}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. Post-lecture refill, glass with lunch"
            className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {allowValidationDemo && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400">Test validation:</span>
              <button
                type="button"
                onClick={() => applyInvalidPreset('negative')}
                className="rounded border border-slate-200 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                Negative
              </button>
              <button
                type="button"
                onClick={() => applyInvalidPreset('zero')}
                className="rounded border border-slate-200 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                Zero
              </button>
              <button
                type="button"
                onClick={() => applyInvalidPreset('alpha')}
                className="rounded border border-slate-200 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                Alphabetic
              </button>
              <button
                type="button"
                onClick={(e) => handleSubmit(e as unknown as FormEvent, true)}
                className="rounded border border-amber-200 bg-amber-50 px-2 py-1 text-[11px] text-amber-800 hover:bg-amber-100 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300"
              >
                Verify Server Rejection
              </button>
            </div>
          )}

          <div className="ml-auto flex items-center gap-2.5">
            {onCancel && (
              <button
                type="button"
                onClick={onCancel}
                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-sky-600 px-5 py-2 text-sm font-medium text-white transition-colors hover:bg-sky-700 disabled:opacity-50 dark:bg-sky-500 dark:hover:bg-sky-400 whitespace-nowrap shrink-0"
            >
              {submitting ? 'Saving...' : initialRecord ? 'Save Changes' : 'Record Intake'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

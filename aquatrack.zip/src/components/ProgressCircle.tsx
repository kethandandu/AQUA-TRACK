import { CheckCircle2, Droplets, TrendingUp } from 'lucide-react';
import type { MeasurementUnit } from '../types/aquatrack';
import { formatVolume } from '../utils/formatters';

interface ProgressCircleProps {
  consumedMl: number;
  targetMl: number;
  completionPct: number;
  status: string;
  preferredUnit: MeasurementUnit;
}

export function ProgressCircle({
  consumedMl,
  targetMl,
  completionPct,
  status,
  preferredUnit,
}: ProgressCircleProps) {
  const size = 216;
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedPct = Math.min(100, Math.max(0, completionPct));
  const strokeDashoffset = circumference - (clampedPct / 100) * circumference;

  const isAchieved = consumedMl >= targetMl;
  const isAbove = consumedMl > targetMl;

  const strokeColor = isAbove
    ? 'stroke-sky-500 dark:stroke-sky-400'
    : isAchieved
      ? 'stroke-emerald-500 dark:stroke-emerald-400'
      : 'stroke-sky-600 dark:stroke-sky-400';

  const StatusIcon = isAbove ? TrendingUp : isAchieved ? CheckCircle2 : Droplets;
  const statusColor = isAbove
    ? 'text-sky-700 dark:text-sky-300'
    : isAchieved
      ? 'text-emerald-700 dark:text-emerald-300'
      : 'text-amber-700 dark:text-amber-300';

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="-rotate-90"
          role="img"
          aria-label={`Daily hydration completion: ${completionPct.toFixed(1)}%`}
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            strokeWidth={strokeWidth}
            className="stroke-slate-100 dark:stroke-slate-800"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className={`${strokeColor} transition-all duration-300 ease-out`}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-mono text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-50 tabular-nums">
            {completionPct.toFixed(0)}%
          </span>
          <span className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {formatVolume(consumedMl, preferredUnit)} / {formatVolume(targetMl, preferredUnit)}
          </span>
        </div>
      </div>

      <div className={`mt-4 flex items-center gap-1.5 text-sm font-medium ${statusColor}`}>
        <StatusIcon className="h-4 w-4 shrink-0" />
        <span>{status}</span>
      </div>
    </div>
  );
}

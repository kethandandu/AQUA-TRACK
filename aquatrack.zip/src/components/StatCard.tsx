interface StatCardProps {
  label: string;
  value: string;
  helper?: string;
  tone?: 'default' | 'accent' | 'success' | 'warning';
}

export function StatCard({ label, value, helper, tone = 'default' }: StatCardProps) {
  const valueTone =
    tone === 'accent'
      ? 'text-sky-700 dark:text-sky-400'
      : tone === 'success'
        ? 'text-emerald-700 dark:text-emerald-400'
        : tone === 'warning'
          ? 'text-amber-700 dark:text-amber-400'
          : 'text-slate-900 dark:text-slate-100';

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
      <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</p>
      <p className={`mt-2 font-mono text-2xl font-semibold tracking-tight tabular-nums ${valueTone}`}>
        {value}
      </p>
      {helper && (
        <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">{helper}</p>
      )}
    </div>
  );
}

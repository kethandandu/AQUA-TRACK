import { Menu, Moon, Plus, Sun } from 'lucide-react';
import type { NavSection } from '../types/aquatrack';

interface NavbarProps {
  activeSection: NavSection;
  darkMode: boolean;
  onToggleTheme: () => void;
  onOpenMobileNav: () => void;
  onQuickTrack: () => void;
}

const SECTION_LABELS: Record<NavSection, string> = {
  dashboard: 'Dashboard',
  track: 'Track Water',
  history: 'History',
  analytics: 'Analytics',
  reports: 'Reports & Export',
  settings: 'Settings',
};

export function Navbar({
  activeSection,
  darkMode,
  onToggleTheme,
  onOpenMobileNav,
  onQuickTrack,
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-4 border-b border-slate-200 bg-white/95 px-4 backdrop-blur-xs sm:px-6 dark:border-slate-800 dark:bg-slate-900/95">
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileNav}
          aria-label="Open navigation menu"
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden dark:text-slate-300 dark:hover:bg-slate-800"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div className="flex min-w-0 items-center gap-2 text-sm">
          <span className="hidden text-slate-500 sm:inline dark:text-slate-400">AquaTrack</span>
          <span className="hidden text-slate-300 sm:inline dark:text-slate-700" aria-hidden="true">
            /
          </span>
          <h1 className="truncate font-semibold text-slate-900 dark:text-slate-100">
            {SECTION_LABELS[activeSection]}
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2.5 shrink-0">
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0"
        >
          {darkMode ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
          <span className="hidden sm:inline">{darkMode ? 'Light' : 'Dark'}</span>
        </button>
        <button
          type="button"
          onClick={onQuickTrack}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 text-xs font-medium text-white transition-colors hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400 whitespace-nowrap shrink-0"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Log Water</span>
        </button>
      </div>
    </header>
  );
}

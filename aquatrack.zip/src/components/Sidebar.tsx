import {
  BarChart3,
  Clock,
  Droplets,
  FileSpreadsheet,
  LayoutDashboard,
  PlusCircle,
  Settings as SettingsIcon,
  X,
} from 'lucide-react';
import type { NavSection } from '../types/aquatrack';

interface SidebarProps {
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'track', label: 'Track Water', icon: PlusCircle },
  { id: 'history', label: 'History', icon: Clock },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'reports', label: 'Reports & Export', icon: FileSpreadsheet },
  { id: 'settings', label: 'Settings', icon: SettingsIcon },
];

export function Sidebar({
  activeSection,
  onSelect,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const handlePick = (id: NavSection) => {
    onSelect(id);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex h-full flex-col justify-between bg-white px-4 py-5 dark:bg-slate-900">
      <div>
        <div className="flex items-center justify-between px-2 pb-6">
          <button
            type="button"
            onClick={() => handlePick('dashboard')}
            className="flex items-center gap-2.5 text-left focus:outline-none"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600 text-white dark:bg-sky-500">
              <Droplets className="h-4 w-4" />
            </span>
            <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-50 whitespace-nowrap">
              AquaTrack
            </span>
          </button>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav aria-label="Primary Navigation" className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handlePick(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800/70 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="border-t border-slate-200 px-2 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
        <p className="font-medium text-slate-700 dark:text-slate-300">CampusSolve · Project 31</p>
        <p className="mt-0.5">Water Intake Reminder Log</p>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 lg:block dark:border-slate-800">
        <div className="sticky top-0 h-screen">{navContent}</div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex lg:hidden" role="dialog" aria-modal="true">
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <aside className="relative z-10 w-72 max-w-[82vw] border-r border-slate-200 dark:border-slate-800">
            {navContent}
          </aside>
        </div>
      )}
    </>
  );
}

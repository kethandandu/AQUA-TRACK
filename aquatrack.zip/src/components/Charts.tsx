import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { CategoryBreakdownItem, SeriesDayPoint } from '../types/aquatrack';

const CATEGORY_COLORS = [
  '#0284c7',
  '#0ea5e9',
  '#06b6d4',
  '#14b8a6',
  '#16a34a',
  '#6366f1',
  '#8b5cf6',
  '#64748b',
];

function EmptyChartMessage({ message }: { message: string }) {
  return (
    <div className="flex h-64 items-center justify-center rounded-lg border border-dashed border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
      {message}
    </div>
  );
}

export function DailyTrendChart({
  data,
  targetMl,
}: {
  data: Array<{ label: string; total_ml: number; cumulative_ml: number; category: string }>;
  targetMl: number;
}) {
  if (data.length === 0) {
    return <EmptyChartMessage message="Log water entries for this date to visualize your daily consumption curve." />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.22} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit=" ml" width={62} />
          <Tooltip
            formatter={(value: unknown, name: unknown) => [
              `${Math.round(Number(value))} ml`,
              name === 'cumulative_ml' ? 'Cumulative' : 'Entry Volume',
            ]}
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.94)',
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#f8fafc',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <ReferenceLine
            y={targetMl}
            stroke="#d97706"
            strokeDasharray="4 4"
            label={{ value: `Target ${Math.round(targetMl)} ml`, position: 'insideTopRight', fill: '#d97706', fontSize: 11 }}
          />
          <Area
            type="monotone"
            dataKey="cumulative_ml"
            name="Cumulative (ml)"
            stroke="#0284c7"
            fill="#0ea5e9"
            fillOpacity={0.18}
            strokeWidth={2}
          />
          <Bar dataKey="total_ml" name="Single Entry (ml)" fill="#06b6d4" barSize={16} radius={[3, 3, 0, 0]} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WeeklyComparisonChart({
  data,
  targetMl,
}: {
  data: SeriesDayPoint[];
  targetMl: number;
}) {
  const hasAny = data.some((d) => d.total_ml > 0);
  if (!hasAny) {
    return <EmptyChartMessage message="No intake records found in this 7-day window." />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.22} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit=" ml" width={62} />
          <Tooltip
            formatter={(value: unknown) => [`${Math.round(Number(value))} ml`, 'Consumed']}
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.94)',
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#f8fafc',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <ReferenceLine
            y={targetMl}
            stroke="#d97706"
            strokeDasharray="4 4"
            label={{ value: `Goal ${Math.round(targetMl)} ml`, position: 'insideTopRight', fill: '#d97706', fontSize: 11 }}
          />
          <Bar dataKey="total_ml" name="Daily Total (ml)" radius={[4, 4, 0, 0]} maxBarSize={42}>
            {data.map((entry) => (
              <Cell
                key={entry.date}
                fill={entry.achieved ? '#16a34a' : '#0284c7'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MonthlyOverviewChart({
  data,
  targetMl,
}: {
  data: SeriesDayPoint[];
  targetMl: number;
}) {
  const hasAny = data.some((d) => d.total_ml > 0);
  if (!hasAny) {
    return <EmptyChartMessage message="No intake records recorded for the selected month." />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.22} />
          <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#64748b' }} interval={1} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit=" ml" width={62} />
          <Tooltip
            labelFormatter={(label) => `Day ${label}`}
            formatter={(value: unknown) => [`${Math.round(Number(value))} ml`, 'Daily Total']}
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.94)',
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#f8fafc',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <ReferenceLine y={targetMl} stroke="#d97706" strokeDasharray="4 4" />
          <Bar dataKey="total_ml" name="Daily Volume (ml)" fill="#0ea5e9" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function TargetVsActualChart({ data }: { data: SeriesDayPoint[] }) {
  const hasAny = data.some((d) => d.total_ml > 0);
  if (!hasAny) {
    return <EmptyChartMessage message="Add entries to compare actual consumption against your daily target." />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.22} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit=" ml" width={62} />
          <Tooltip
            formatter={(value: unknown, name: unknown) => [`${Math.round(Number(value))} ml`, String(name)]}
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.94)',
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#f8fafc',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <Bar dataKey="total_ml" name="Actual (ml)" fill="#0284c7" radius={[3, 3, 0, 0]} />
          <Bar dataKey="target_ml" name="Target (ml)" fill="#94a3b8" fillOpacity={0.45} radius={[3, 3, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CategoryDistributionChart({ data }: { data: CategoryBreakdownItem[] }) {
  if (data.length === 0) {
    return <EmptyChartMessage message="No category distribution data available for this period." />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="total_ml"
            nameKey="category"
            cx="50%"
            cy="50%"
            innerRadius={52}
            outerRadius={86}
            paddingAngle={2}
          >
            {data.map((item, idx) => (
              <Cell key={item.category} fill={CATEGORY_COLORS[idx % CATEGORY_COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: unknown) => [`${Math.round(Number(value))} ml`, 'Volume']}
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.94)',
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#f8fafc',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

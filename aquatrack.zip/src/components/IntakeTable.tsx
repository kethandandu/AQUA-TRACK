import { Pencil, Trash2 } from 'lucide-react';
import type { IntakeRecord, MeasurementUnit } from '../types/aquatrack';
import { formatDateShort, formatVolume } from '../utils/formatters';

interface IntakeTableProps {
  records: IntakeRecord[];
  preferredUnit?: MeasurementUnit;
  loading?: boolean;
  emptyTitle?: string;
  emptyActionLabel?: string;
  onEmptyAction?: () => void;
  onEdit: (record: IntakeRecord) => void;
  onDelete: (record: IntakeRecord) => void;
}

export function IntakeTable({
  records,
  preferredUnit = 'ml',
  loading = false,
  emptyTitle = 'No water intake records found.',
  emptyActionLabel,
  onEmptyAction,
  onEdit,
  onDelete,
}: IntakeTableProps) {
  if (loading) {
    return (
      <div className="space-y-2 py-2">
        {[1, 2, 3, 4].map((row) => (
          <div
            key={row}
            className="h-10 w-full animate-pulse rounded-lg bg-slate-100 dark:bg-slate-800/70"
          />
        ))}
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center">
        <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{emptyTitle}</p>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Entries added from Track Water or CSV Import will appear here.
        </p>
        {emptyActionLabel && onEmptyAction && (
          <button
            type="button"
            onClick={onEmptyAction}
            className="mt-4 rounded-lg bg-sky-600 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400"
          >
            {emptyActionLabel}
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-left text-sm">
        <thead>
          <tr className="border-b border-slate-200 text-xs font-medium text-slate-500 dark:border-slate-800 dark:text-slate-400">
            <th className="py-2.5 pr-4">Date</th>
            <th className="py-2.5 pr-4">Time</th>
            <th className="py-2.5 pr-4 text-right">Volume</th>
            <th className="py-2.5 pr-4">Category</th>
            <th className="py-2.5 pr-4">Description</th>
            <th className="py-2.5 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
          {records.map((rec) => (
            <tr
              key={rec.id}
              className="h-11 transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
            >
              <td className="py-2 pr-4 font-mono text-xs text-slate-700 dark:text-slate-300 whitespace-nowrap">
                {formatDateShort(rec.intake_date)}
              </td>
              <td className="py-2 pr-4 font-mono text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                {rec.intake_time}
              </td>
              <td className="py-2 pr-4 text-right font-mono text-xs font-semibold text-slate-900 dark:text-slate-100 tabular-nums whitespace-nowrap">
                {formatVolume(rec.quantity_ml, preferredUnit)}
                {rec.original_unit === 'l' && preferredUnit === 'ml' && (
                  <span className="ml-1.5 font-normal text-slate-400 dark:text-slate-500">
                    ({rec.original_quantity} L)
                  </span>
                )}
              </td>
              <td className="py-2 pr-4 text-xs text-slate-700 dark:text-slate-300 whitespace-nowrap">
                <span>{rec.category}</span>
                {rec.is_sample && (
                  <span className="ml-1.5 text-sky-600 dark:text-sky-400">· Demo</span>
                )}
              </td>
              <td className="max-w-xs truncate py-2 pr-4 text-xs text-slate-600 dark:text-slate-400">
                {rec.description || '—'}
              </td>
              <td className="py-2 text-right whitespace-nowrap">
                <div className="inline-flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onEdit(rec)}
                    aria-label={`Edit entry from ${rec.intake_date} at ${rec.intake_time}`}
                    className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 hover:text-sky-600 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-sky-400"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDelete(rec)}
                    aria-label={`Delete entry from ${rec.intake_date} at ${rec.intake_time}`}
                    className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-rose-50 hover:text-rose-600 dark:text-slate-400 dark:hover:bg-rose-950/60 dark:hover:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

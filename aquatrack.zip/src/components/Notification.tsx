import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: number;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}

interface NotificationProps {
  toast: ToastMessage | null;
  onDismiss: () => void;
}

export function Notification({ toast, onDismiss }: NotificationProps) {
  if (!toast) return null;

  const styles =
    toast.type === 'success'
      ? 'border-emerald-200 bg-white text-slate-900 dark:border-emerald-900/70 dark:bg-slate-900 dark:text-slate-100'
      : toast.type === 'error'
        ? 'border-rose-200 bg-white text-slate-900 dark:border-rose-900/70 dark:bg-slate-900 dark:text-slate-100'
        : 'border-sky-200 bg-white text-slate-900 dark:border-sky-900/70 dark:bg-slate-900 dark:text-slate-100';

  const Icon =
    toast.type === 'success'
      ? CheckCircle2
      : toast.type === 'error'
        ? AlertCircle
        : Info;

  const iconColor =
    toast.type === 'success'
      ? 'text-emerald-600 dark:text-emerald-400'
      : toast.type === 'error'
        ? 'text-rose-600 dark:text-rose-400'
        : 'text-sky-600 dark:text-sky-400';

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed bottom-5 right-5 z-50 flex w-full max-w-sm items-start gap-3 rounded-xl border p-4 shadow-lg transition-all duration-200 ${styles}`}
    >
      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${iconColor}`} />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold">{toast.title}</p>
        {toast.description && (
          <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-400">{toast.description}</p>
        )}
      </div>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Dismiss notification"
        className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

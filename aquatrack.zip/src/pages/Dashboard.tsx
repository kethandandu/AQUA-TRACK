import { useState } from 'react';
import { AlertTriangle, Database, Info, PlusCircle, Sparkles } from 'lucide-react';
import { WeeklyComparisonChart } from '../components/Charts';
import { IntakeTable } from '../components/IntakeTable';
import { ProgressCircle } from '../components/ProgressCircle';
import { StatCard } from '../components/StatCard';
import type {
  DailyAnalytics,
  IntakeRecord,
  MeasurementUnit,
  NavSection,
  WeeklyAnalytics,
} from '../types/aquatrack';
import { formatVolume } from '../utils/formatters';

const QUICK_PRESETS = [100, 150, 250, 300, 500, 750] as const;

interface DashboardProps {
  selectedDate: string;
  onChangeDate: (date: string) => void;
  daily: DailyAnalytics | null;
  weekly: WeeklyAnalytics | null;
  preferredUnit: MeasurementUnit;
  loading: boolean;
  onQuickAdd: (ml: number) => Promise<void>;
  onNavigate: (section: NavSection) => void;
  onEditRecord: (record: IntakeRecord) => void;
  onDeleteRecord: (record: IntakeRecord) => void;
  onLoadSample: () => Promise<void>;
  onClearSample: () => Promise<void>;
}

export function Dashboard({
  selectedDate,
  onChangeDate,
  daily,
  weekly,
  preferredUnit,
  loading,
  onQuickAdd,
  onNavigate,
  onEditRecord,
  onDeleteRecord,
  onLoadSample,
  onClearSample,
}: DashboardProps) {
  const [quickBusyMl, setQuickBusyMl] = useState<number | null>(null);
  const [sampleBusy, setSampleBusy] = useState(false);

  const handleQuick = async (ml: number) => {
    setQuickBusyMl(ml);
    try {
      await onQuickAdd(ml);
    } finally {
      setQuickBusyMl(null);
    }
  };

  const handleSampleAction = async (fn: () => Promise<void>) => {
    setSampleBusy(true);
    try {
      await fn();
    } finally {
      setSampleBusy(false);
    }
  };

  const totalRecords = daily?.dataset_meta.total_records ?? 0;
  const hasSample = daily?.dataset_meta.has_sample_data ?? false;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Daily Hydration Overview
          </h2>
          <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
            Track consumption against your personalized daily water intake target.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <label
            htmlFor="dashboard-date"
            className="text-xs font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap"
          >
            Active Date
          </label>
          <input
            id="dashboard-date"
            type="date"
            value={selectedDate}
            onChange={(e) => e.target.value && onChangeDate(e.target.value)}
            className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
          />
        </div>
      </div>

      {hasSample && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-sky-200 bg-sky-50/70 px-4 py-3 text-xs text-sky-900 dark:border-sky-900/70 dark:bg-sky-950/40 dark:text-sky-200">
          <div className="flex items-center gap-2.5">
            <Info className="h-4 w-4 shrink-0 text-sky-600 dark:text-sky-400" />
            <span>
              Demonstration dataset active ({daily?.dataset_meta.sample_records} sample records clearly tagged). Real entries you add remain separate.
            </span>
          </div>
          <button
            type="button"
            disabled={sampleBusy}
            onClick={() => handleSampleAction(onClearSample)}
            className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 font-medium text-sky-800 transition-colors hover:bg-sky-100 disabled:opacity-50 dark:border-sky-800 dark:bg-slate-900 dark:text-sky-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            {sampleBusy ? 'Clearing...' : 'Clear Demo Data'}
          </button>
        </div>
      )}

      {!loading && totalRecords === 0 && (
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="max-w-xl">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Welcome to AquaTrack
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              Your log currently has zero stored entries. Record your first water intake entry or load the 30-day demonstration dataset to explore analytics and export reports right away.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate('track')}
              className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400 whitespace-nowrap"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>Log First Entry</span>
            </button>
            <button
              type="button"
              disabled={sampleBusy}
              onClick={() => handleSampleAction(onLoadSample)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap"
            >
              <Database className="h-3.5 w-3.5" />
              <span>{sampleBusy ? 'Loading...' : 'Load Demo Dataset'}</span>
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-stretch">
        <div className="flex flex-col justify-center rounded-xl border border-slate-200 bg-white p-6 lg:col-span-4 dark:border-slate-800 dark:bg-slate-900">
          <ProgressCircle
            consumedMl={daily?.total_ml ?? 0}
            targetMl={daily?.daily_target_ml ?? 2500}
            completionPct={daily?.completion_pct ?? 0}
            status={daily?.status ?? 'Below target'}
            preferredUnit={preferredUnit}
          />
        </div>

        <div className="flex flex-col justify-between gap-4 lg:col-span-8">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <StatCard
              label="Daily Target"
              value={formatVolume(daily?.daily_target_ml ?? 2500, preferredUnit)}
              helper="Configured personal goal (adjustable in Settings)"
            />
            <StatCard
              label="Consumed Today"
              value={formatVolume(daily?.total_ml ?? 0, preferredUnit)}
              helper={`${(daily?.completion_pct ?? 0).toFixed(1)}% of daily target`}
              tone={daily?.target_achieved ? 'success' : 'accent'}
            />
            <StatCard
              label="Remaining Requirement"
              value={formatVolume(daily?.remaining_ml ?? 0, preferredUnit)}
              helper={
                (daily?.remaining_ml ?? 0) === 0
                  ? 'Daily hydration goal met'
                  : 'Needed to reach today’s target'
              }
              tone={(daily?.remaining_ml ?? 0) === 0 ? 'success' : 'default'}
            />
            <StatCard
              label="Entries Logged"
              value={String(daily?.entry_count ?? 0)}
              helper={
                daily && daily.entry_count > 0
                  ? `Average ${formatVolume(daily.avg_per_entry_ml, preferredUnit)} per entry`
                  : 'No entries logged for selected date'
              }
            />
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Quick-Add Water Entry ({selectedDate})
              </p>
              <button
                type="button"
                onClick={() => onNavigate('track')}
                className="text-xs font-medium text-sky-600 hover:underline dark:text-sky-400 whitespace-nowrap"
              >
                Custom quantity & category
              </button>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
              {QUICK_PRESETS.map((ml) => (
                <button
                  key={ml}
                  type="button"
                  disabled={quickBusyMl !== null}
                  onClick={() => handleQuick(ml)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs font-medium text-slate-800 transition-colors hover:border-sky-300 hover:bg-sky-50 hover:text-sky-700 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:border-sky-700 dark:hover:bg-sky-950/60 dark:hover:text-sky-300 whitespace-nowrap"
                >
                  {quickBusyMl === ml ? 'Saving...' : `+${ml} ml`}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {daily && daily.warnings.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Threshold & Anomaly Indicators
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="text-xs font-medium text-sky-600 hover:underline dark:text-sky-400"
            >
              Configure thresholds
            </button>
          </div>
          <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
            {daily.warnings.map((w, idx) => {
              const isWarn = w.severity === 'warning';
              return (
                <div
                  key={`${w.code}-${idx}`}
                  className={`flex items-start gap-3 rounded-lg border p-3.5 ${
                    isWarn
                      ? 'border-amber-200 bg-amber-50/60 dark:border-amber-900/60 dark:bg-amber-950/30'
                      : 'border-slate-200 bg-slate-50/80 dark:border-slate-800 dark:bg-slate-800/40'
                  }`}
                >
                  {isWarn ? (
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                  ) : (
                    <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-sky-600 dark:text-sky-400" />
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {w.title}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
                      {w.message}
                    </p>
                    <p className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      Basis: {w.basis}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 xl:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                7-Day Consumption Overview
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {weekly ? `${weekly.start_date} to ${weekly.end_date}` : 'Last 7 days'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="text-xs font-medium text-sky-600 hover:underline dark:text-sky-400 whitespace-nowrap"
            >
              Full analytics
            </button>
          </div>
          <WeeklyComparisonChart
            data={weekly?.daily_series ?? []}
            targetMl={daily?.daily_target_ml ?? 2500}
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 xl:col-span-7 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Recent Water Intake Entries
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Latest entries recorded for {selectedDate}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="text-xs font-medium text-sky-600 hover:underline dark:text-sky-400 whitespace-nowrap"
            >
              View all history
            </button>
          </div>
          <IntakeTable
            records={daily?.recent_entries ?? []}
            preferredUnit={preferredUnit}
            loading={loading}
            emptyTitle={`No entries logged on ${selectedDate}`}
            emptyActionLabel="Record Water Intake"
            onEmptyAction={() => onNavigate('track')}
            onEdit={onEditRecord}
            onDelete={onDeleteRecord}
          />
        </div>
      </div>
    </div>
  );
}

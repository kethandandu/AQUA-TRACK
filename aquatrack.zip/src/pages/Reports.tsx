import { useCallback, useEffect, useState, type ChangeEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileText,
  Upload,
} from 'lucide-react';
import { api } from '../services/api';
import type { CsvImportResult } from '../types/aquatrack';

type ExportFormat = 'csv' | 'json' | 'markdown' | 'txt';

interface ReportsProps {
  onImportSuccess: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
}

export function Reports({ onImportSuccess, onNotify }: ReportsProps) {
  const [format, setFormat] = useState<ExportFormat>('markdown');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [previewText, setPreviewText] = useState('');
  const [loadingPreview, setLoadingPreview] = useState(false);

  const [csvText, setCsvText] = useState('');
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<CsvImportResult | null>(null);

  const refreshPreview = useCallback(async () => {
    setLoadingPreview(true);
    try {
      const text = await api.fetchExportPreview(format, startDate, endDate);
      setPreviewText(text);
    } catch (err) {
      setPreviewText(err instanceof Error ? err.message : 'Unable to generate report preview.');
    } finally {
      setLoadingPreview(false);
    }
  }, [format, startDate, endDate]);

  useEffect(() => {
    void refreshPreview();
  }, [refreshPreview]);

  const handleDownloadExport = (fmt: ExportFormat) => {
    const params = new URLSearchParams();
    if (startDate) params.set('start_date', startDate);
    if (endDate) params.set('end_date', endDate);
    const qs = params.toString() ? `?${params.toString()}` : '';
    api.downloadUrl(`/api/export/${fmt}${qs}`);
    onNotify('success', `Exported ${fmt.toUpperCase()} report`, 'Download started from live records.');
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setCsvText(String(reader.result ?? ''));
      setImportResult(null);
    };
    reader.readAsText(file);
  };

  const handleLoadSampleErrorsCsv = async () => {
    try {
      const res = await api.getSampleErrorCsv();
      setCsvText(res.csv_text);
      setImportResult(null);
      onNotify(
        'info',
        'Loaded edge-case CSV sample',
        'Includes valid rows, duplicate rows, negative/zero quantities, and malformed dates to demonstrate row-level validation.',
      );
    } catch (err) {
      onNotify('error', 'Failed to load sample CSV', err instanceof Error ? err.message : undefined);
    }
  };

  const handleRunImport = async () => {
    setImporting(true);
    try {
      const result = await api.importCsvText(csvText);
      setImportResult(result);
      if (result.imported_count > 0) {
        await onImportSuccess();
        await refreshPreview();
      }
      onNotify(
        result.imported_count > 0 ? 'success' : 'info',
        `Import processed: ${result.imported_count} added`,
        `${result.rejected_count} invalid · ${result.duplicate_count} duplicate(s) skipped.`,
      );
    } catch (err) {
      onNotify('error', 'CSV import failed', err instanceof Error ? err.message : undefined);
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          Reports, Export & Bulk CSV Import
        </h2>
        <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
          Generate downloadable analytical reports in CSV, JSON, Markdown, and TXT formats, or bulk-import validated CSV datasets.
        </p>
      </div>

      {/* Multi-Format Export */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-sky-600 dark:text-sky-400" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Multi-Format Summary Export
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="date"
              aria-label="Export start date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
            <span className="text-xs text-slate-400">to</span>
            <input
              type="date"
              aria-label="Export end date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex rounded-lg border border-slate-200 bg-slate-100 p-1 dark:border-slate-800 dark:bg-slate-800/70">
            {(
              [
                { id: 'markdown', label: 'Markdown (.md)' },
                { id: 'csv', label: 'CSV (.csv)' },
                { id: 'json', label: 'JSON (.json)' },
                { id: 'txt', label: 'Audit Log (.txt)' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFormat(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  format === tab.id
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-slate-100'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleDownloadExport(format)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download {format.toUpperCase()}</span>
            </button>
          </div>
        </div>

        <div className="mt-4">
          <p className="mb-1.5 text-xs font-medium text-slate-500 dark:text-slate-400">
            Live Export Preview
          </p>
          <pre className="max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-50 p-4 font-mono text-xs leading-relaxed text-slate-800 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200">
            {loadingPreview ? 'Generating preview from database...' : previewText}
          </pre>
        </div>
      </section>

      {/* Bulk CSV Import */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Bulk CSV Dataset Import
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Validates headers, dates, 24h times, units, categories, numeric boundaries, and duplicates row-by-row.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => api.downloadUrl('/api/import/template')}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Sample Template CSV</span>
            </button>
            <button
              type="button"
              onClick={handleLoadSampleErrorsCsv}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap"
            >
              Load Edge-Case Test CSV
            </button>
          </div>
        </div>

        <div className="mt-4 space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700">
              <Upload className="h-3.5 w-3.5" />
              <span>Choose CSV File</span>
              <input type="file" accept=".csv,text/csv" onChange={handleFileUpload} className="sr-only" />
            </label>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Required headers: <code className="font-mono">intake_date, intake_time, quantity, unit, category</code>
            </span>
          </div>

          <textarea
            rows={7}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder="Paste CSV rows here or upload a .csv file above..."
            className="w-full rounded-lg border border-slate-200 bg-white p-3 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />

          <div className="flex justify-end">
            <button
              type="button"
              disabled={importing || !csvText.trim()}
              onClick={handleRunImport}
              className="rounded-lg bg-sky-600 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-700 disabled:opacity-50 dark:bg-sky-500 dark:hover:bg-sky-400 whitespace-nowrap"
            >
              {importing ? 'Validating & Importing...' : 'Validate & Import CSV'}
            </button>
          </div>
        </div>

        {importResult && (
          <div className="mt-5 space-y-3 border-t border-slate-200 pt-5 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-6 text-xs">
              <span className="inline-flex items-center gap-1.5 font-medium text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" />
                Imported: <strong className="font-mono">{importResult.imported_count}</strong>
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium text-amber-700 dark:text-amber-400">
                <AlertCircle className="h-4 w-4" />
                Duplicates skipped: <strong className="font-mono">{importResult.duplicate_count}</strong>
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium text-rose-700 dark:text-rose-400">
                <AlertCircle className="h-4 w-4" />
                Invalid rows rejected: <strong className="font-mono">{importResult.rejected_count}</strong>
              </span>
            </div>

            {importResult.errors.length > 0 && (
              <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-300">
                      <th className="px-3 py-2">CSV Row</th>
                      <th className="px-3 py-2">Issue Type</th>
                      <th className="px-3 py-2">Validation Reason</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {importResult.errors.map((err, idx) => (
                      <tr key={`${err.row}-${idx}`}>
                        <td className="px-3 py-2 font-mono text-slate-700 dark:text-slate-300">
                          Row {err.row}
                        </td>
                        <td className="px-3 py-2 capitalize text-slate-700 dark:text-slate-300">
                          {err.type}
                        </td>
                        <td className="px-3 py-2 text-rose-700 dark:text-rose-300">
                          {err.reason}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

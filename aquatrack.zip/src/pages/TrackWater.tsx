import { IntakeForm } from '../components/IntakeForm';
import { IntakeTable } from '../components/IntakeTable';
import { StatCard } from '../components/StatCard';
import type {
  DailyAnalytics,
  IntakeRecord,
  MeasurementUnit,
} from '../types/aquatrack';
import { formatVolume } from '../utils/formatters';

interface TrackWaterProps {
  daily: DailyAnalytics | null;
  preferredUnit: MeasurementUnit;
  onCreateIntake: (payload: {
    quantity: string;
    unit: MeasurementUnit;
    category: string;
    description: string;
    intake_date: string;
    intake_time: string;
  }) => Promise<void>;
  onQuickAdd: (ml: number) => Promise<void>;
  onEditRecord: (record: IntakeRecord) => void;
  onDeleteRecord: (record: IntakeRecord) => void;
}

export function TrackWater({
  daily,
  preferredUnit,
  onCreateIntake,
  onQuickAdd,
  onEditRecord,
  onDeleteRecord,
}: TrackWaterProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          Track Water Intake
        </h2>
        <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
          Record consumption in milliliters (ml) or liters (L). All liters convert automatically to ml for calculations.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Consumed Today"
          value={formatVolume(daily?.total_ml ?? 0, preferredUnit)}
          tone={daily?.target_achieved ? 'success' : 'accent'}
        />
        <StatCard
          label="Remaining Today"
          value={formatVolume(daily?.remaining_ml ?? 0, preferredUnit)}
        />
        <StatCard
          label="Completion"
          value={`${(daily?.completion_pct ?? 0).toFixed(1)}%`}
          helper={daily?.status ?? 'Below target'}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-6 xl:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            New Water Intake Entry
          </h3>
          <p className="mt-1 mb-5 text-xs text-slate-500 dark:text-slate-400">
            Use a quick-add volume button or enter a custom quantity with category and notes.
          </p>
          <IntakeForm
            defaultUnit={preferredUnit}
            onSubmit={onCreateIntake}
            onQuickAdd={onQuickAdd}
            allowValidationDemo
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6 xl:col-span-7 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Today’s Recorded Entries
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Editing or deleting an entry updates all dashboard totals immediately.
              </p>
            </div>
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {daily?.entry_count ?? 0} entries
            </span>
          </div>
          <IntakeTable
            records={daily?.recent_entries ?? []}
            preferredUnit={preferredUnit}
            emptyTitle="No water intake entries recorded today yet."
            onEdit={onEditRecord}
            onDelete={onDeleteRecord}
          />
        </div>
      </div>
    </div>
  );
}

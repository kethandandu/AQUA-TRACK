import { useEffect, useState, type FormEvent } from 'react';
import { AlertCircle, CheckCircle2, Database, RotateCcw, Trash2 } from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ApiError, api } from '../services/api';
import type { MeasurementUnit, StorageStatus, UserSettings } from '../types/aquatrack';

interface SettingsProps {
  settings: UserSettings;
  onUpdateSettings: (payload: Partial<UserSettings>) => Promise<void>;
  onLoadSample: () => Promise<void>;
  onClearSample: () => Promise<void>;
  onResetAll: () => Promise<void>;
}

const TARGET_PRESETS = [2000, 2500, 3000, 3500] as const;

export function Settings({
  settings,
  onUpdateSettings,
  onLoadSample,
  onClearSample,
  onResetAll,
}: SettingsProps) {
  const [dailyTarget, setDailyTarget] = useState(String(settings.daily_target_ml));
  const [preferredUnit, setPreferredUnit] = useState<MeasurementUnit>(settings.preferred_unit);
  const [highSingle, setHighSingle] = useState(String(settings.high_single_entry_threshold_ml));
  const [highDaily, setHighDaily] = useState(String(settings.high_daily_total_threshold_ml));
  const [reminderHours, setReminderHours] = useState(String(settings.reminder_interval_hours));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [storageStatus, setStorageStatus] = useState<StorageStatus | null>(null);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const [dataBusy, setDataBusy] = useState(false);

  useEffect(() => {
    setDailyTarget(String(settings.daily_target_ml));
    setPreferredUnit(settings.preferred_unit);
    setHighSingle(String(settings.high_single_entry_threshold_ml));
    setHighDaily(String(settings.high_daily_total_threshold_ml));
    setReminderHours(String(settings.reminder_interval_hours));
  }, [settings]);

  useEffect(() => {
    void api.getStorageStatus().then(setStorageStatus).catch(() => null);
  }, []);

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    const targetNum = Number(dailyTarget);
    const singleNum = Number(highSingle);
    const dailyNum = Number(highDaily);
    const remNum = Number(reminderHours);

    if (!Number.isFinite(targetNum) || targetNum < 500 || targetNum > 10000) {
      setError('Daily water target must be between 500 ml and 10,000 ml.');
      return;
    }
    if (!Number.isFinite(singleNum) || singleNum < 500 || singleNum > 5000) {
      setError('Single-entry warning threshold must be between 500 ml and 5,000 ml.');
      return;
    }
    if (!Number.isFinite(dailyNum) || dailyNum < 2000 || dailyNum > 15000) {
      setError('High daily total threshold must be between 2,000 ml and 15,000 ml.');
      return;
    }
    if (!Number.isFinite(remNum) || remNum < 1 || remNum > 12) {
      setError('Reminder interval must be between 1 and 12 hours.');
      return;
    }

    setSaving(true);
    try {
      await onUpdateSettings({
        daily_target_ml: targetNum,
        preferred_unit: preferredUnit,
        high_single_entry_threshold_ml: singleNum,
        high_daily_total_threshold_ml: dailyNum,
        reminder_interval_hours: Math.round(remNum),
      });
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError(err instanceof Error ? err.message : 'Unable to save settings.');
      }
    } finally {
      setSaving(false);
    }
  };

  const runDataAction = async (fn: () => Promise<void>) => {
    setDataBusy(true);
    try {
      await fn();
      const s = await api.getStorageStatus();
      setStorageStatus(s);
    } finally {
      setDataBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          Target Preferences & Storage Settings
        </h2>
        <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
          Customize your daily hydration target, display units, threshold warnings, and persistent data controls.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <form
          onSubmit={handleSave}
          className="space-y-5 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-slate-900"
        >
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Personalized Daily Hydration Target
          </h3>

          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label
              htmlFor="settings-target"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Daily Target (ml)
            </label>
            <div className="mt-1.5 flex flex-wrap items-center gap-2">
              <input
                id="settings-target"
                type="number"
                min={500}
                max={10000}
                step={50}
                value={dailyTarget}
                onChange={(e) => setDailyTarget(e.target.value)}
                className="w-40 rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              {TARGET_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setDailyTarget(String(preset))}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs font-medium text-slate-700 hover:bg-sky-50 hover:text-sky-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-sky-950/60"
                >
                  {preset} ml
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
              The 2,500 ml default is a configurable baseline for tracking convenience, not a universal medical recommendation.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="settings-unit"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Preferred Display Unit
              </label>
              <select
                id="settings-unit"
                value={preferredUnit}
                onChange={(e) => setPreferredUnit(e.target.value as MeasurementUnit)}
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="ml">Milliliters (ml)</option>
                <option value="l">Liters (L)</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="settings-reminder"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Reminder Interval (Hours)
              </label>
              <input
                id="settings-reminder"
                type="number"
                min={1}
                max={12}
                value={reminderHours}
                onChange={(e) => setReminderHours(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="settings-high-single"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                High Single-Entry Warning (ml)
              </label>
              <input
                id="settings-high-single"
                type="number"
                min={500}
                max={5000}
                step={50}
                value={highSingle}
                onChange={(e) => setHighSingle(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="settings-high-daily"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                High Daily Total Warning (ml)
              </label>
              <input
                id="settings-high-daily"
                type="number"
                min={2000}
                max={15000}
                step={100}
                value={highDaily}
                onChange={(e) => setHighDaily(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 pt-4 dark:border-slate-800">
            <label className="inline-flex cursor-pointer items-center gap-2.5 text-xs font-medium text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={settings.dark_mode}
                onChange={(e) => onUpdateSettings({ dark_mode: e.target.checked })}
                className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500"
              />
              <span>Enable Dark Mode</span>
            </label>

            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-sky-600 px-5 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-700 disabled:opacity-50 dark:bg-sky-500 dark:hover:bg-sky-400"
            >
              {saving ? 'Saving...' : 'Save Preferences'}
            </button>
          </div>
        </form>

        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Local Persistence & Exchange Status
            </h3>
            <div className="mt-4 space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">SQLite Primary Database</span>
                <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {storageStatus?.sqlite_ok !== false ? 'Connected' : 'Error'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">JSON Exchange Snapshot</span>
                <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {storageStatus?.json_backup_ok !== false ? 'Synced' : 'Needs sync'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">CSV Exchange Snapshot</span>
                <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {storageStatus?.csv_backup_ok !== false ? 'Synced' : 'Needs sync'}
                </span>
              </div>
            </div>
            {storageStatus && storageStatus.warnings.length > 0 && (
              <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
                {storageStatus.warnings.join(' ')}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Demonstration Dataset & Clean Slate
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Sample records are strictly separated from your personal entries so you can preview analytics or return to a clean state anytime.
            </p>
            <div className="mt-4 flex flex-col gap-2.5">
              <button
                type="button"
                disabled={dataBusy}
                onClick={() => runDataAction(onLoadSample)}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-2 text-xs font-medium text-slate-800 transition-colors hover:bg-sky-50 hover:text-sky-700 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-sky-950/60"
              >
                <Database className="h-3.5 w-3.5" />
                <span>Load 30-Day Demo Dataset</span>
              </button>
              <button
                type="button"
                disabled={dataBusy}
                onClick={() => runDataAction(onClearSample)}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Clear Demo Records Only</span>
              </button>
              <button
                type="button"
                disabled={dataBusy}
                onClick={() => setConfirmResetOpen(true)}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2 text-xs font-medium text-rose-700 transition-colors hover:bg-rose-100 disabled:opacity-50 dark:border-rose-900/70 dark:bg-rose-950/40 dark:text-rose-300 dark:hover:bg-rose-950"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Reset All Intake Records</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={confirmResetOpen}
        title="Reset all water intake records?"
        message="This permanently removes all stored intake entries (both personal and demonstration records) from the SQLite database. Your target settings will remain intact."
        confirmLabel="Reset All Records"
        destructive
        busy={dataBusy}
        onCancel={() => setConfirmResetOpen(false)}
        onConfirm={async () => {
          await runDataAction(onResetAll);
          setConfirmResetOpen(false);
        }}
      />
    </div>
  );
}

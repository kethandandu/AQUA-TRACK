import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, Search } from 'lucide-react';
import { IntakeTable } from '../components/IntakeTable';
import { api } from '../services/api';
import {
  INTAKE_CATEGORIES,
  type IntakeRecord,
  type MeasurementUnit,
  type PaginationMeta,
} from '../types/aquatrack';

interface HistoryProps {
  preferredUnit: MeasurementUnit;
  refreshToken: number;
  onEditRecord: (record: IntakeRecord) => void;
  onDeleteRecord: (record: IntakeRecord) => void;
}

export function History({
  preferredUnit,
  refreshToken,
  onEditRecord,
  onDeleteRecord,
}: HistoryProps) {
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [category, setCategory] = useState('all');
  const [unit, setUnit] = useState('all');
  const [minMl, setMinMl] = useState('');
  const [maxMl, setMaxMl] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);

  const [records, setRecords] = useState<IntakeRecord[]>([]);
  const [pagination, setPagination] = useState<PaginationMeta>({
    page: 1,
    page_size: 15,
    total_records: 0,
    total_pages: 1,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.listIntakes({
        search,
        start_date: startDate,
        end_date: endDate,
        category,
        unit,
        min_ml: minMl,
        max_ml: maxMl,
        sort,
        page,
        page_size: 15,
      });
      setRecords(res.records);
      setPagination(res.pagination);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to query intake history.');
    } finally {
      setLoading(false);
    }
  }, [search, startDate, endDate, category, unit, minMl, maxMl, sort, page]);

  useEffect(() => {
    void fetchHistory();
  }, [fetchHistory, refreshToken]);

  const handleResetFilters = () => {
    setSearch('');
    setStartDate('');
    setEndDate('');
    setCategory('all');
    setUnit('all');
    setMinMl('');
    setMaxMl('');
    setSort('newest');
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Consumption History & Search
          </h2>
          <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
            Filter historical entries by keyword, date window, category, unit, or volume.
          </p>
        </div>

        <button
          type="button"
          onClick={handleResetFilters}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Reset Filters</span>
        </button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2">
            <label htmlFor="history-search" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Keyword Search
            </label>
            <div className="relative mt-1">
              <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="history-search"
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Search description, category, or YYYY-MM-DD..."
                className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label htmlFor="history-category" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Category
            </label>
            <select
              id="history-category"
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="all">All categories</option>
              {INTAKE_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="history-sort" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Sort Order
            </label>
            <select
              id="history-sort"
              value={sort}
              onChange={(e) => {
                setSort(e.target.value);
                setPage(1);
              }}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="highest">Highest quantity</option>
              <option value="lowest">Lowest quantity</option>
            </select>
          </div>

          <div>
            <label htmlFor="history-start" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Start Date
            </label>
            <input
              id="history-start"
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPage(1);
              }}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label htmlFor="history-end" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              End Date
            </label>
            <input
              id="history-end"
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPage(1);
              }}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label htmlFor="history-unit" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Original Unit
            </label>
            <select
              id="history-unit"
              value={unit}
              onChange={(e) => {
                setUnit(e.target.value);
                setPage(1);
              }}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="all">All units</option>
              <option value="ml">Milliliters (ml)</option>
              <option value="l">Liters (l)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label htmlFor="history-min" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Min (ml)
              </label>
              <input
                id="history-min"
                type="number"
                min={0}
                value={minMl}
                onChange={(e) => {
                  setMinMl(e.target.value);
                  setPage(1);
                }}
                placeholder="0"
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
            <div>
              <label htmlFor="history-max" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Max (ml)
              </label>
              <input
                id="history-max"
                type="number"
                min={0}
                value={maxMl}
                onChange={(e) => {
                  setMaxMl(e.target.value);
                  setPage(1);
                }}
                placeholder="10000"
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 font-mono text-xs text-slate-900 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200">
          {error}
        </div>
      )}

      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Showing{' '}
            <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
              {records.length}
            </span>{' '}
            of{' '}
            <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
              {pagination.total_records}
            </span>{' '}
            matching records
          </p>
          <p className="font-mono text-xs text-slate-500 dark:text-slate-400">
            Page {pagination.page} / {pagination.total_pages}
          </p>
        </div>

        <IntakeTable
          records={records}
          preferredUnit={preferredUnit}
          loading={loading}
          emptyTitle="No matching water intake records found."
          emptyActionLabel="Reset Filters"
          onEmptyAction={handleResetFilters}
          onEdit={onEditRecord}
          onDelete={onDeleteRecord}
        />

        {pagination.total_pages > 1 && (
          <div className="mt-4 flex items-center justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
            <button
              type="button"
              disabled={pagination.page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
              <span>Previous</span>
            </button>
            <button
              type="button"
              disabled={pagination.page >= pagination.total_pages}
              onClick={() => setPage((p) => Math.min(pagination.total_pages, p + 1))}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <span>Next</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

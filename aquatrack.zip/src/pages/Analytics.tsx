import { useCallback, useEffect, useState } from 'react';
import { Download, RefreshCw } from 'lucide-react';
import {
  CategoryDistributionChart,
  DailyTrendChart,
  MonthlyOverviewChart,
  TargetVsActualChart,
  WeeklyComparisonChart,
} from '../components/Charts';
import { StatCard } from '../components/StatCard';
import { api } from '../services/api';
import type {
  ChartEngineStatus,
  DailyAnalytics,
  MeasurementUnit,
  MonthlyAnalytics,
  WeeklyAnalytics,
} from '../types/aquatrack';
import { formatDateShort, formatVolume, localTodayIso } from '../utils/formatters';

interface AnalyticsProps {
  preferredUnit: MeasurementUnit;
  refreshToken: number;
}

export function Analytics({ preferredUnit, refreshToken }: AnalyticsProps) {
  const today = localTodayIso();
  const [selectedDate, setSelectedDate] = useState(today);
  const [selectedMonth, setSelectedMonth] = useState(today.slice(0, 7));

  const [daily, setDaily] = useState<DailyAnalytics | null>(null);
  const [weekly, setWeekly] = useState<WeeklyAnalytics | null>(null);
  const [monthly, setMonthly] = useState<MonthlyAnalytics | null>(null);
  const [engineStatus, setEngineStatus] = useState<ChartEngineStatus | null>(null);
  const [backendChartType, setBackendChartType] = useState<
    'daily' | 'weekly' | 'monthly' | 'target_vs_actual' | 'category'
  >('weekly');
  const [chartTimestamp, setChartTimestamp] = useState(Date.now());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [yStr, mStr] = selectedMonth.split('-');
      const [dRes, wRes, mRes, eRes] = await Promise.all([
        api.getDailyAnalytics(selectedDate),
        api.getWeeklyAnalytics(selectedDate),
        api.getMonthlyAnalytics(Number(yStr), Number(mStr)),
        api.getChartEngineStatus(),
      ]);
      setDaily(dRes);
      setWeekly(wRes);
      setMonthly(mRes);
      setEngineStatus(eRes);
      setChartTimestamp(Date.now());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load analytics.');
    } finally {
      setLoading(false);
    }
  }, [selectedDate, selectedMonth]);

  useEffect(() => {
    void loadAnalytics();
  }, [loadAnalytics, refreshToken]);

  const backendChartUrl = `/api/export/chart?type=${backendChartType}&date=${encodeURIComponent(
    backendChartType === 'monthly' ? `${selectedMonth}-01` : selectedDate,
  )}&t=${chartTimestamp}`;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Executive Hydration Analytics
          </h2>
          <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
            Real-time daily, weekly, and monthly aggregations computed directly from stored SQLite records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="analytics-date" className="text-xs font-medium text-slate-600 dark:text-slate-400">
              Reference Day
            </label>
            <input
              id="analytics-date"
              type="date"
              value={selectedDate}
              onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="analytics-month" className="text-xs font-medium text-slate-600 dark:text-slate-400">
              Month
            </label>
            <input
              id="analytics-month"
              type="month"
              value={selectedMonth}
              onChange={(e) => e.target.value && setSelectedMonth(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200">
          {error}
        </div>
      )}

      {/* Daily Summary */}
      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          01. Daily Analytics ({formatDateShort(selectedDate)})
        </h3>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard
            label="Total Consumption"
            value={loading ? '...' : formatVolume(daily?.total_ml ?? 0, preferredUnit)}
            helper={`Target: ${formatVolume(daily?.daily_target_ml ?? 2500, preferredUnit)}`}
            tone={daily?.target_achieved ? 'success' : 'accent'}
          />
          <StatCard
            label="Completion Percentage"
            value={loading ? '...' : `${(daily?.completion_pct ?? 0).toFixed(1)}%`}
            helper={daily?.status ?? 'Below target'}
          />
          <StatCard
            label="Remaining Intake"
            value={loading ? '...' : formatVolume(daily?.remaining_ml ?? 0, preferredUnit)}
            helper={`${daily?.entry_count ?? 0} entries recorded`}
          />
          <StatCard
            label="Average Per Entry"
            value={loading ? '...' : formatVolume(daily?.avg_per_entry_ml ?? 0, preferredUnit)}
            helper="Computed across day entries"
          />
        </div>
      </section>

      {/* Weekly Summary */}
      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          02. Weekly Analytics ({weekly ? `${weekly.start_date} to ${weekly.end_date}` : '7-Day Window'})
        </h3>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          <StatCard
            label="Total Weekly Intake"
            value={loading ? '...' : formatVolume(weekly?.total_ml ?? 0, preferredUnit)}
            helper={
              weekly?.trend_pct !== null && weekly?.trend_pct !== undefined
                ? `${weekly.trend_pct >= 0 ? '+' : ''}${weekly.trend_pct}% vs prior 7 days`
                : 'No prior week baseline'
            }
          />
          <StatCard
            label="7-Day Daily Average"
            value={loading ? '...' : formatVolume(weekly?.daily_average_ml ?? 0, preferredUnit)}
            helper={`${weekly?.active_days ?? 0} of 7 active days`}
          />
          <StatCard
            label="Target Achievement Freq"
            value={loading ? '...' : `${(weekly?.target_achievement_frequency_pct ?? 0).toFixed(1)}%`}
            helper={`${weekly?.target_achieved_days ?? 0} of 7 days met goal`}
          />
          <StatCard
            label="Highest Day"
            value={
              weekly?.highest_day
                ? formatVolume(weekly.highest_day.total_ml, preferredUnit)
                : 'N/A'
            }
            helper={weekly?.highest_day ? weekly.highest_day.date : 'No active days'}
          />
          <StatCard
            label="Lowest Active Day"
            value={
              weekly?.lowest_day
                ? formatVolume(weekly.lowest_day.total_ml, preferredUnit)
                : 'N/A'
            }
            helper={weekly?.lowest_day ? weekly.lowest_day.date : 'No active days'}
          />
        </div>
      </section>

      {/* Monthly Summary */}
      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          03. Monthly Analytics ({selectedMonth})
        </h3>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          <StatCard
            label="Total Monthly Intake"
            value={loading ? '...' : formatVolume(monthly?.total_ml ?? 0, preferredUnit)}
            helper={
              monthly?.month_over_month_delta_pct !== null &&
              monthly?.month_over_month_delta_pct !== undefined
                ? `${monthly.month_over_month_delta_pct >= 0 ? '+' : ''}${monthly.month_over_month_delta_pct}% MoM`
                : 'Insufficient prior month data'
            }
          />
          <StatCard
            label="Active-Day Average"
            value={loading ? '...' : formatVolume(monthly?.monthly_average_ml ?? 0, preferredUnit)}
            helper={`${monthly?.active_days ?? 0} active tracking days`}
          />
          <StatCard
            label="Target Achievement Rate"
            value={loading ? '...' : `${(monthly?.target_achievement_rate_pct ?? 0).toFixed(1)}%`}
            helper={`${monthly?.target_achieved_days ?? 0} goal days achieved`}
          />
          <StatCard
            label="Monthly Peak Day"
            value={
              monthly?.highest_day
                ? formatVolume(monthly.highest_day.total_ml, preferredUnit)
                : 'N/A'
            }
            helper={monthly?.highest_day ? monthly.highest_day.date : 'No data'}
          />
          <StatCard
            label="Monthly Lowest Day"
            value={
              monthly?.lowest_day
                ? formatVolume(monthly.lowest_day.total_ml, preferredUnit)
                : 'N/A'
            }
            helper={monthly?.lowest_day ? monthly.lowest_day.date : 'No data'}
          />
        </div>
      </section>

      {/* 5 Interactive Recharts Visualizations */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            1. Daily Water Consumption Trend
          </h4>
          <p className="mb-4 text-xs text-slate-500 dark:text-slate-400">
            Cumulative and per-entry intake timeline for {selectedDate}
          </p>
          <DailyTrendChart
            data={daily?.hourly_timeline ?? []}
            targetMl={daily?.daily_target_ml ?? 2500}
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            2. Weekly Consumption Comparison
          </h4>
          <p className="mb-4 text-xs text-slate-500 dark:text-slate-400">
            7-day comparison highlighting days reaching daily goal in green
          </p>
          <WeeklyComparisonChart
            data={weekly?.daily_series ?? []}
            targetMl={weekly?.daily_target_ml ?? 2500}
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            3. Monthly Consumption Overview
          </h4>
          <p className="mb-4 text-xs text-slate-500 dark:text-slate-400">
            Day-by-day consumption across {selectedMonth}
          </p>
          <MonthlyOverviewChart
            data={monthly?.daily_series ?? []}
            targetMl={monthly?.daily_target_ml ?? 2500}
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            4. Target vs Actual Consumption
          </h4>
          <p className="mb-4 text-xs text-slate-500 dark:text-slate-400">
            Side-by-side 7-day actual intake vs configured target
          </p>
          <TargetVsActualChart data={weekly?.daily_series ?? []} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            5. Water Intake Distribution by Category
          </h4>
          <p className="mb-4 text-xs text-slate-500 dark:text-slate-400">
            Category share across the 7-day reporting window
          </p>
          <CategoryDistributionChart data={weekly?.category_breakdown ?? []} />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Backend Exportable Chart Renderer
              </h4>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                {engineStatus?.message ?? 'Checking backend chart engine...'}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Backend chart type"
                value={backendChartType}
                onChange={(e) =>
                  setBackendChartType(
                    e.target.value as 'daily' | 'weekly' | 'monthly' | 'target_vs_actual' | 'category',
                  )
                }
                className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
              >
                <option value="weekly">Weekly Comparison</option>
                <option value="daily">Daily Trend</option>
                <option value="monthly">Monthly Overview</option>
                <option value="target_vs_actual">Target vs Actual</option>
                <option value="category">Category Distribution</option>
              </select>
              <button
                type="button"
                onClick={() => setChartTimestamp(Date.now())}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Render</span>
              </button>
              <button
                type="button"
                onClick={() => api.downloadUrl(backendChartUrl)}
                className="inline-flex items-center gap-1 rounded-lg bg-sky-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Chart</span>
              </button>
            </div>
          </div>

          <div className="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white p-2 dark:border-slate-800">
            <img
              src={backendChartUrl}
              alt={`Server-rendered ${backendChartType} hydration chart`}
              className="h-auto w-full object-contain"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

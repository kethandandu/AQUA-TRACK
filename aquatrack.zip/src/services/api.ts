import type {
  ChartEngineStatus,
  CsvImportResult,
  DailyAnalytics,
  IntakeListResponse,
  IntakeRecord,
  MonthlyAnalytics,
  StorageStatus,
  UserSettings,
  WeeklyAnalytics,
} from '../types/aquatrack';

export interface FieldError {
  field: string;
  message: string;
}

export class ApiError extends Error {
  status: number;
  fieldErrors: FieldError[];

  constructor(message: string, status: number, fieldErrors: FieldError[] = []) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  const text = await res.text();
  let data: Record<string, unknown> = {};
  if (text) {
    try {
      data = JSON.parse(text) as Record<string, unknown>;
    } catch {
      if (!res.ok) {
        throw new ApiError(`Request failed (${res.status})`, res.status);
      }
    }
  }

  if (!res.ok) {
    const detail = (data.detail as Record<string, unknown> | undefined) ?? data;
    const msg =
      typeof detail.error === 'string'
        ? detail.error
        : typeof data.error === 'string'
          ? data.error
          : `Request failed with status ${res.status}`;
    const fieldErrors = Array.isArray(detail.field_errors)
      ? (detail.field_errors as FieldError[])
      : [];
    throw new ApiError(msg, res.status, fieldErrors);
  }

  return data as T;
}

export interface IntakeQueryFilters {
  search?: string;
  start_date?: string;
  end_date?: string;
  category?: string;
  unit?: string;
  min_ml?: string;
  max_ml?: string;
  sort?: string;
  page?: number;
  page_size?: number;
}

export interface IntakePayload {
  quantity: number | string;
  unit: string;
  category: string;
  description: string;
  intake_date: string;
  intake_time: string;
}

export const api = {
  getDailyAnalytics(date?: string): Promise<DailyAnalytics> {
    const qs = date ? `?date=${encodeURIComponent(date)}` : '';
    return requestJson<DailyAnalytics>(`/api/analytics/daily${qs}`);
  },

  getWeeklyAnalytics(endDate?: string): Promise<WeeklyAnalytics> {
    const qs = endDate ? `?end_date=${encodeURIComponent(endDate)}` : '';
    return requestJson<WeeklyAnalytics>(`/api/analytics/weekly${qs}`);
  },

  getMonthlyAnalytics(year?: number, month?: number): Promise<MonthlyAnalytics> {
    const params = new URLSearchParams();
    if (year) params.set('year', String(year));
    if (month) params.set('month', String(month));
    const qs = params.toString() ? `?${params.toString()}` : '';
    return requestJson<MonthlyAnalytics>(`/api/analytics/monthly${qs}`);
  },

  listIntakes(filters: IntakeQueryFilters = {}): Promise<IntakeListResponse> {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== null && String(v).trim() !== '') {
        params.set(k, String(v));
      }
    });
    const qs = params.toString() ? `?${params.toString()}` : '';
    return requestJson<IntakeListResponse>(`/api/intake${qs}`);
  },

  createIntake(payload: IntakePayload): Promise<{ record: IntakeRecord }> {
    return requestJson<{ record: IntakeRecord }>('/api/intake', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateIntake(id: number, payload: IntakePayload): Promise<{ record: IntakeRecord }> {
    return requestJson<{ record: IntakeRecord }>(`/api/intake/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  deleteIntake(id: number): Promise<{ deleted: boolean; id: number }> {
    return requestJson<{ deleted: boolean; id: number }>(`/api/intake/${id}`, {
      method: 'DELETE',
    });
  },

  getSettings(): Promise<{ settings: UserSettings }> {
    return requestJson<{ settings: UserSettings }>('/api/settings');
  },

  updateSettings(payload: Partial<UserSettings>): Promise<{ settings: UserSettings }> {
    return requestJson<{ settings: UserSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  importCsvText(csvText: string): Promise<CsvImportResult> {
    return requestJson<CsvImportResult>('/api/import/csv', {
      method: 'POST',
      body: JSON.stringify({ csv_text: csvText }),
    });
  },

  getSampleErrorCsv(): Promise<{ csv_text: string }> {
    return requestJson<{ csv_text: string }>('/api/import/sample-errors');
  },

  loadSampleDataset(): Promise<{ loaded_count: number }> {
    return requestJson<{ loaded_count: number }>('/api/sample/load', { method: 'POST' });
  },

  clearSampleDataset(): Promise<{ deleted_count: number }> {
    return requestJson<{ deleted_count: number }>('/api/sample/clear', { method: 'POST' });
  },

  resetAllData(): Promise<{ deleted_count: number }> {
    return requestJson<{ deleted_count: number }>('/api/data/reset', { method: 'POST' });
  },

  getStorageStatus(): Promise<StorageStatus> {
    return requestJson<StorageStatus>('/api/storage/status');
  },

  getChartEngineStatus(): Promise<ChartEngineStatus> {
    return requestJson<ChartEngineStatus>('/api/export/chart/status');
  },

  async fetchExportPreview(format: 'csv' | 'json' | 'markdown' | 'txt', startDate = '', endDate = ''): Promise<string> {
    const params = new URLSearchParams();
    if (startDate) params.set('start_date', startDate);
    if (endDate) params.set('end_date', endDate);
    const qs = params.toString() ? `?${params.toString()}` : '';
    const res = await fetch(`/api/export/${format}${qs}`);
    if (!res.ok) throw new Error(`Failed to generate ${format} export`);
    return res.text();
  },

  downloadUrl(path: string): void {
    const a = document.createElement('a');
    a.href = path;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  },
};

import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import {
  getDailyAnalytics,
  getMonthlyAnalytics,
  getWeeklyAnalytics,
  localTodayIso,
} from './server/analytics.ts';
import { renderChartSvg } from './server/chartSvg.ts';
import {
  clearSampleDataset,
  exportCsvText,
  exportJsonText,
  exportMarkdownText,
  exportTxtAudit,
  importCsvText,
  loadSampleDataset,
  resetAllData,
} from './server/exchange.ts';
import {
  DB_PATH,
  getDb,
  getSettings,
  getStorageStatus,
  rowToRecord,
  syncExchangeFiles,
  utcNowIso,
} from './server/storage.ts';
import {
  ValidationError,
  validateIntakePayload,
  validateSettingsPayload,
} from './server/validation.ts';

const execFileAsync = promisify(execFile);

let matplotlibAvailableCache: boolean | null = null;
async function checkMatplotlib(): Promise<boolean> {
  if (matplotlibAvailableCache !== null) return matplotlibAvailableCache;
  try {
    await execFileAsync('python3', ['-c', 'import matplotlib'], { timeout: 3000 });
    matplotlibAvailableCache = true;
  } catch {
    matplotlibAvailableCache = false;
  }
  return matplotlibAvailableCache;
}

async function startServer() {
  getDb();
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));
  app.use(express.text({ type: 'text/csv', limit: '5mb' }));

  // Malformed JSON error handler
  app.use((err: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'Malformed JSON payload.', details: err.message });
      return;
    }
    next(err);
  });

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'aquatrack',
      storage: getStorageStatus(),
    });
  });

  app.get('/api/storage/status', (_req, res) => {
    res.json(getStorageStatus());
  });

  // Water Intake CRUD + Search/Filter/Sort/Pagination
  app.get('/api/intake', (req, res) => {
    try {
      const db = getDb();
      const search = String(req.query.search ?? '').trim();
      const startDate = String(req.query.start_date ?? '').trim();
      const endDate = String(req.query.end_date ?? '').trim();
      const category = String(req.query.category ?? '').trim();
      const unit = String(req.query.unit ?? '').trim();
      const sort = String(req.query.sort ?? 'newest').trim();
      const page = Math.max(1, Number(req.query.page ?? 1) || 1);
      const pageSize = Math.max(1, Math.min(100, Number(req.query.page_size ?? 20) || 20));

      const minMlRaw = req.query.min_ml !== undefined && String(req.query.min_ml).trim() !== '' ? Number(req.query.min_ml) : null;
      const maxMlRaw = req.query.max_ml !== undefined && String(req.query.max_ml).trim() !== '' ? Number(req.query.max_ml) : null;

      const clauses: string[] = [];
      const params: Array<string | number> = [];

      if (search) {
        const like = `%${search}%`;
        clauses.push('(description LIKE ? OR category LIKE ? OR intake_date LIKE ?)');
        params.push(like, like, like);
      }
      if (startDate) {
        clauses.push('intake_date >= ?');
        params.push(startDate);
      }
      if (endDate) {
        clauses.push('intake_date <= ?');
        params.push(endDate);
      }
      if (category && category.toLowerCase() !== 'all') {
        clauses.push('category = ?');
        params.push(category);
      }
      if (unit && unit.toLowerCase() !== 'all') {
        clauses.push('original_unit = ?');
        params.push(unit.toLowerCase());
      }
      if (minMlRaw !== null && Number.isFinite(minMlRaw)) {
        clauses.push('quantity_ml >= ?');
        params.push(minMlRaw);
      }
      if (maxMlRaw !== null && Number.isFinite(maxMlRaw)) {
        clauses.push('quantity_ml <= ?');
        params.push(maxMlRaw);
      }

      const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
      const orderMap: Record<string, string> = {
        newest: 'intake_date DESC, intake_time DESC, id DESC',
        oldest: 'intake_date ASC, intake_time ASC, id ASC',
        highest: 'quantity_ml DESC, intake_date DESC, intake_time DESC',
        lowest: 'quantity_ml ASC, intake_date DESC, intake_time DESC',
      };
      const orderSql = orderMap[sort] ?? orderMap.newest;
      const offset = (page - 1) * pageSize;

      const countRow = db
        .prepare(`SELECT COUNT(*) AS cnt FROM intake_records ${whereSql}`)
        .get(...params) as { cnt: number };
      const total = Number(countRow.cnt);
      const rows = db
        .prepare(`SELECT * FROM intake_records ${whereSql} ORDER BY ${orderSql} LIMIT ? OFFSET ?`)
        .all(...params, pageSize, offset) as Record<string, unknown>[];

      res.json({
        records: rows.map(rowToRecord),
        pagination: {
          page,
          page_size: pageSize,
          total_records: total,
          total_pages: Math.max(1, Math.ceil(total / pageSize)),
        },
      });
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to load intake records.' });
    }
  });

  app.post('/api/intake', (req, res) => {
    try {
      const cleaned = validateIntakePayload(req.body);
      const db = getDb();
      const now = utcNowIso();
      const info = db
        .prepare(
          `INSERT INTO intake_records (
            quantity_ml, original_quantity, original_unit,
            category, description, intake_date, intake_time,
            is_sample, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          cleaned.quantity_ml,
          cleaned.original_quantity,
          cleaned.original_unit,
          cleaned.category,
          cleaned.description,
          cleaned.intake_date,
          cleaned.intake_time,
          cleaned.is_sample,
          now,
          now,
        );

      const created = db
        .prepare('SELECT * FROM intake_records WHERE id = ?')
        .get(Number(info.lastInsertRowid)) as Record<string, unknown>;
      syncExchangeFiles();
      res.status(201).json({ record: rowToRecord(created) });
    } catch (err) {
      if (err instanceof ValidationError) {
        res.status(422).json({ error: err.message, field_errors: err.fieldErrors });
        return;
      }
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to create intake record.' });
    }
  });

  app.get('/api/intake/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Record ID must be a positive integer.' });
      return;
    }
    const row = getDb().prepare('SELECT * FROM intake_records WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: `Intake record #${id} not found.` });
      return;
    }
    res.json({ record: rowToRecord(row) });
  });

  app.put('/api/intake/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Record ID must be a positive integer.' });
      return;
    }
    const db = getDb();
    const existing = db.prepare('SELECT id FROM intake_records WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: `Intake record #${id} not found.` });
      return;
    }
    try {
      const cleaned = validateIntakePayload(req.body);
      const now = utcNowIso();
      db.prepare(
        `UPDATE intake_records
         SET quantity_ml = ?, original_quantity = ?, original_unit = ?,
             category = ?, description = ?, intake_date = ?, intake_time = ?,
             updated_at = ?
         WHERE id = ?`,
      ).run(
        cleaned.quantity_ml,
        cleaned.original_quantity,
        cleaned.original_unit,
        cleaned.category,
        cleaned.description,
        cleaned.intake_date,
        cleaned.intake_time,
        now,
        id,
      );
      const updated = db.prepare('SELECT * FROM intake_records WHERE id = ?').get(id) as Record<string, unknown>;
      syncExchangeFiles();
      res.json({ record: rowToRecord(updated) });
    } catch (err) {
      if (err instanceof ValidationError) {
        res.status(422).json({ error: err.message, field_errors: err.fieldErrors });
        return;
      }
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to update intake record.' });
    }
  });

  app.delete('/api/intake/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Record ID must be a positive integer.' });
      return;
    }
    const info = getDb().prepare('DELETE FROM intake_records WHERE id = ?').run(id);
    if (Number(info.changes ?? 0) === 0) {
      res.status(404).json({ error: `Intake record #${id} not found.` });
      return;
    }
    syncExchangeFiles();
    res.json({ deleted: true, id });
  });

  // Analytics endpoints
  app.get('/api/analytics/daily', (req, res) => {
    try {
      const dateStr = typeof req.query.date === 'string' ? req.query.date : undefined;
      res.json(getDailyAnalytics(dateStr));
    } catch (err) {
      res.status(422).json({ error: err instanceof Error ? err.message : 'Invalid date parameter.' });
    }
  });

  app.get('/api/analytics/weekly', (req, res) => {
    try {
      const endDate = typeof req.query.end_date === 'string' ? req.query.end_date : undefined;
      res.json(getWeeklyAnalytics(endDate));
    } catch (err) {
      res.status(422).json({ error: err instanceof Error ? err.message : 'Invalid end_date parameter.' });
    }
  });

  app.get('/api/analytics/monthly', (req, res) => {
    try {
      const year = req.query.year ? Number(req.query.year) : undefined;
      const month = req.query.month ? Number(req.query.month) : undefined;
      res.json(getMonthlyAnalytics(year, month));
    } catch (err) {
      res.status(422).json({ error: err instanceof Error ? err.message : 'Invalid month parameter.' });
    }
  });

  // Settings endpoints
  app.get('/api/settings', (_req, res) => {
    res.json({ settings: getSettings() });
  });

  app.put('/api/settings', (req, res) => {
    try {
      const cleaned = validateSettingsPayload(req.body);
      const keys = Object.keys(cleaned);
      if (keys.length > 0) {
        const db = getDb();
        const now = utcNowIso();
        const setSql = [...keys.map((k) => `${k} = ?`), 'updated_at = ?'].join(', ');
        db.prepare(`UPDATE user_settings SET ${setSql} WHERE id = 1`).run(
          ...(Object.values(cleaned) as Array<string | number>),
          now,
        );
      }
      res.json({ settings: getSettings() });
    } catch (err) {
      if (err instanceof ValidationError) {
        res.status(422).json({ error: err.message, field_errors: err.fieldErrors });
        return;
      }
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to update settings.' });
    }
  });

  // Export endpoints
  app.get('/api/export/csv', (req, res) => {
    const start = String(req.query.start_date ?? '');
    const end = String(req.query.end_date ?? '');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="aquatrack_records.csv"');
    res.send(exportCsvText(start, end));
  });

  app.get('/api/export/json', (req, res) => {
    const start = String(req.query.start_date ?? '');
    const end = String(req.query.end_date ?? '');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="aquatrack_export.json"');
    res.send(exportJsonText(start, end));
  });

  app.get('/api/export/markdown', (req, res) => {
    const start = String(req.query.start_date ?? '');
    const end = String(req.query.end_date ?? '');
    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="aquatrack_report.md"');
    res.send(exportMarkdownText(start, end));
  });

  app.get('/api/export/txt', (req, res) => {
    const start = String(req.query.start_date ?? '');
    const end = String(req.query.end_date ?? '');
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="aquatrack_audit.txt"');
    res.send(exportTxtAudit(start, end));
  });

  app.get('/api/export/chart/status', async (_req, res) => {
    const hasMatplotlib = await checkMatplotlib();
    res.json({
      matplotlib_available: hasMatplotlib,
      active_engine: hasMatplotlib ? 'matplotlib' : 'server-svg-renderer',
      message: hasMatplotlib
        ? 'Python Matplotlib Agg renderer is active for high-DPI PNG chart export.'
        : 'Matplotlib library is not installed in this container; using built-in server SVG vector chart renderer.',
    });
  });

  app.get('/api/export/chart', async (req, res) => {
    const chartType = String(req.query.type ?? 'weekly').trim();
    const dateParam = typeof req.query.date === 'string' && req.query.date.trim() ? req.query.date.trim() : localTodayIso();
    const strict = req.query.strict === 'true';

    if (!['daily', 'weekly', 'monthly', 'target_vs_actual', 'category'].includes(chartType)) {
      res.status(400).json({ error: `Unsupported chart type '${chartType}'.` });
      return;
    }

    const hasMatplotlib = await checkMatplotlib();
    if (hasMatplotlib) {
      try {
        const backendDir = path.resolve(process.cwd(), 'backend');
        const script = `
import json, sys
sys.path.insert(0, ${JSON.stringify(backendDir)})
from app.services.analytics_service import get_daily_analytics, get_weekly_analytics, get_monthly_analytics
from app.services.intake_service import get_settings
from app.utils.chart_generator import generate_chart_png
db_path = ${JSON.stringify(DB_PATH)}
settings = get_settings(db_path)
ctype = sys.argv[1]
dstr = sys.argv[2]
if ctype == "daily":
    data = get_daily_analytics(dstr, db_path)
elif ctype == "monthly":
    y, m = int(dstr[:4]), int(dstr[5:7])
    data = get_monthly_analytics(y, m, db_path)
else:
    data = get_weekly_analytics(dstr, db_path)
png = generate_chart_png(ctype, data, settings["daily_target_ml"])
sys.stdout.buffer.write(png)
`;
        const { stdout } = await execFileAsync('python3', ['-c', script, chartType, dateParam], {
          encoding: 'buffer' as unknown as BufferEncoding,
          maxBuffer: 10 * 1024 * 1024,
        });
        res.setHeader('Content-Type', 'image/png');
        res.setHeader('X-Chart-Engine', 'matplotlib');
        res.setHeader('Content-Disposition', `inline; filename="aquatrack_${chartType}_chart.png"`);
        res.send(stdout);
        return;
      } catch (err) {
        if (strict) {
          res.status(503).json({
            error: err instanceof Error ? err.message : 'Matplotlib chart rendering failed.',
          });
          return;
        }
      }
    } else if (strict) {
      res.status(503).json({
        error: 'Matplotlib is not installed in the current Python runtime. Use built-in server SVG rendering or install matplotlib.',
        fallback_available: true,
      });
      return;
    }

    const settings = getSettings();
    let data: Record<string, unknown>;
    if (chartType === 'daily') {
      data = getDailyAnalytics(dateParam);
    } else if (chartType === 'monthly') {
      data = getMonthlyAnalytics(Number(dateParam.slice(0, 4)), Number(dateParam.slice(5, 7)));
    } else {
      data = getWeeklyAnalytics(dateParam);
    }
    const svg = renderChartSvg(chartType, data, settings.daily_target_ml);
    res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
    res.setHeader('X-Chart-Engine', 'server-svg-renderer');
    res.setHeader('Content-Disposition', `inline; filename="aquatrack_${chartType}_chart.svg"`);
    res.send(svg);
  });

  // Bulk CSV Import & Templates
  app.post('/api/import/csv', (req, res) => {
    try {
      let csvText = '';
      if (typeof req.body === 'string') {
        csvText = req.body;
      } else if (req.body && typeof req.body === 'object' && typeof req.body.csv_text === 'string') {
        csvText = req.body.csv_text;
      } else {
        res.status(400).json({ error: 'Provide CSV text in request body ({ csv_text }) or text/csv payload.' });
        return;
      }
      const result = importCsvText(csvText);
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'CSV import failed.' });
    }
  });

  app.get('/api/import/template', (_req, res) => {
    const today = localTodayIso();
    const template = [
      'intake_date,intake_time,quantity,unit,category,description',
      `${today},08:00,300,ml,Morning,Wake-up glass`,
      `${today},12:30,0.5,l,Lunch,Midday bottle`,
      `${today},16:15,250,ml,Afternoon,Study break`,
    ].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="aquatrack_import_template.csv"');
    res.send(`${template}\n`);
  });

  app.get('/api/import/sample-errors', (_req, res) => {
    const sampleErrPath = path.resolve(process.cwd(), 'backend', 'app', 'data', 'sample_import_with_errors.csv');
    const content = fs.readFileSync(sampleErrPath, 'utf-8');
    res.json({ csv_text: content });
  });

  // Demonstration Data Management (strictly separated from user records)
  app.post('/api/sample/load', (_req, res) => {
    try {
      const result = loadSampleDataset();
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to load sample dataset.' });
    }
  });

  app.post('/api/sample/clear', (_req, res) => {
    try {
      const result = clearSampleDataset();
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to clear sample dataset.' });
    }
  });

  app.post('/api/data/reset', (_req, res) => {
    try {
      const result = resetAllData();
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to reset records.' });
    }
  });

  // Vite middleware in dev; static dist/ in production
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(process.cwd(), 'dist'));
  if (isProd) {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*splat', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AquaTrack server listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start AquaTrack server:', err);
  process.exit(1);
});
